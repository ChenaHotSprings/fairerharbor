<?php
/**
 * Plugin Name: FairerHarbor
 * Description: Activity booking and tour management for Chena Hot Springs Resort.
 * Version:     15.0.0
 * Author:      Chena Hot Springs Resort
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ──────────────────────────────────────────────────────────────────
// 1. ACTIVATION — create all tables
// ──────────────────────────────────────────────────────────────────
register_activation_hook( __FILE__, 'fh_create_tables' );

function fh_create_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    // Activities table
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}fh_activities (
        id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        name            VARCHAR(200)    NOT NULL,
        description     TEXT            DEFAULT '',
        color           VARCHAR(10)     DEFAULT '#049DE1',
        duration_min    INT             NOT NULL DEFAULT 60,
        capacity        INT             NOT NULL DEFAULT 20,
        price_adult     DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        price_child     DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        price_group     DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        group_min       INT             NOT NULL DEFAULT 10,
        season_start    DATE            DEFAULT NULL,
        season_end      DATE            DEFAULT NULL,
        active          TINYINT(1)      NOT NULL DEFAULT 1,
        sort_order      INT             NOT NULL DEFAULT 0,
        created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset;");

    // Time slots table
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}fh_slots (
        id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        activity_id     BIGINT UNSIGNED NOT NULL,
        slot_time       TIME            NOT NULL,
        days_of_week    VARCHAR(20)     NOT NULL DEFAULT '0,1,2,3,4,5,6',
        active          TINYINT(1)      NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        KEY activity_id (activity_id)
    ) $charset;");

    // Bookings table
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}fh_bookings (
        id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        activity_id     BIGINT UNSIGNED NOT NULL,
        slot_id         BIGINT UNSIGNED NOT NULL,
        booking_date    DATE            NOT NULL,
        booking_time    TIME            NOT NULL,
        guest_name      VARCHAR(200)    NOT NULL,
        guest_email     VARCHAR(200)    NOT NULL,
        guest_phone     VARCHAR(50)     DEFAULT '',
        party_size      INT             NOT NULL DEFAULT 1,
        adults          INT             NOT NULL DEFAULT 1,
        children        INT             NOT NULL DEFAULT 0,
        price_type      ENUM('adult','child','group') NOT NULL DEFAULT 'adult',
        total_price     DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        status          ENUM('confirmed','cancelled','no_show','completed') NOT NULL DEFAULT 'confirmed',
        booking_source  ENUM('online','onsite','phone') NOT NULL DEFAULT 'onsite',
        waiver_id       BIGINT UNSIGNED DEFAULT NULL,
        waiver_status   ENUM('pending','signed','exempt') NOT NULL DEFAULT 'pending',
        notes           TEXT            DEFAULT '',
        guide_name      VARCHAR(200)    DEFAULT '',
        confirmation_code VARCHAR(20)  NOT NULL DEFAULT '',
        created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY activity_id (activity_id),
        KEY booking_date (booking_date),
        KEY guest_email (guest_email)
    ) $charset;");

    // Blackout dates
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}fh_blackouts (
        id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        activity_id     BIGINT UNSIGNED DEFAULT NULL,
        blackout_date   DATE            NOT NULL,
        reason          VARCHAR(200)    DEFAULT '',
        PRIMARY KEY (id),
        KEY blackout_date (blackout_date)
    ) $charset;");

    // Guest booking extras (additional guests in a party)
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}fh_booking_guests (
        id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        booking_id      BIGINT UNSIGNED NOT NULL,
        guest_name      VARCHAR(200)    NOT NULL,
        guest_email     VARCHAR(200)    DEFAULT '',
        waiver_id       BIGINT UNSIGNED DEFAULT NULL,
        waiver_status   ENUM('pending','signed') NOT NULL DEFAULT 'pending',
        PRIMARY KEY (id),
        KEY booking_id (booking_id)
    ) $charset;");

    // ── Custom fields per activity
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}fh_activity_fields (
        id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        activity_id  BIGINT UNSIGNED NOT NULL,
        field_label  VARCHAR(200)    NOT NULL,
        field_key    VARCHAR(100)    NOT NULL,
        field_type   ENUM('text','number','select','checkbox') NOT NULL DEFAULT 'text',
        field_options TEXT           DEFAULT '',
        required     TINYINT(1)      NOT NULL DEFAULT 0,
        sort_order   INT             NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        KEY activity_id (activity_id)
    ) $charset;");

    // ── Upsells per activity
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}fh_upsells (
        id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        activity_id  BIGINT UNSIGNED NOT NULL,
        name         VARCHAR(200)    NOT NULL,
        description  TEXT            DEFAULT '',
        price        DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        price_type   ENUM('per_person','flat') NOT NULL DEFAULT 'per_person',
        active       TINYINT(1)      NOT NULL DEFAULT 1,
        sort_order   INT             NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        KEY activity_id (activity_id)
    ) $charset;");

    // ── Add-ons product catalog
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}fh_addons (
        id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        name         VARCHAR(200)    NOT NULL,
        description  TEXT            DEFAULT '',
        photo_url    VARCHAR(500)    DEFAULT '',
        price        DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        tax_rate     DECIMAL(5,2)    NOT NULL DEFAULT 0.00,
        fee_type     ENUM('flat','percent') NOT NULL DEFAULT 'flat',
        fee_amount   DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        price_type   ENUM('per_person','flat') NOT NULL DEFAULT 'per_person',
        active       TINYINT(1)      NOT NULL DEFAULT 1,
        sort_order   INT             NOT NULL DEFAULT 0,
        PRIMARY KEY (id)
    ) $charset;");

    // ── Activity → Addon links
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}fh_activity_addons (
        id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        activity_id BIGINT UNSIGNED NOT NULL,
        addon_id    BIGINT UNSIGNED NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY act_addon (activity_id, addon_id)
    ) $charset;");

    // ── Plugin settings
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}fh_settings (
        setting_key   VARCHAR(100) NOT NULL,
        setting_value LONGTEXT     DEFAULT '',
        PRIMARY KEY (setting_key)
    ) $charset;");

    // ── Guest waiver tracking per booking party member
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}fh_guest_waivers (
        id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        booking_id   BIGINT UNSIGNED NOT NULL,
        guest_name   VARCHAR(200)    NOT NULL,
        guest_email  VARCHAR(200)    DEFAULT '',
        waiver_id    BIGINT UNSIGNED DEFAULT NULL,
        waiver_token VARCHAR(64)     DEFAULT '',
        status       ENUM('pending','signed') NOT NULL DEFAULT 'pending',
        sent_at      DATETIME        DEFAULT NULL,
        signed_at    DATETIME        DEFAULT NULL,
        PRIMARY KEY (id),
        KEY booking_id (booking_id)
    ) $charset;");

    // ── Slot overrides (per-date capacity + bookable toggle)
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}fh_slot_overrides (
        id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        slot_id      BIGINT UNSIGNED NOT NULL,
        override_date DATE           NOT NULL,
        capacity     INT             DEFAULT NULL,
        bookable     TINYINT(1)      NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        UNIQUE KEY slot_date (slot_id, override_date)
    ) $charset;");

    // ── Booking custom field values
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}fh_booking_fields (
        id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        booking_id   BIGINT UNSIGNED NOT NULL,
        field_key    VARCHAR(100)    NOT NULL,
        field_label  VARCHAR(200)    NOT NULL,
        field_value  TEXT            DEFAULT '',
        PRIMARY KEY (id),
        KEY booking_id (booking_id)
    ) $charset;");

    // ── Booking upsells selected
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}fh_booking_upsells (
        id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        booking_id   BIGINT UNSIGNED NOT NULL,
        upsell_id    BIGINT UNSIGNED NOT NULL,
        upsell_name  VARCHAR(200)    NOT NULL,
        price        DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        price_type   ENUM('per_person','flat') NOT NULL DEFAULT 'per_person',
        quantity     INT             NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        KEY booking_id (booking_id)
    ) $charset;");
}

// Safe upgrade on every load
add_action('init', 'fh_safe_upgrade');
function fh_safe_upgrade() {
    global $wpdb;
    $t = $wpdb->prefix . 'fh_bookings';
    if ( $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) !== $t ) {
        fh_create_tables();
    }
    // Add checkin_status column if missing
    $cols = $wpdb->get_col("DESC {$wpdb->prefix}fh_bookings", 0);
    if (!in_array('checkin_status', $cols))
        $wpdb->query("ALTER TABLE {$wpdb->prefix}fh_bookings ADD COLUMN checkin_status VARCHAR(20) NOT NULL DEFAULT 'not_checked_in'");
    if (!in_array('payment_status', $cols))
        $wpdb->query("ALTER TABLE {$wpdb->prefix}fh_bookings ADD COLUMN payment_status ENUM('unpaid','partial','paid') NOT NULL DEFAULT 'unpaid'");
    if (!in_array('payment_amount', $cols))
        $wpdb->query("ALTER TABLE {$wpdb->prefix}fh_bookings ADD COLUMN payment_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00");
    if (!in_array('refund_amount', $cols))
        $wpdb->query("ALTER TABLE {$wpdb->prefix}fh_bookings ADD COLUMN refund_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00");
    if (!in_array('staying_at_resort', $cols))
        $wpdb->query("ALTER TABLE {$wpdb->prefix}fh_bookings ADD COLUMN staying_at_resort TINYINT(1) NOT NULL DEFAULT 0");
    if (!in_array('room_number', $cols))
        $wpdb->query("ALTER TABLE {$wpdb->prefix}fh_bookings ADD COLUMN room_number VARCHAR(20) DEFAULT ''");
    if (!in_array('guest_first_name', $cols))
        $wpdb->query("ALTER TABLE {$wpdb->prefix}fh_bookings ADD COLUMN guest_first_name VARCHAR(100) DEFAULT ''");
    if (!in_array('guest_last_name', $cols))
        $wpdb->query("ALTER TABLE {$wpdb->prefix}fh_bookings ADD COLUMN guest_last_name VARCHAR(100) DEFAULT ''");
    // Add slot_overrides table if missing
    fh_create_tables();
}

// ──────────────────────────────────────────────────────────────────
// 2. ADMIN MENUS
// ──────────────────────────────────────────────────────────────────
add_action('admin_menu', 'fh_admin_menu');
function fh_admin_menu() {
    add_menu_page('FairerHarbor', 'FairerHarbor', 'view_chena_waivers', 'farerharbor', 'fh_dashboard_page', 'dashicons-calendar-alt', 25);
    add_submenu_page('farerharbor', 'Dashboard',  'Dashboard',  'view_chena_waivers', 'farerharbor',            'fh_dashboard_page');
    add_submenu_page('farerharbor', 'Calendar',     'Calendar',     'view_chena_waivers', 'farerharbor-calendar',   'fh_calendar_page');
    add_submenu_page('farerharbor', 'New Booking',  'New Booking',  'view_chena_waivers', 'farerharbor-new',        'fh_new_booking_page');
    add_submenu_page('farerharbor', 'Activities',   'Activities',   'manage_options',     'farerharbor-activities', 'fh_activities_page');
    add_submenu_page('farerharbor', 'Add-ons',    'Add-ons',    'manage_options',     'farerharbor-addons',     'fh_addons_page');
    add_submenu_page('farerharbor', 'Manifests',  'Manifests',  'view_chena_waivers', 'farerharbor-manifests',  'fh_manifests_page');
    add_submenu_page('farerharbor', 'Settings',   'Settings',   'manage_options',     'farerharbor-settings',   'fh_settings_page');
}

// ──────────────────────────────────────────────────────────────────
// 3. SHARED STYLES + JS
// ──────────────────────────────────────────────────────────────────
function fh_styles() { ?>
<style>
:root {
  --fh-bg:       #111827;
  --fh-surface:  #1f2937;
  --fh-surface2: #1a2535;
  --fh-border:   rgba(99,152,199,.2);
  --fh-blue:     #049DE1;
  --fh-teal:     #40FFF3;
  --fh-text:     #f1f5f9;
  --fh-muted:    #94a3b8;
  --fh-dim:      #64748b;
  --fh-green:    #1a9a50;
  --fh-red:      #d94040;
  --fh-yellow:   #d4a017;
}
@keyframes fh-pulse { 0%,100%{opacity:1;} 50%{opacity:.5;} }
@keyframes fh-in    { from{opacity:0;transform:translateY(6px);} to{opacity:1;transform:translateY(0);} }

.fh-wrap { font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; max-width:1400px; animation:fh-in .2s ease; }

/* ── Top bar ── */
.fh-topbar { background:var(--fh-bg); border-radius:8px 8px 0 0; padding:12px 20px; display:flex; align-items:center; gap:12px; border-bottom:2px solid var(--fh-blue); flex-wrap:wrap; }
.fh-topbar-logo { height:44px; width:auto; }
.fh-topbar-divider { width:1px; height:28px; background:var(--fh-border); flex-shrink:0; }
.fh-topbar-title { font-size:15px; font-weight:800; color:var(--fh-blue); letter-spacing:.06em; text-transform:uppercase; }
.fh-topbar-sub { font-size:11px; color:var(--fh-muted); }
.fh-spacer { flex:1; }

/* ── Buttons ── */
.fh-btn { display:inline-flex; align-items:center; gap:5px; padding:7px 15px; border-radius:6px; font-size:12px; font-weight:700; cursor:pointer; border:1px solid transparent; text-decoration:none; transition:all .15s; white-space:nowrap; }
.fh-btn:hover { text-decoration:none; opacity:.85; }
.fh-btn-primary  { background:var(--fh-blue); color:#fff; border-color:var(--fh-blue); }
.fh-btn-ghost    { background:rgba(4,157,225,.1); color:#7ecfef; border-color:var(--fh-border); }
.fh-btn-ghost:hover { background:rgba(4,157,225,.2); color:#fff; border-color:var(--fh-blue); }
.fh-btn-green    { background:var(--fh-green); color:#fff; border-color:var(--fh-green); }
.fh-btn-red      { background:rgba(217,64,64,.15); color:#f07070; border-color:rgba(217,64,64,.4); }
.fh-btn-red:hover { background:rgba(217,64,64,.3); color:#fff; }
.fh-btn-sm { padding:4px 10px; font-size:11px; }

/* ── Cards ── */
.fh-card { background:var(--fh-surface); border:1px solid var(--fh-border); border-radius:8px; overflow:hidden; margin-bottom:18px; }
.fh-card-hdr { background:var(--fh-surface2); color:var(--fh-blue); font-size:10px; font-weight:700; letter-spacing:.12em; text-transform:uppercase; padding:9px 18px; border-bottom:1px solid var(--fh-border); display:flex; align-items:center; justify-content:space-between; gap:10px; }
.fh-card-body { padding:18px; }

/* ── KPI grid ── */
.fh-kpi-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(140px,1fr)); gap:12px; margin-bottom:20px; }
.fh-kpi { background:var(--fh-surface); border:1px solid var(--fh-border); border-radius:8px; padding:16px; text-align:center; }
.fh-kpi .num { font-size:30px; font-weight:800; color:var(--fh-blue); line-height:1; }
.fh-kpi .lbl { font-size:10px; color:var(--fh-muted); margin-top:5px; text-transform:uppercase; letter-spacing:.08em; }
.fh-kpi.highlight .num { color:var(--fh-teal); }

/* ── Table ── */
.fh-table-wrap { background:var(--fh-bg); border:1px solid var(--fh-border); border-radius:0 0 8px 8px; overflow:hidden; }
.fh-table { width:100%; border-collapse:collapse; font-size:12px; }
.fh-table thead tr { background:var(--fh-surface2); }
.fh-table thead th { padding:9px 12px; color:var(--fh-blue); font-size:10px; font-weight:700; letter-spacing:.1em; text-transform:uppercase; border-bottom:1px solid var(--fh-border); text-align:left; white-space:nowrap; }
.fh-table tbody tr { border-bottom:1px solid rgba(255,255,255,.04); transition:background .1s; cursor:pointer; }
.fh-table tbody tr:hover { background:rgba(4,157,225,.07); }
.fh-table tbody tr:last-child { border-bottom:none; }
.fh-table td { padding:9px 12px; color:var(--fh-text); vertical-align:middle; }

/* ── Status badges ── */
.fh-badge { display:inline-block; font-size:10px; font-weight:700; padding:2px 8px; border-radius:10px; letter-spacing:.04em; white-space:nowrap; }
.fh-badge-confirmed { background:rgba(26,154,80,.15); color:#40d080; border:1px solid rgba(26,154,80,.3); }
.fh-badge-cancelled { background:rgba(217,64,64,.12); color:#f07070; border:1px solid rgba(217,64,64,.3); }
.fh-badge-completed { background:rgba(4,157,225,.12); color:#7ecfef; border:1px solid var(--fh-border); }
.fh-badge-no_show   { background:rgba(212,160,23,.12); color:#ffc107; border:1px solid rgba(212,160,23,.3); }
.fh-badge-signed    { background:rgba(26,154,80,.15); color:#40d080; border:1px solid rgba(26,154,80,.3); }
.fh-badge-pending   { background:rgba(212,160,23,.12); color:#ffc107; border:1px solid rgba(212,160,23,.3); }
.fh-badge-online    { background:rgba(4,157,225,.12); color:#7ecfef; border:1px solid var(--fh-border); }
.fh-badge-onsite    { background:rgba(64,255,243,.08); color:var(--fh-teal); border:1px solid rgba(64,255,243,.2); }

/* ── Forms ── */
.fh-form-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.fh-form-grid.three { grid-template-columns:1fr 1fr 1fr; }
.fh-form-grid.full { grid-template-columns:1fr; }
@media(max-width:700px){ .fh-form-grid,.fh-form-grid.three{grid-template-columns:1fr;} }
.fh-field { display:flex; flex-direction:column; gap:5px; }
.fh-field label { font-size:11px; font-weight:700; color:var(--fh-muted); text-transform:uppercase; letter-spacing:.06em; }
.fh-field input,.fh-field select,.fh-field textarea {
    background:var(--fh-bg); border:1px solid var(--fh-border); color:var(--fh-text);
    border-radius:5px; padding:8px 11px; font-size:13px; font-family:inherit;
    transition:border-color .15s;
}
.fh-field input:focus,.fh-field select:focus,.fh-field textarea:focus { outline:none; border-color:var(--fh-blue); }
.fh-field input::placeholder,.fh-field textarea::placeholder { color:rgba(238,242,246,.3); }
.fh-field select option { background:#1f2937; color:var(--fh-text); }
.fh-field-span2 { grid-column:span 2; }
.fh-field-span3 { grid-column:span 3; }

/* ── Activity color dots ── */
.fh-dot { display:inline-block; width:10px; height:10px; border-radius:50%; margin-right:6px; flex-shrink:0; }

/* ── Calendar ── */
.fh-cal-wrap { overflow-x:auto; }
.fh-cal-controls { display:flex; align-items:center; gap:10px; margin-bottom:14px; flex-wrap:wrap; }
.fh-cal-title { font-size:16px; font-weight:700; color:var(--fh-text); min-width:180px; }
.fh-cal-view-toggle { display:flex; border:1px solid var(--fh-border); border-radius:6px; overflow:hidden; }
.fh-cal-view-toggle button { background:var(--fh-surface); color:var(--fh-muted); border:none; padding:6px 14px; font-size:12px; font-weight:600; cursor:pointer; transition:all .15s; }
.fh-cal-view-toggle button.active { background:var(--fh-blue); color:#fff; }

/* Week view */
.fh-week-table { width:100%; border-collapse:collapse; min-width:900px; }
.fh-week-table th { background:var(--fh-surface2); color:var(--fh-muted); font-size:11px; font-weight:700; letter-spacing:.08em; text-transform:uppercase; padding:10px 8px; border:1px solid var(--fh-border); text-align:center; min-width:130px; }
.fh-week-table th.today-hdr { background:rgba(4,157,225,.15); color:var(--fh-blue); }
.fh-week-table th.act-col { min-width:160px; text-align:left; padding-left:12px; color:var(--fh-blue); }
.fh-week-table td { border:1px solid rgba(255,255,255,.05); padding:4px; vertical-align:top; background:var(--fh-bg); min-height:60px; }
.fh-week-table td.today-col { background:rgba(4,157,225,.04); }
.fh-slot-cell { display:flex; flex-direction:column; gap:3px; }
.fh-slot-pill { border-radius:4px; padding:4px 7px; font-size:11px; cursor:pointer; transition:opacity .15s; border:1px solid rgba(255,255,255,.1); }
.fh-slot-pill:hover { opacity:.8; }
.fh-slot-pill .sp-time { font-weight:700; font-size:11px; }
.fh-slot-pill .sp-counts { font-size:10px; opacity:.85; margin-top:1px; }
.fh-slot-pill.full { opacity:.5; }

/* Month view */
.fh-month-grid { display:grid; grid-template-columns:repeat(7,1fr); gap:2px; }
.fh-month-day-hdr { background:var(--fh-surface2); text-align:center; font-size:10px; font-weight:700; color:var(--fh-muted); letter-spacing:.08em; text-transform:uppercase; padding:7px 0; border-radius:4px; }
.fh-month-day { background:var(--fh-surface); border:1px solid var(--fh-border); border-radius:5px; min-height:90px; padding:6px; }
.fh-month-day.other-month { opacity:.35; }
.fh-month-day.today { border-color:var(--fh-blue); background:rgba(4,157,225,.06); }
.fh-month-day-num { font-size:12px; font-weight:700; color:var(--fh-muted); margin-bottom:4px; }
.fh-month-day.today .fh-month-day-num { color:var(--fh-blue); }
.fh-month-event { border-radius:3px; padding:2px 5px; font-size:10px; font-weight:600; margin-bottom:2px; color:#fff; cursor:pointer; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }

/* ── Manifest ── */
.fh-manifest-hdr { display:flex; align-items:center; gap:10px; margin-bottom:16px; flex-wrap:wrap; }
.fh-manifest-card { background:var(--fh-surface); border:1px solid var(--fh-border); border-radius:8px; margin-bottom:16px; overflow:hidden; }
.fh-manifest-card-hdr { padding:12px 18px; display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap; }
.fh-manifest-activity { font-size:14px; font-weight:700; color:var(--fh-text); display:flex; align-items:center; gap:8px; }
.fh-manifest-meta { font-size:11px; color:var(--fh-muted); }

/* ── Notification ── */
.fh-toast { position:fixed; bottom:24px; right:24px; background:var(--fh-surface2); border:1px solid var(--fh-blue); border-radius:8px; padding:12px 18px; font-size:13px; color:var(--fh-text); z-index:99999; animation:fh-in .2s ease; box-shadow:0 4px 20px rgba(0,0,0,.4); }

/* ── Nuclear form dark theme — catches ALL fields on FairerHarbor pages ── */
body.wp-admin input[type="text"],body.wp-admin input[type="email"],body.wp-admin input[type="tel"],
body.wp-admin input[type="number"],body.wp-admin input[type="date"],body.wp-admin input[type="url"],
body.wp-admin input[type="search"],body.wp-admin input[type="password"],
body.wp-admin select,body.wp-admin textarea {
  background: var(--fh-bg) !important;
  border: 1px solid var(--fh-border) !important;
  color: var(--fh-text) !important;
  border-radius: 6px !important;
  box-shadow: none !important;
  -webkit-appearance: none !important;
}
body.wp-admin input[type="text"]:focus,body.wp-admin input[type="email"]:focus,
body.wp-admin input[type="tel"]:focus,body.wp-admin input[type="number"]:focus,
body.wp-admin input[type="date"]:focus,body.wp-admin input[type="url"]:focus,
body.wp-admin select:focus,body.wp-admin textarea:focus {
  border-color: var(--fh-blue) !important;
  outline: none !important;
  box-shadow: 0 0 0 1px var(--fh-blue) !important;
}
body.wp-admin input::placeholder,body.wp-admin textarea::placeholder { color: var(--fh-dim) !important; }
body.wp-admin select option { background: var(--fh-surface) !important; color: var(--fh-text) !important; }
input[type=date]::-webkit-calendar-picker-indicator { filter: invert(1); opacity: .6; cursor: pointer; }
/* Remove number spinners globally */
input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
input[type=number] { -moz-appearance: textfield; }

/* ── Global date picker click ── */

/* ── Full dark admin override ── */
#wpbody,#wpbody-content,#wpcontent,.wrap,#wpwrap{background:#111827!important;color:#eef2f6!important;}
#adminmenuback,#adminmenuwrap{background:#1a2535!important;}
#adminmenu,#adminmenu *{background:#1a2535!important;color:#aabfd4!important;}
#adminmenu li.current a.menu-top,#adminmenu li a.menu-top:hover{background:rgba(4,157,225,.15)!important;color:#fff!important;}
#adminmenu .wp-submenu{background:#060e18!important;}
#wpadminbar{background:#060e18!important;}
#wpadminbar *{color:#aabfd4!important;}
.wp-submenu li a{color:#aabfd4!important;}
.wp-submenu li.current a,.wp-submenu li a:hover{color:#049DE1!important;}
#wpfooter{background:#1a2535!important;border-top:1px solid rgba(4,157,225,.1)!important;color:#4a6070!important;}
#wpfooter a{color:#049DE1!important;}
</style>
<?php }

// ──────────────────────────────────────────────────────────────────
// 4. HELPER FUNCTIONS
// ──────────────────────────────────────────────────────────────────
function fh_confirmation_code() {
    return 'FH-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 8));
}

function fh_status_badge($status) {
    $labels = ['confirmed'=>'Confirmed','cancelled'=>'Cancelled','completed'=>'Completed','no_show'=>'No Show'];
    $label  = $labels[$status] ?? ucfirst($status);
    return '<span class="fh-badge fh-badge-' . esc_attr($status) . '">' . $label . '</span>';
}

function fh_waiver_badge($status) {
    $map = ['signed'=>'✓ Signed','pending'=>'Pending','exempt'=>'Exempt'];
    return '<span class="fh-badge fh-badge-' . esc_attr($status) . '">' . ($map[$status] ?? $status) . '</span>';
}

function fh_source_badge($source) {
    return '<span class="fh-badge fh-badge-' . esc_attr($source) . '">' . ucfirst($source) . '</span>';
}

function fh_get_booked_count($activity_id, $date, $time) {
    global $wpdb;
    return (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(party_size),0) FROM {$wpdb->prefix}fh_bookings
         WHERE activity_id=%d AND booking_date=%s AND booking_time=%s AND status != 'cancelled'",
        $activity_id, $date, $time
    ));
}

function fh_get_booking_count($activity_id, $date, $time) {
    global $wpdb;
    return (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}fh_bookings
         WHERE activity_id=%d AND booking_date=%s AND booking_time=%s AND status != 'cancelled'",
        $activity_id, $date, $time
    ));
}

function fh_send_confirmation($booking_id) {
    global $wpdb;
    $b = $wpdb->get_row($wpdb->prepare("SELECT b.*, a.name as activity_name, a.duration_min FROM {$wpdb->prefix}fh_bookings b JOIN {$wpdb->prefix}fh_activities a ON b.activity_id=a.id WHERE b.id=%d", $booking_id));
    if (!$b || !$b->guest_email) return;
    $subject = 'Booking Confirmed — ' . $b->activity_name . ' — Chena Hot Springs Resort';
    $body = '
    <html><body style="font-family:Arial,sans-serif;font-size:14px;color:#222;max-width:600px;">
    <div style="background:#111827;padding:20px 28px;">
      <h1 style="color:#fff;font-size:20px;margin:0;">Chena Hot Springs Resort</h1>
      <p style="color:#049DE1;margin:4px 0 0;font-size:13px;">Booking Confirmation</p>
    </div>
    <div style="padding:24px 28px;background:#fff;">
      <p>Dear ' . esc_html($b->guest_first_name ?: explode(' ',$b->guest_name.' ')[0]) . ',</p>
      <p>Your booking is confirmed! We look forward to seeing you.</p>
      <div style="background:#f5f8fa;border-left:4px solid #049DE1;padding:14px 18px;margin:18px 0;border-radius:0 6px 6px 0;">
        <p style="margin:0 0 6px;"><strong>Activity:</strong> ' . esc_html($b->activity_name) . '</p>
        <p style="margin:0 0 6px;"><strong>Date:</strong> ' . date('F j, Y', strtotime($b->booking_date)) . '</p>
        <p style="margin:0 0 6px;"><strong>Time:</strong> ' . date('g:i A', strtotime($b->booking_time)) . '</p>
        <p style="margin:0 0 6px;"><strong>Party Size:</strong> ' . $b->party_size . '</p>
        <p style="margin:0 0 6px;"><strong>Confirmation #:</strong> <strong>' . esc_html($b->confirmation_code) . '</strong></p>
        <p style="margin:0;"><strong>Total:</strong> $' . number_format($b->total_price, 2) . '</p>
      </div>
      <p>Please arrive 10–15 minutes before your scheduled time. Don\'t forget to sign your waiver if you haven\'t already.</p>
      <p style="margin-top:24px;"><strong>Chena Hot Springs Resort</strong><br>
      Mile 56.5 Chena Hot Springs Road<br>Fairbanks, AK 99712<br>(907) 451-8104</p>
    </div>
    <div style="background:#f0f4f8;padding:12px 28px;">
      <p style="font-size:11px;color:#888;margin:0;">Confirmation code: ' . esc_html($b->confirmation_code) . '</p>
    </div>
    </body></html>';
    wp_mail($b->guest_email, $subject, $body, ['Content-Type: text/html; charset=UTF-8']);
}

// ──────────────────────────────────────────────────────────────────
// 5. AJAX HANDLERS
// ──────────────────────────────────────────────────────────────────
add_action('wp_ajax_fh_get_slots',        'fh_ajax_get_slots');
add_action('wp_ajax_fh_save_booking',     'fh_ajax_save_booking');
add_action('wp_ajax_fh_update_status',    'fh_ajax_update_status');
add_action('wp_ajax_fh_delete_booking',   'fh_ajax_delete_booking');
add_action('wp_ajax_fh_save_activity',    'fh_ajax_save_activity');
add_action('wp_ajax_fh_delete_activity',  'fh_ajax_delete_activity');
add_action('wp_ajax_fh_get_calendar',     'fh_ajax_get_calendar');
add_action('wp_ajax_fh_slot_popup_data',   'fh_ajax_slot_popup_data');
add_action('wp_ajax_fh_update_booking',    'fh_ajax_update_booking');
add_action('wp_ajax_fh_resend_email',      'fh_ajax_resend_email');
add_action('wp_ajax_fh_save_upsell',       'fh_ajax_save_upsell');
add_action('wp_ajax_fh_delete_upsell',     'fh_ajax_delete_upsell');
add_action('wp_ajax_fh_save_field',        'fh_ajax_save_field');
add_action('wp_ajax_fh_delete_field',      'fh_ajax_delete_field');
add_action('wp_ajax_fh_get_activity_data',   'fh_ajax_get_activity_data');
add_action('wp_ajax_fh_save_addon',          'fh_ajax_save_addon');
add_action('wp_ajax_fh_delete_addon',        'fh_ajax_delete_addon');
add_action('wp_ajax_fh_get_addons',          'fh_ajax_get_addons');
add_action('wp_ajax_fh_save_settings',       'fh_ajax_save_settings');
add_action('wp_ajax_fh_install_update',      'fh_ajax_install_update');
add_action('wp_ajax_fh_send_waiver_link',    'fh_ajax_send_waiver_link');
add_action('wp_ajax_fh_get_guest_history',   'fh_ajax_get_guest_history');
add_action('wp_ajax_fh_update_payment',      'fh_ajax_update_payment');
add_action('wp_ajax_fh_save_slot_bookable',  'fh_ajax_save_slot_bookable');
add_action('wp_ajax_fh_save_slot_settings',   'fh_ajax_save_slot_settings');
add_action('wp_ajax_fh_get_booking_extras',   'fh_ajax_get_booking_extras');
add_action('wp_ajax_nopriv_fh_get_booking_extras','fh_ajax_get_booking_extras');
add_action('wp_ajax_fh_checkin_guest',        'fh_ajax_checkin_guest');

function fh_ajax_slot_popup_data() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('view_chena_waivers')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $act_id  = (int)$_POST['activity_id'];
    $date    = sanitize_text_field($_POST['date']);
    $time    = sanitize_text_field($_POST['time']);
    $slot_id = (int)$_POST['slot_id'];
    $act     = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_activities WHERE id=%d",$act_id));
    if (!$act) wp_send_json_error('Not found');
    // Check for capacity override
    $ov = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_slot_overrides WHERE slot_id=%d AND override_date=%s",$slot_id,$date));
    $cap_use = ($ov && $ov->capacity !== null) ? (int)$ov->capacity : (int)$act->capacity;
    $booked  = fh_get_booked_count($act_id,$date,$time);
    $avail   = $cap_use - $booked;
    $guests  = $wpdb->get_results($wpdb->prepare(
        "SELECT id,guest_name,party_size,status,waiver_status,adults,children FROM {$wpdb->prefix}fh_bookings
         WHERE activity_id=%d AND booking_date=%s AND booking_time=%s AND status!='cancelled'
         ORDER BY id ASC LIMIT 15",
        $act_id,$date,$time
    ));
    $guest_html = '';
    foreach ($guests as $g) {
        $ws = $g->waiver_status==='signed' ? '<span style="color:#40d080;font-size:10px;">✓ Waiver</span>' : '<span style="color:#ffc107;font-size:10px;">⚠ Waiver</span>';
        $guest_html .= '<div style="display:flex;align-items:center;justify-content:space-between;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05);">';
        $guest_html .= '<span style="font-size:12px;color:#eef2f6;">'.esc_html($g->guest_name).'</span>';
        $guest_html .= '<span style="display:flex;align-items:center;gap:8px;">'.$ws.'<span style="font-size:11px;color:#aabfd4;">×'.$g->party_size.'</span>';
        $guest_html .= '<select onchange="fhUpdateStatusInline('.$g->id.',this.value)" style="background:#111827;border:1px solid rgba(4,157,225,.3);color:#eef2f6;border-radius:4px;padding:2px 5px;font-size:10px;">';
        foreach (['confirmed'=>'Confirmed','completed'=>'Completed ✓','no_show'=>'No Show','cancelled'=>'Cancelled'] as $v=>$l) {
            $sel = $g->status===$v?' selected':'';
            $guest_html .= '<option value="'.$v.'"'.$sel.'>'.$l.'</option>';
        }
        $guest_html .= '</select></span></div>';
    }
    // Get active bookings for this slot
    $bookings = $wpdb->get_results($wpdb->prepare(
        "SELECT id,guest_name,confirmation_code,party_size,booking_source,payment_status,status
         FROM {$wpdb->prefix}fh_bookings
         WHERE activity_id=%d AND booking_date=%s AND booking_time=%s AND status!='cancelled'
         ORDER BY id ASC LIMIT 20",
        $act_id,$date,$time
    ));
    $cancelled = $wpdb->get_results($wpdb->prepare(
        "SELECT id,guest_name,confirmation_code,party_size,status
         FROM {$wpdb->prefix}fh_bookings
         WHERE activity_id=%d AND booking_date=%s AND booking_time=%s AND status IN('cancelled','no_show')
         ORDER BY id ASC LIMIT 10",
        $act_id,$date,$time
    ));
    wp_send_json_success([
        'activity'  => $act->name,
        'color'     => $act->color,
        'booked'    => $booked,
        'available' => $avail,
        'capacity'  => $cap_use,
        'bookings'  => $bookings,
        'cancelled' => $cancelled,
    ]);
}

function fh_ajax_get_slots() {
    check_ajax_referer('fh_nonce','nonce');
    global $wpdb;
    $activity_id = (int)$_POST['activity_id'];
    $date        = sanitize_text_field($_POST['date']);
    $activity    = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_activities WHERE id=%d", $activity_id));
    if (!$activity) wp_send_json_error('Activity not found');
    $dow   = date('w', strtotime($date));
    $slots = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}fh_slots WHERE activity_id=%d AND active=1 ORDER BY slot_time ASC", $activity_id
    ));
    $out = [];
    foreach ($slots as $s) {
        $days = explode(',', $s->days_of_week);
        if (!in_array($dow, $days)) continue;
        $booked = fh_get_booked_count($activity_id, $date, $s->slot_time);
        $avail  = $activity->capacity - $booked;
        $out[]  = ['id'=>$s->id,'time'=>date('g:i A',strtotime($s->slot_time)),'time_raw'=>$s->slot_time,'available'=>$avail,'capacity'=>$activity->capacity,'booked'=>$booked];
    }
    wp_send_json_success($out);
}

function fh_ajax_save_booking() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('view_chena_waivers')) wp_send_json_error('Unauthorized');
    global $wpdb;

    $activity_id = (int)$_POST['activity_id'];
    $slot_id     = (int)$_POST['slot_id'];
    $date        = sanitize_text_field($_POST['booking_date']);
    $time        = sanitize_text_field($_POST['booking_time']);
    $first_name  = sanitize_text_field($_POST['guest_first_name'] ?? '');
    $last_name   = sanitize_text_field($_POST['guest_last_name'] ?? '');
    $name        = $first_name && $last_name ? $first_name.' '.$last_name : sanitize_text_field($_POST['guest_name'] ?? '');
    if (!$name && $first_name) $name = $first_name;
    $email       = sanitize_email($_POST['guest_email']);
    $phone       = sanitize_text_field($_POST['guest_phone'] ?? '');
    $adults      = max(0,(int)$_POST['adults']);
    $children    = max(0,(int)$_POST['children']);
    $party_size  = $adults + $children;
    $price_type  = sanitize_text_field($_POST['price_type'] ?? 'adult');
    $total       = floatval($_POST['total_price'] ?? 0);
    $source      = sanitize_text_field($_POST['booking_source'] ?? 'onsite');
    $notes       = sanitize_textarea_field($_POST['notes'] ?? '');
    $guide       = sanitize_text_field($_POST['guide_name'] ?? '');
    $send_email  = !empty($_POST['guest_email']) || !empty($_POST['send_email']); // auto-send if email present

    if (!$activity_id||!$date||!$name||$party_size<1) wp_send_json_error('Missing required fields');

    $activity = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_activities WHERE id=%d", $activity_id));
    if (!$activity) wp_send_json_error('Activity not found');

    $booked = fh_get_booked_count($activity_id, $date, $time);
    if ($booked + $party_size > $activity->capacity) wp_send_json_error('Not enough capacity. Only ' . ($activity->capacity - $booked) . ' spots remaining.');

    $code = fh_confirmation_code();
    $wpdb->insert("{$wpdb->prefix}fh_bookings", [
        'activity_id'=>$activity_id,'slot_id'=>$slot_id,'booking_date'=>$date,'booking_time'=>$time,
        'guest_name'=>$name,'guest_first_name'=>$first_name,'guest_last_name'=>$last_name,
        'guest_email'=>$email,'guest_phone'=>$phone,
        'party_size'=>$party_size,'adults'=>$adults,'children'=>$children,
        'price_type'=>$price_type,'total_price'=>$total,'status'=>'confirmed',
        'booking_source'=>$source,'notes'=>$notes,'guide_name'=>$guide,
        'confirmation_code'=>$code,
    ], ['%d','%d','%s','%s','%s','%s','%s','%s','%s','%d','%d','%d','%s','%f','%s','%s','%s','%s','%s']);

    $booking_id = $wpdb->insert_id;
    if ($send_email && $email) fh_send_confirmation($booking_id);

    wp_send_json_success(['id'=>$booking_id,'code'=>$code,'message'=>'Booking confirmed! Code: '.$code]);
}

function fh_ajax_update_status() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('view_chena_waivers')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $id     = (int)$_POST['id'];
    $status = sanitize_text_field($_POST['status']);
    $allowed = ['confirmed','cancelled','no_show','completed'];
    if (!in_array($status,$allowed)) wp_send_json_error('Invalid status');
    $wpdb->update("{$wpdb->prefix}fh_bookings",['status'=>$status],['id'=>$id],['%s'],['%d']);
    wp_send_json_success();
}

function fh_ajax_delete_booking() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $wpdb->delete("{$wpdb->prefix}fh_bookings",['id'=>(int)$_POST['id']],['%d']);
    wp_send_json_success();
}

function fh_ajax_save_activity() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $id   = (int)($_POST['id'] ?? 0);
    $data = [
        'name'         => sanitize_text_field($_POST['name']),
        'description'  => sanitize_textarea_field($_POST['description'] ?? ''),
        'color'        => sanitize_hex_color($_POST['color'] ?? '#049DE1'),
        'duration_min' => (int)$_POST['duration_min'],
        'capacity'     => (int)$_POST['capacity'],
        'price_adult'  => floatval($_POST['price_adult']),
        'price_child'  => floatval($_POST['price_child']),
        'price_group'  => floatval($_POST['price_group']),
        'group_min'    => (int)$_POST['group_min'],
        'season_start' => sanitize_text_field($_POST['season_start'] ?? '') ?: null,
        'season_end'   => sanitize_text_field($_POST['season_end'] ?? '') ?: null,
        'active'       => (int)($_POST['active'] ?? 1),
    ];
    $fmt = ['%s','%s','%s','%d','%d','%f','%f','%f','%d','%s','%s','%d'];
    if ($id) {
        $wpdb->update("{$wpdb->prefix}fh_activities",$data,['id'=>$id],$fmt,['%d']);
    } else {
        $wpdb->insert("{$wpdb->prefix}fh_activities",$data,$fmt);
        $id = $wpdb->insert_id;
    }
    // Save time slots
    if (isset($_POST['slots']) && is_array($_POST['slots'])) {
        $wpdb->delete("{$wpdb->prefix}fh_slots",['activity_id'=>$id],['%d']);
        foreach ($_POST['slots'] as $slot) {
            $t = sanitize_text_field($slot['time'] ?? '');
            $d = sanitize_text_field($slot['days'] ?? '0,1,2,3,4,5,6');
            if ($t) $wpdb->insert("{$wpdb->prefix}fh_slots",['activity_id'=>$id,'slot_time'=>$t,'days_of_week'=>$d],['%d','%s','%s']);
        }
    }
    wp_send_json_success(['id'=>$id]);
}

function fh_ajax_delete_activity() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $id = (int)$_POST['id'];
    $wpdb->delete("{$wpdb->prefix}fh_activities",['id'=>$id],['%d']);
    $wpdb->delete("{$wpdb->prefix}fh_slots",['activity_id'=>$id],['%d']);
    wp_send_json_success();
}

// ──────────────────────────────────────────────────────────────────
// 6. DASHBOARD PAGE
// ──────────────────────────────────────────────────────────────────

// ── Add-on AJAX handlers ─────────────────────────────────────────
function fh_ajax_save_addon() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $id   = (int)($_POST['id']??0);
    $data = [
        'name'        => sanitize_text_field($_POST['name']??''),
        'description' => sanitize_textarea_field($_POST['description']??''),
        'photo_url'   => esc_url_raw($_POST['photo_url']??''),
        'price'       => floatval($_POST['price']??0),
        'tax_rate'    => floatval($_POST['tax_rate']??0),
        'fee_type'    => sanitize_text_field($_POST['fee_type']??'flat'),
        'fee_amount'  => floatval($_POST['fee_amount']??0),
        'price_type'  => sanitize_text_field($_POST['price_type']??'per_person'),
        'active'      => (int)($_POST['active']??1),
    ];
    $fmt = ['%s','%s','%s','%f','%f','%s','%f','%s','%d'];
    $t   = $wpdb->prefix.'fh_addons';
    if ($id) {
        $wpdb->update($t,$data,['id'=>$id],$fmt,['%d']);
    } else {
        $wpdb->insert($t,$data,$fmt);
        $id = $wpdb->insert_id;
    }
    // Save activity links
    if (isset($_POST['activity_ids'])) {
        $at = $wpdb->prefix.'fh_activity_addons';
        $wpdb->delete($at,['addon_id'=>$id],['%d']);
        foreach ((array)$_POST['activity_ids'] as $aid) {
            $aid = (int)$aid;
            if ($aid) $wpdb->insert($at,['activity_id'=>$aid,'addon_id'=>$id],['%d','%d']);
        }
    }
    wp_send_json_success(['id'=>$id,'message'=>'Add-on saved.']);
}

function fh_ajax_delete_addon() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $id = (int)$_POST['id'];
    $wpdb->delete($wpdb->prefix.'fh_addons',['id'=>$id],['%d']);
    $wpdb->delete($wpdb->prefix.'fh_activity_addons',['addon_id'=>$id],['%d']);
    wp_send_json_success();
}

function fh_ajax_get_addons() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $act_id = (int)($_POST['activity_id']??0);
    if ($act_id) {
        $addons = $wpdb->get_results($wpdb->prepare(
            "SELECT a.* FROM {$wpdb->prefix}fh_addons a
             JOIN {$wpdb->prefix}fh_activity_addons aa ON a.id=aa.addon_id
             WHERE aa.activity_id=%d AND a.active=1 ORDER BY a.sort_order,a.name", $act_id));
    } else {
        $addons = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}fh_addons ORDER BY sort_order,name");
    }
    // Add linked activity IDs to each addon for edit modal pre-selection
    foreach ($addons as &$addon) {
        $addon->linked_activity_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT activity_id FROM {$wpdb->prefix}fh_activity_addons WHERE addon_id=%d", $addon->id
        ));
    }
    wp_send_json_success($addons);
}

// ── Settings AJAX ────────────────────────────────────────────────
function fh_ajax_save_settings() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $t = $wpdb->prefix.'fh_settings';
    $allowed = ['resort_name','resort_address','resort_phone','resort_email','resort_url',
                'timezone','min_advance_hours','max_advance_days','default_source',
                'require_phone','allow_children','email_from_name','email_from_address',
                'email_bcc','email_subject','email_footer','notify_staff_email',
                'waiver_version','waiver_expiry_days','require_waiver_checkin',
                'payment_methods','default_tax_rate','currency',
                'cancel_window_hours','cancel_fee_type','cancel_fee_amount','noshow_fee'];
    foreach ($allowed as $key) {
        if (isset($_POST[$key])) {
            $val = sanitize_text_field($_POST[$key]);
            $wpdb->replace($t,['setting_key'=>$key,'setting_value'=>$val],['%s','%s']);
        }
    }
    wp_send_json_success(['message'=>'Settings saved.']);
}

function fh_ajax_install_update() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    $url = esc_url_raw($_POST['update_url'] ?? '');
    if (!$url) wp_send_json_error('No update URL provided.');
    if (!filter_var($url, FILTER_VALIDATE_URL)) wp_send_json_error('Invalid URL.');
    // Download the zip
    require_once ABSPATH.'wp-admin/includes/file.php';
    require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';
    require_once ABSPATH.'wp-admin/includes/misc.php';
    WP_Filesystem();
    $tmp = download_url($url, 30);
    if (is_wp_error($tmp)) wp_send_json_error('Download failed: '.$tmp->get_error_message());
    // Install
    $upgrader = new Plugin_Upgrader(new WP_Ajax_Upgrader_Skin());
    $result = $upgrader->install($tmp, ['overwrite_package' => true]);
    @unlink($tmp);
    if (is_wp_error($result)) wp_send_json_error('Install failed: '.$result->get_error_message());
    if ($result === false) wp_send_json_error('Install failed — could not overwrite plugin files.');
    // Reactivate
    $plugin_file = 'farerharbor/farerharbor.php';
    if (!is_plugin_active($plugin_file)) activate_plugin($plugin_file);
    wp_send_json_success(['message' => 'FairerHarbor updated successfully!']);
}

function fh_get_setting($key, $default='') {
    global $wpdb;
    $val = $wpdb->get_var($wpdb->prepare("SELECT setting_value FROM {$wpdb->prefix}fh_settings WHERE setting_key=%s",$key));
    return $val !== null ? $val : $default;
}

// ── Send waiver link ─────────────────────────────────────────────
function fh_ajax_send_waiver_link() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('view_chena_waivers')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $booking_id  = (int)$_POST['booking_id'];
    $guest_name  = sanitize_text_field($_POST['guest_name']??'');
    $guest_email = sanitize_email($_POST['guest_email']??'');
    if (!$guest_email) wp_send_json_error('No email address for this guest.');
    $booking = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_bookings WHERE id=%d",$booking_id));
    if (!$booking) wp_send_json_error('Booking not found.');
    // Generate waiver token
    $token = wp_generate_password(32,false);
    $t     = $wpdb->prefix.'fh_guest_waivers';
    $existing = $wpdb->get_row($wpdb->prepare("SELECT id FROM $t WHERE booking_id=%d AND guest_name=%s",$booking_id,$guest_name));
    if ($existing) {
        $wpdb->update($t,['waiver_token'=>$token,'sent_at'=>current_time('mysql')],['id'=>$existing->id],['%s','%s'],['%d']);
    } else {
        $wpdb->insert($t,['booking_id'=>$booking_id,'guest_name'=>$guest_name,'guest_email'=>$guest_email,'waiver_token'=>$token,'status'=>'pending','sent_at'=>current_time('mysql')],['%d','%s','%s','%s','%s','%s']);
    }
    $waiver_url = home_url('/waivers/?token='.$token.'&booking='.$booking_id.'&guest='.urlencode($guest_name));
    $resort_name = fh_get_setting('resort_name','Chena Hot Springs Resort');
    $act = $wpdb->get_row($wpdb->prepare("SELECT name FROM {$wpdb->prefix}fh_activities WHERE id=%d",$booking->activity_id));
    $subject = 'Please sign your waiver — '.($act?$act->name:'Tour');
    $body = '<p>Hi '.esc_html(explode(' ',$guest_name.' ')[0]).',</p>'
           .'<p>You have an upcoming booking for <strong>'.($act?esc_html($act->name):'your tour').'</strong> on '.date('l, F j, Y',strtotime($booking->booking_date)).'.</p>'
           .'<p>Please sign your waiver before arriving:</p>'
           .'<p><a href="'.esc_url($waiver_url).'" style="background:#049DE1;color:#fff;padding:12px 24px;border-radius:6px;text-decoration:none;font-weight:bold;">Sign Waiver →</a></p>'
           .'<p>This link is unique to you. If you have questions call us at '.fh_get_setting('resort_phone','907-451-8104').'</p>'
           .'<p>'.esc_html($resort_name).'</p>';
    $headers = ['Content-Type: text/html; charset=UTF-8','From: '.(fh_get_setting('email_from_name',$resort_name)).' <'.(fh_get_setting('email_from_address','noreply@chenahotsprings.com')).'>'];
    wp_mail($guest_email,$subject,$body,$headers);
    wp_send_json_success(['message'=>'Waiver link sent to '.$guest_email]);
}

// ──────────────────────────────────────────────────────────────────
// V7 DASHBOARD — redesigned with KPIs, schedule, alerts, chart
// ──────────────────────────────────────────────────────────────────
function fh_dashboard_page() {
    global $wpdb;
    $today      = date('Y-m-d');
    $t_book     = $wpdb->prefix.'fh_bookings';
    $t_act      = $wpdb->prefix.'fh_activities';

    // KPI data
    $today_bookings = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t_book WHERE booking_date=%s AND status!='cancelled'",$today));
    $today_guests   = (int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(party_size),0) FROM $t_book WHERE booking_date=%s AND status!='cancelled'",$today));
    $week_end       = date('Y-m-d', strtotime('+6 days'));
    $week_bookings  = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t_book WHERE booking_date BETWEEN %s AND %s AND status!='cancelled'",$today,$week_end));
    $week_guests    = (int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(party_size),0) FROM $t_book WHERE booking_date BETWEEN %s AND %s AND status!='cancelled'",$today,$week_end));
    $pending_waivers= (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t_book WHERE booking_date>=%s AND status!='cancelled' AND waiver_status='pending'",$today));
    $active_tours   = (int)$wpdb->get_var("SELECT COUNT(*) FROM $t_act WHERE active=1");

    // Today's schedule
    $today_groups = [];
    $today_bks = $wpdb->get_results($wpdb->prepare(
        "SELECT b.*,a.name as act_name,a.color,a.capacity FROM $t_book b JOIN $t_act a ON b.activity_id=a.id
         WHERE b.booking_date=%s AND b.status!='cancelled' ORDER BY b.booking_time,a.name",$today));
    foreach ($today_bks as $b) {
        $k = $b->activity_id.'|'.$b->booking_time;
        if (!isset($today_groups[$k])) $today_groups[$k] = ['name'=>$b->act_name,'color'=>$b->color,'time'=>$b->booking_time,'capacity'=>$b->capacity,'guests'=>0,'bookings'=>0,'act_id'=>$b->activity_id];
        $today_groups[$k]['guests']   += $b->party_size;
        $today_groups[$k]['bookings'] += 1;
    }

    // 7-day chart data
    $chart_data = [];
    for ($i=0;$i<7;$i++) {
        $d = date('Y-m-d',strtotime("+$i days"));
        $g = (int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(party_size),0) FROM $t_book WHERE booking_date=%s AND status!='cancelled'",$d));
        $chart_data[] = ['date'=>date('M j',strtotime($d)),'guests'=>$g,'day'=>$i===0?'Today':date('D',strtotime($d))];
    }

    // Pending waiver bookings
    $waiver_bks = $wpdb->get_results($wpdb->prepare(
        "SELECT b.*,a.name as act_name,a.color FROM $t_book b JOIN $t_act a ON b.activity_id=a.id
         WHERE b.booking_date>=%s AND b.status!='cancelled' AND b.waiver_status='pending'
         ORDER BY b.booking_date,b.booking_time LIMIT 8",$today));

    // Recent bookings
    $recent_bks = $wpdb->get_results(
        "SELECT b.*,a.name as act_name,a.color FROM $t_book b JOIN $t_act a ON b.activity_id=a.id
         ORDER BY b.id DESC LIMIT 8");

    // Low capacity alerts (next 7 days, >75% full)
    $low_cap = [];
    $slots = $wpdb->get_results("SELECT s.*,a.name as act_name,a.color,a.capacity FROM {$wpdb->prefix}fh_slots s JOIN $t_act a ON s.activity_id=a.id WHERE a.active=1 AND s.active=1");
    for ($i=1;$i<=7;$i++) {
        $d = date('Y-m-d',strtotime("+$i days"));
        $dow = date('w',strtotime($d));
        foreach ($slots as $s) {
            $days = explode(',',$s->days_of_week);
            if (!in_array($dow,$days)) continue;
            $booked = fh_get_booked_count($s->activity_id,$d,$s->slot_time);
            $pct = $s->capacity > 0 ? ($booked/$s->capacity)*100 : 0;
            if ($pct >= 75 && $booked > 0) {
                $low_cap[] = ['name'=>$s->act_name,'color'=>$s->color,'date'=>date('M j',strtotime($d)),'time'=>date('g:i A',strtotime($s->slot_time)),'booked'=>$booked,'cap'=>$s->capacity,'pct'=>round($pct)];
            }
        }
    }
    usort($low_cap,function($a,$b){return $b['pct']-$a['pct'];});
    $low_cap = array_slice($low_cap,0,5);

    fh_styles(); ?>
    <style>
    .fh7-kpi-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin-bottom:22px;}
    @media(max-width:900px){.fh7-kpi-grid{grid-template-columns:repeat(3,1fr);}}
    .fh7-kpi{background:var(--fh-surface);border:1px solid var(--fh-border);border-radius:10px;padding:16px 18px;position:relative;overflow:hidden;transition:border-color .15s;}
    .fh7-kpi:hover{border-color:var(--fh-blue);}
    .fh7-kpi-lbl{font-size:10px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--fh-muted);margin-bottom:8px;}
    .fh7-kpi-val{font-size:32px;font-weight:800;line-height:1;color:var(--fh-text);}
    .fh7-kpi-sub{font-size:11px;color:var(--fh-dim);margin-top:4px;}
    .fh7-kpi-accent{position:absolute;bottom:0;left:0;right:0;height:3px;border-radius:0 0 10px 10px;}
    .fh7-grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;}
    @media(max-width:800px){.fh7-grid2{grid-template-columns:1fr;}}
    .fh7-section-title{font-size:11px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--fh-blue);margin-bottom:12px;display:flex;align-items:center;justify-content:space-between;}
    .fh7-schedule-row{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-radius:7px;background:var(--fh-bg);border:1px solid var(--fh-border);margin-bottom:6px;transition:border-color .15s;}
    .fh7-schedule-row:hover{border-color:var(--fh-blue);}
    .fh7-alert-row{display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:7px;background:rgba(240,119,119,.06);border:1px solid rgba(240,119,119,.2);margin-bottom:6px;}
    .fh7-alert-icon{width:8px;height:8px;border-radius:50%;background:#f07777;flex-shrink:0;animation:fhv-pulse 2s infinite;}
    .fh7-recent-row{display:grid;grid-template-columns:auto 1fr auto auto;gap:10px;align-items:center;padding:9px 14px;border-radius:7px;background:var(--fh-bg);border:1px solid var(--fh-border);margin-bottom:5px;}
    /* Bar chart */
    .fh7-chart{display:flex;align-items:flex-end;gap:6px;height:80px;padding:0 4px;}
    .fh7-bar-wrap{flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;}
    .fh7-bar{width:100%;background:var(--fh-blue);border-radius:4px 4px 0 0;min-height:3px;transition:height .3s;}
    .fh7-bar-lbl{font-size:9px;color:var(--fh-muted);text-align:center;font-weight:600;letter-spacing:.04em;}
    .fh7-bar-val{font-size:9px;color:var(--fh-teal);font-weight:700;}
    .fh7-cap-bar{height:6px;background:var(--fh-surface2);border-radius:3px;overflow:hidden;flex:1;}
    .fh7-cap-fill{height:100%;border-radius:3px;transition:width .3s;}
    </style>

    <div class="wrap"><div class="fh-wrap">
      <div class="fh-topbar">
        <img src="https://www.chenahotsprings.com/wp-content/uploads/2025/12/Chene-Hotsprings-Logo-scaled.webp" class="fh-topbar-logo" onerror="this.style.display='none'">
        <div class="fh-topbar-divider"></div>
        <div class="fh-topbar-title">Dashboard</div>
        <div class="fh-spacer"></div>
        <span style="font-size:13px;color:var(--fh-muted);"><?php echo date('l, F j, Y'); ?></span>
        <a href="<?php echo admin_url('admin.php?page=farerharbor-manifests&date='.date('Y-m-d')); ?>" class="fh-btn fh-btn-ghost">📋 Today's Manifests</a>
        <a href="<?php echo admin_url('admin.php?page=farerharbor-calendar'); ?>" class="fh-btn fh-btn-primary">📅 Calendar</a>
      </div>

      <!-- KPI Row -->
      <div class="fh7-kpi-grid" style="margin-top:18px;">
        <div class="fh7-kpi">
          <div class="fh7-kpi-lbl">Today's Bookings</div>
          <div class="fh7-kpi-val" style="color:var(--fh-blue);"><?php echo $today_bookings; ?></div>
          <div class="fh7-kpi-sub"><?php echo $today_guests; ?> guests today</div>
          <div class="fh7-kpi-accent" style="background:var(--fh-blue);"></div>
        </div>
        <div class="fh7-kpi">
          <div class="fh7-kpi-lbl">Next 7 Days</div>
          <div class="fh7-kpi-val" style="color:var(--fh-teal);"><?php echo $week_bookings; ?></div>
          <div class="fh7-kpi-sub"><?php echo $week_guests; ?> guests upcoming</div>
          <div class="fh7-kpi-accent" style="background:var(--fh-teal);"></div>
        </div>
        <div class="fh7-kpi">
          <div class="fh7-kpi-lbl">Pending Waivers</div>
          <div class="fh7-kpi-val" style="color:<?php echo $pending_waivers>0?'#ffc107':'#40d080'; ?>;"><?php echo $pending_waivers; ?></div>
          <div class="fh7-kpi-sub"><?php echo $pending_waivers>0?'Guests need to sign':'All waivers signed ✓'; ?></div>
          <div class="fh7-kpi-accent" style="background:<?php echo $pending_waivers>0?'#ffc107':'#40d080'; ?>;"></div>
        </div>
        <div class="fh7-kpi">
          <div class="fh7-kpi-lbl">Active Tours</div>
          <div class="fh7-kpi-val"><?php echo $active_tours; ?></div>
          <div class="fh7-kpi-sub">Activities running</div>
          <div class="fh7-kpi-accent" style="background:#a78bfa;"></div>
        </div>
        <div class="fh7-kpi">
          <div class="fh7-kpi-lbl">7-Day Guests</div>
          <div class="fh7-kpi-val" style="color:#40d080;"><?php echo $week_guests; ?></div>
          <div class="fh7-kpi-sub">Confirmed bookings</div>
          <div class="fh7-kpi-accent" style="background:#40d080;"></div>
        </div>
      </div>

      <div class="fh7-grid2">

        <!-- Today's Schedule -->
        <div>
          <div class="fh-card">
            <div class="fh-card-hdr" style="display:flex;align-items:center;justify-content:space-between;">
              <span>📅 Today's Schedule</span>
              <a href="<?php echo admin_url('admin.php?page=farerharbor-manifests&date='.date('Y-m-d')); ?>" style="font-size:11px;color:var(--fh-blue);text-decoration:none;">View all →</a>
            </div>
            <div class="fh-card-body">
              <?php if (empty($today_groups)): ?>
              <div style="text-align:center;padding:20px;color:var(--fh-dim);font-size:13px;">No bookings today.</div>
              <?php else: foreach ($today_groups as $g): $util = $g['capacity']>0?round(($g['guests']/$g['capacity'])*100):0; ?>
              <div class="fh7-schedule-row">
                <div style="display:flex;align-items:center;gap:8px;">
                  <span style="width:10px;height:10px;border-radius:50%;background:<?php echo esc_attr($g['color']); ?>;flex-shrink:0;"></span>
                  <div>
                    <div style="font-size:13px;font-weight:700;color:var(--fh-text);"><?php echo esc_html($g['name']); ?></div>
                    <div style="font-size:11px;color:var(--fh-muted);"><?php echo date('g:i A',strtotime($g['time'])); ?> &nbsp;·&nbsp; <?php echo $g['bookings']; ?> booking<?php echo $g['bookings']!=1?'s':''; ?></div>
                  </div>
                </div>
                <div style="text-align:right;">
                  <div style="font-size:13px;font-weight:700;color:<?php echo $util>=90?'#f07777':($util>=70?'#ffc107':'#40d080'); ?>"><?php echo $g['guests']; ?>/<?php echo $g['capacity']; ?></div>
                  <div style="font-size:10px;color:var(--fh-muted);"><?php echo $util; ?>% full</div>
                </div>
              </div>
              <?php endforeach; endif; ?>
            </div>
          </div>

          <!-- 7-Day Chart -->
          <div class="fh-card" style="margin-top:14px;">
            <div class="fh-card-hdr">📊 Guests — Next 7 Days</div>
            <div class="fh-card-body">
              <?php $max = max(1,max(array_column($chart_data,'guests'))); ?>
              <div class="fh7-chart">
                <?php foreach ($chart_data as $cd): ?>
                <div class="fh7-bar-wrap">
                  <div class="fh7-bar-val"><?php echo $cd['guests']>0?$cd['guests']:''; ?></div>
                  <div class="fh7-bar" style="height:<?php echo round(($cd['guests']/$max)*64); ?>px;background:<?php echo $cd['day']==='Today'?'var(--fh-teal)':'var(--fh-blue)'; ?>;opacity:<?php echo $cd['day']==='Today'?'1':'.6'; ?>;"></div>
                  <div class="fh7-bar-lbl"><?php echo $cd['day']; ?></div>
                </div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
        </div>

        <!-- Right column -->
        <div>
          <!-- Pending Waivers Alert -->
          <?php if ($pending_waivers > 0): ?>
          <div class="fh-card" style="border-color:rgba(255,193,7,.3);margin-bottom:14px;">
            <div class="fh-card-hdr" style="color:#ffc107;border-bottom-color:rgba(255,193,7,.2);">⚠ Pending Waivers (<?php echo $pending_waivers; ?>)</div>
            <div class="fh-card-body">
              <?php foreach ($waiver_bks as $b): ?>
              <div class="fh7-alert-row">
                <div class="fh7-alert-icon"></div>
                <div style="flex:1;">
                  <div style="font-size:12px;font-weight:700;color:var(--fh-text);"><?php echo esc_html($b->guest_name); ?></div>
                  <div style="font-size:11px;color:var(--fh-muted);"><?php echo esc_html($b->act_name); ?> · <?php echo date('M j',strtotime($b->booking_date)); ?></div>
                </div>
                <a href="<?php echo admin_url('admin.php?page=farerharbor-manifests&date='.$b->booking_date); ?>" style="font-size:11px;color:var(--fh-blue);text-decoration:none;">View →</a>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endif; ?>

          <!-- Low Capacity Alerts -->
          <?php if (!empty($low_cap)): ?>
          <div class="fh-card" style="margin-bottom:14px;">
            <div class="fh-card-hdr">🔥 Nearly Full — Next 7 Days</div>
            <div class="fh-card-body">
              <?php foreach ($low_cap as $lc): ?>
              <div style="margin-bottom:10px;">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
                  <div style="display:flex;align-items:center;gap:6px;">
                    <span style="width:8px;height:8px;border-radius:50%;background:<?php echo esc_attr($lc['color']); ?>;"></span>
                    <span style="font-size:12px;font-weight:600;color:var(--fh-text);"><?php echo esc_html($lc['name']); ?></span>
                    <span style="font-size:11px;color:var(--fh-muted);"><?php echo $lc['date'].' · '.$lc['time']; ?></span>
                  </div>
                  <span style="font-size:12px;font-weight:700;color:<?php echo $lc['pct']>=100?'#f07777':'#ffc107'; ?>;"><?php echo $lc['pct']; ?>%</span>
                </div>
                <div class="fh7-cap-bar"><div class="fh7-cap-fill" style="width:<?php echo min(100,$lc['pct']); ?>%;background:<?php echo $lc['pct']>=100?'#f07777':'#ffc107'; ?>;"></div></div>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endif; ?>

          <!-- Recent Bookings -->
          <div class="fh-card">
            <div class="fh-card-hdr">🕐 Recent Bookings</div>
            <div class="fh-card-body">
              <?php foreach ($recent_bks as $b): ?>
              <div class="fh7-recent-row">
                <span style="width:8px;height:8px;border-radius:50%;background:<?php echo esc_attr($b->color); ?>;"></span>
                <div>
                  <div style="font-size:12px;font-weight:700;color:var(--fh-text);"><?php echo esc_html($b->guest_name); ?></div>
                  <div style="font-size:11px;color:var(--fh-muted);"><?php echo esc_html($b->act_name); ?> · <?php echo date('M j',strtotime($b->booking_date)); ?></div>
                </div>
                <span style="font-size:11px;color:var(--fh-teal);font-weight:700;">$<?php echo number_format($b->total_price,2); ?></span>
                <a href="<?php echo admin_url('admin.php?page=farerharbor-manifests&date='.$b->booking_date); ?>" style="font-size:11px;color:var(--fh-blue);text-decoration:none;">→</a>
              </div>
              <?php endforeach; ?>
              <?php if (empty($recent_bks)): ?><div style="text-align:center;padding:16px;color:var(--fh-dim);font-size:13px;">No bookings yet.</div><?php endif; ?>
            </div>
          </div>
        </div>
      </div>

    </div></div>
    <?php fh_admin_js(); ?>
    <?php
}

// ──────────────────────────────────────────────────────────────────
// V7 ADD-ONS PAGE — product catalog
// ──────────────────────────────────────────────────────────────────
function fh_addons_page() {
    global $wpdb;
    $addons     = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}fh_addons ORDER BY sort_order,name");
    $activities = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}fh_activities WHERE active=1 ORDER BY name");
    fh_styles(); ?>
    <style>
    .fh7-addon-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:18px;margin-top:18px;}
    .fh7-addon-card{background:var(--fh-surface);border:1px solid var(--fh-border);border-radius:12px;overflow:hidden;transition:all .2s;}
    .fh7-addon-card:hover{border-color:var(--fh-blue);transform:translateY(-2px);box-shadow:0 4px 20px rgba(4,157,225,.12);}
    .fh7-addon-img{height:130px;background:linear-gradient(135deg,var(--fh-surface2),var(--fh-bg));position:relative;overflow:hidden;display:flex;align-items:center;justify-content:center;}
    .fh7-addon-img img{width:100%;height:100%;object-fit:cover;}
    .fh7-addon-img-placeholder{font-size:40px;opacity:.3;}
    .fh7-addon-status{position:absolute;top:8px;left:8px;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:700;}
    .fh7-addon-body{padding:14px 16px;}
    .fh7-addon-name{font-size:14px;font-weight:700;color:var(--fh-text);margin-bottom:4px;}
    .fh7-addon-desc{font-size:11px;color:var(--fh-muted);margin-bottom:10px;line-height:1.4;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;}
    .fh7-addon-price-row{display:flex;align-items:center;gap:6px;margin-bottom:10px;flex-wrap:wrap;}
    .fh7-addon-price{font-size:18px;font-weight:800;color:var(--fh-teal);}
    .fh7-addon-meta{font-size:10px;color:var(--fh-dim);background:rgba(4,157,225,.08);border:1px solid var(--fh-border);padding:2px 7px;border-radius:4px;}
    .fh7-addon-footer{display:flex;gap:6px;border-top:1px solid var(--fh-border);padding-top:10px;}
    /* Addon modal */
    .fh7-am-overlay{position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:99998;backdrop-filter:blur(4px);}
    .fh7-am-modal{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:99999;background:#1f2937;border:1px solid rgba(4,157,225,.35);border-radius:12px;width:560px;max-width:96vw;max-height:90vh;overflow-y:auto;box-shadow:0 16px 60px rgba(0,0,0,.7);animation:fh-in .2s ease;}
    .fh7-am-hdr{background:#1a2535;padding:13px 18px;border-bottom:1px solid rgba(4,157,225,.2);display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:2;}
    .fh7-am-close{background:none;border:none;color:#6a8090;font-size:20px;cursor:pointer;}
    .fh7-am-close:hover{color:#f07070;}
    .fh7-am-body{padding:20px;}
    .fh7-am-sec{margin-bottom:20px;}
    .fh7-am-sec-title{font-size:10px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--fh-blue);border-bottom:1px solid rgba(4,157,225,.15);padding-bottom:6px;margin-bottom:12px;}
    .fh7-am-g2{display:grid;grid-template-columns:1fr 1fr;gap:11px;margin-bottom:11px;}
    .fh7-am-g1{margin-bottom:11px;}
    .fh7-am-f{display:flex;flex-direction:column;gap:4px;}
    .fh7-am-f label{font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--fh-muted);}
    .fh7-am-i{background:var(--fh-bg);border:1px solid var(--fh-border);color:var(--fh-text);border-radius:6px;padding:8px 10px;font-size:13px;font-family:inherit;width:100%;transition:border-color .15s;}
    .fh7-am-i:focus{outline:none;border-color:var(--fh-blue);}
    .fh7-act-picker{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:7px;}
    .fh7-act-pick-item{display:flex;align-items:center;gap:7px;padding:7px 10px;border-radius:6px;border:1px solid var(--fh-border);cursor:pointer;font-size:12px;color:var(--fh-text);transition:all .15s;}
    .fh7-act-pick-item:hover{border-color:var(--fh-blue);}
    .fh7-act-pick-item.sel{background:rgba(4,157,225,.1);border-color:var(--fh-blue);color:var(--fh-blue);}
    .fh7-am-footer{padding:13px 18px;border-top:1px solid var(--fh-border);display:flex;gap:8px;justify-content:flex-end;background:#1a2535;position:sticky;bottom:0;}
    </style>

    <div class="wrap"><div class="fh-wrap">
      <div class="fh-topbar">
        <img src="https://www.chenahotsprings.com/wp-content/uploads/2025/12/Chene-Hotsprings-Logo-scaled.webp" class="fh-topbar-logo" onerror="this.style.display='none'">
        <div class="fh-topbar-divider"></div>
        <div class="fh-topbar-title">Add-ons & Upsells</div>
        <div class="fh-spacer"></div>
        <button onclick="fh7AddonOpen()" class="fh-btn fh-btn-primary">＋ New Add-on</button>
      </div>

      <?php if ($addons): ?>
      <div class="fh7-addon-grid">
      <?php foreach ($addons as $a):
        $linked = $wpdb->get_col($wpdb->prepare("SELECT activity_id FROM {$wpdb->prefix}fh_activity_addons WHERE addon_id=%d",$a->id));
        $tax_str = $a->tax_rate>0 ? ' + '.$a->tax_rate.'% tax' : '';
      ?>
      <div class="fh7-addon-card">
        <div class="fh7-addon-img">
          <?php if ($a->photo_url): ?><img src="<?php echo esc_url($a->photo_url); ?>" alt="<?php echo esc_attr($a->name); ?>">
          <?php else: ?><div class="fh7-addon-img-placeholder">🎁</div><?php endif; ?>
          <div class="fh7-addon-status" style="background:<?php echo $a->active?'#1d9e75':'#5f5e5a'; ?>;color:<?php echo $a->active?'#e1f5ee':'#f1efe8'; ?>;"><?php echo $a->active?'Active':'Inactive'; ?></div>
        </div>
        <div class="fh7-addon-body">
          <div class="fh7-addon-name"><?php echo esc_html($a->name); ?></div>
          <?php if ($a->description): ?><div class="fh7-addon-desc"><?php echo esc_html($a->description); ?></div><?php endif; ?>
          <div class="fh7-addon-price-row">
            <span class="fh7-addon-price">$<?php echo number_format($a->price,2); ?></span>
            <span class="fh7-addon-meta"><?php echo $a->price_type==='per_person'?'per person':'flat fee'; ?></span>
            <?php if ($a->tax_rate>0): ?><span class="fh7-addon-meta"><?php echo $a->tax_rate; ?>% tax</span><?php endif; ?>
          </div>
          <?php if (!empty($linked)): ?>
          <div style="font-size:10px;color:var(--fh-dim);margin-bottom:10px;"><?php echo count($linked); ?> activit<?php echo count($linked)!=1?'ies':'y'; ?> linked</div>
          <?php endif; ?>
          <div class="fh7-addon-footer">
            <button onclick="fh7AddonLoad(<?php echo $a->id; ?>)" class="fh-btn fh-btn-ghost fh-btn-sm" style="flex:1;">Edit</button>
            <button onclick="fh7AddonDelete(<?php echo $a->id; ?>,'<?php echo esc_js($a->name); ?>')" class="fh-btn fh-btn-red fh-btn-sm">Delete</button>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
      </div>
      <?php else: ?>
      <div style="margin-top:18px;padding:48px;text-align:center;color:var(--fh-dim);background:var(--fh-surface);border:1px solid var(--fh-border);border-radius:8px;">
        <div style="font-size:40px;margin-bottom:12px;">🎁</div>
        <div style="font-size:16px;font-weight:700;color:var(--fh-text);margin-bottom:8px;">No add-ons yet</div>
        <div style="font-size:13px;margin-bottom:18px;">Create add-ons like Appletini Package, Photo Package, GoPro Rental — then attach them to activities.</div>
        <button onclick="fh7AddonOpen()" class="fh-btn fh-btn-primary">＋ Create First Add-on</button>
      </div>
      <?php endif; ?>
    </div></div>

    <!-- Add-on Modal -->
    <div id="fh7-am-overlay" class="fh7-am-overlay" style="display:none;" onclick="fh7AddonClose()"></div>
    <div id="fh7-am-modal" class="fh7-am-modal" style="display:none;">
      <div class="fh7-am-hdr">
        <span style="font-size:13px;font-weight:700;color:var(--fh-blue);text-transform:uppercase;letter-spacing:.1em;" id="fh7-am-title">New Add-on</span>
        <button class="fh7-am-close" onclick="fh7AddonClose()">✕</button>
      </div>
      <div class="fh7-am-body">
        <input type="hidden" id="fh7-am-id">
        <div class="fh7-am-sec">
          <div class="fh7-am-sec-title">Product Details</div>
          <div class="fh7-am-g1"><div class="fh7-am-f"><label>Name *</label><input type="text" id="fh7-am-name" class="fh7-am-i" placeholder="e.g. Appletini Package"></div></div>
          <div class="fh7-am-g1"><div class="fh7-am-f"><label>Description</label><textarea id="fh7-am-desc" class="fh7-am-i" rows="2" style="resize:vertical;border-radius:6px;" placeholder="What's included…"></textarea></div></div>
          <div class="fh7-am-g1"><div class="fh7-am-f"><label>Photo URL</label><input type="url" id="fh7-am-photo" class="fh7-am-i" placeholder="https://…"></div></div>
          <div class="fh7-am-g2">
            <div class="fh7-am-f"><label>Status</label><select id="fh7-am-active" class="fh7-am-i"><option value="1">Active</option><option value="0">Inactive</option></select></div>
            <div class="fh7-am-f"><label>Price Type</label><select id="fh7-am-ptype" class="fh7-am-i"><option value="per_person">Per person</option><option value="flat">Flat fee</option></select></div>
          </div>
        </div>
        <div class="fh7-am-sec">
          <div class="fh7-am-sec-title">Pricing & Tax</div>
          <div class="fh7-am-g2">
            <div class="fh7-am-f"><label>Base Price ($)</label><input type="number" id="fh7-am-price" class="fh7-am-i" value="0" step="0.01" min="0"></div>
            <div class="fh7-am-f"><label>Tax Rate (%)</label><input type="number" id="fh7-am-tax" class="fh7-am-i" value="0" step="0.1" min="0"></div>
          </div>
          <div class="fh7-am-g2">
            <div class="fh7-am-f"><label>Fee Type</label><select id="fh7-am-ftype" class="fh7-am-i"><option value="flat">Flat fee</option><option value="percent">Percent</option></select></div>
            <div class="fh7-am-f"><label>Fee Amount</label><input type="number" id="fh7-am-fee" class="fh7-am-i" value="0" step="0.01" min="0"></div>
          </div>
        </div>
        <div class="fh7-am-sec">
          <div class="fh7-am-sec-title">Linked Activities <span style="font-weight:400;color:var(--fh-dim);">(select which tours offer this)</span></div>
          <div class="fh7-act-picker" id="fh7-am-acts">
            <?php foreach ($activities as $act): ?>
            <div class="fh7-act-pick-item" data-id="<?php echo $act->id; ?>" onclick="this.classList.toggle('sel')">
              <span style="width:8px;height:8px;border-radius:50%;background:<?php echo esc_attr($act->color); ?>;flex-shrink:0;"></span>
              <?php echo esc_html($act->name); ?>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
      <div class="fh7-am-footer">
        <button onclick="fh7AddonClose()" class="fh-btn fh-btn-ghost">Cancel</button>
        <button onclick="fh7AddonSave()" class="fh-btn fh-btn-primary">Save Add-on</button>
      </div>
    </div>

    <script>
    var fh7Nonce = '<?php echo wp_create_nonce("fh_nonce"); ?>';
    var fh7Ajax  = '<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
    var fh7Addons = <?php echo json_encode(array_combine(array_column($addons,'id'),$addons)); ?>;

    function fh7AddonOpen(){ document.getElementById('fh7-am-title').textContent='New Add-on'; document.getElementById('fh7-am-id').value=''; document.getElementById('fh7-am-name').value=''; document.getElementById('fh7-am-desc').value=''; document.getElementById('fh7-am-photo').value=''; document.getElementById('fh7-am-price').value='0'; document.getElementById('fh7-am-tax').value='0'; document.getElementById('fh7-am-fee').value='0'; document.getElementById('fh7-am-active').value='1'; document.querySelectorAll('.fh7-act-pick-item').forEach(function(el){el.classList.remove('sel');}); document.getElementById('fh7-am-overlay').style.display=''; document.getElementById('fh7-am-modal').style.display=''; }
    function fh7AddonClose(){ document.getElementById('fh7-am-overlay').style.display='none'; document.getElementById('fh7-am-modal').style.display='none'; }
    function fh7AddonLoad(id){
        fetch(fh7Ajax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=fh_get_addons&nonce='+fh7Nonce})
        .then(function(r){return r.json();}).then(function(d){
            if(!d.success)return;
            var a=d.data.find(function(x){return x.id==id;}); if(!a)return;
            document.getElementById('fh7-am-title').textContent='Edit Add-on';
            document.getElementById('fh7-am-id').value=a.id;
            document.getElementById('fh7-am-name').value=a.name||'';
            document.getElementById('fh7-am-desc').value=a.description||'';
            document.getElementById('fh7-am-photo').value=a.photo_url||'';
            document.getElementById('fh7-am-price').value=a.price||0;
            document.getElementById('fh7-am-tax').value=a.tax_rate||0;
            document.getElementById('fh7-am-fee').value=a.fee_amount||0;
            document.getElementById('fh7-am-active').value=a.active||1;
            document.getElementById('fh7-am-ptype').value=a.price_type||'per_person';
            document.getElementById('fh7-am-ftype').value=a.fee_type||'flat';
            // Re-apply linked activities selection
            var linked=a.linked_activity_ids||[];
            document.querySelectorAll('.fh7-act-pick-item').forEach(function(el){
                el.classList.toggle('sel', linked.indexOf(String(el.dataset.id))>-1||linked.indexOf(parseInt(el.dataset.id))>-1);
            });
            document.getElementById('fh7-am-overlay').style.display='';
            document.getElementById('fh7-am-modal').style.display='';
        });
    }
    function fh7AddonSave(){
        var name=document.getElementById('fh7-am-name').value.trim();
        if(!name){alert('Name required.');return;}
        var acts=[];
        document.querySelectorAll('.fh7-act-pick-item.sel').forEach(function(el){acts.push(el.dataset.id);});
        var body='action=fh_save_addon&nonce='+fh7Nonce
            +'&id='+document.getElementById('fh7-am-id').value
            +'&name='+encodeURIComponent(name)
            +'&description='+encodeURIComponent(document.getElementById('fh7-am-desc').value)
            +'&photo_url='+encodeURIComponent(document.getElementById('fh7-am-photo').value)
            +'&price='+document.getElementById('fh7-am-price').value
            +'&tax_rate='+document.getElementById('fh7-am-tax').value
            +'&fee_amount='+document.getElementById('fh7-am-fee').value
            +'&active='+document.getElementById('fh7-am-active').value
            +'&price_type='+document.getElementById('fh7-am-ptype').value
            +'&fee_type='+document.getElementById('fh7-am-ftype').value;
        acts.forEach(function(a,i){body+='&activity_ids['+i+']='+a;});
        fetch(fh7Ajax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body})
        .then(function(r){return r.json();})
        .then(function(d){if(d.success){fhToast('Add-on saved!');fh7AddonClose();setTimeout(function(){location.reload();},800);}else alert('Error: '+d.data);});
    }
    function fh7AddonDelete(id,name){
        if(!confirm('Delete "'+name+'"?'))return;
        fetch(fh7Ajax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=fh_delete_addon&id='+id+'&nonce='+fh7Nonce})
        .then(function(r){return r.json();}).then(function(d){if(d.success)location.reload();});
    }
    </script>
    <?php fh_admin_js(); ?>
    <?php
}

// ──────────────────────────────────────────────────────────────────
// V7 SETTINGS PAGE
// ──────────────────────────────────────────────────────────────────
function fh_settings_page() {
    fh_styles(); ?>
    <style>
    .fh7-sett-grid{display:grid;grid-template-columns:200px 1fr;gap:20px;margin-top:18px;align-items:start;}
    @media(max-width:700px){.fh7-sett-grid{grid-template-columns:1fr;}}
    .fh7-sett-nav{background:var(--fh-surface);border:1px solid var(--fh-border);border-radius:10px;overflow:hidden;position:sticky;top:32px;}
    .fh7-sett-nav-item{display:block;padding:11px 16px;font-size:13px;color:var(--fh-muted);cursor:pointer;border-left:3px solid transparent;transition:all .15s;border-bottom:1px solid var(--fh-border);}
    .fh7-sett-nav-item:last-child{border-bottom:none;}
    .fh7-sett-nav-item:hover{color:var(--fh-text);background:rgba(4,157,225,.05);}
    .fh7-sett-nav-item.active{color:var(--fh-blue);border-left-color:var(--fh-blue);background:rgba(4,157,225,.06);font-weight:700;}
    .fh7-sett-panel{display:none;}
    .fh7-sett-panel.active{display:block;}
    .fh7-sett-sec{background:var(--fh-surface);border:1px solid var(--fh-border);border-radius:10px;margin-bottom:14px;overflow:hidden;}
    .fh7-sett-sec-hdr{background:#1a2535;padding:12px 18px;font-size:11px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--fh-blue);border-bottom:1px solid rgba(4,157,225,.2);}
    .fh7-sett-sec-body{padding:18px;}
    .fh7-sett-row{display:grid;grid-template-columns:200px 1fr;gap:14px;align-items:start;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.04);}
    .fh7-sett-row:last-child{border-bottom:none;}
    .fh7-sett-lbl{font-size:12px;font-weight:700;color:var(--fh-text);padding-top:9px;}
    .fh7-sett-hint{font-size:10px;color:var(--fh-dim);margin-top:2px;line-height:1.4;}
    .fh7-sett-input{background:var(--fh-bg);border:1px solid var(--fh-border);color:var(--fh-text);border-radius:6px;padding:8px 10px;font-size:13px;font-family:inherit;width:100%;transition:border-color .15s;}
    .fh7-sett-input:focus{outline:none;border-color:var(--fh-blue);}
    .fh7-sett-toggle{display:flex;align-items:center;gap:10px;padding-top:8px;}
    .fh7-sett-toggle input[type=checkbox]{width:18px;height:18px;accent-color:var(--fh-blue);cursor:pointer;}
    .fh7-sett-toggle label{font-size:13px;color:var(--fh-text);cursor:pointer;}
    </style>

    <?php
    // Load all settings
    global $wpdb;
    $settings = [];
    $rows = $wpdb->get_results("SELECT setting_key,setting_value FROM {$wpdb->prefix}fh_settings");
    foreach ($rows as $r) $settings[$r->setting_key] = $r->setting_value;
    function fhs($key,$default='') { global $settings; return esc_attr($settings[$key]??$default); }
    function fhsc($key) { global $settings; return !empty($settings[$key])?'checked':''; }
    ?>

    <div class="wrap"><div class="fh-wrap">
      <div class="fh-topbar">
        <img src="https://www.chenahotsprings.com/wp-content/uploads/2025/12/Chene-Hotsprings-Logo-scaled.webp" class="fh-topbar-logo" onerror="this.style.display='none'">
        <div class="fh-topbar-divider"></div>
        <div class="fh-topbar-title">Settings</div>
        <div class="fh-spacer"></div>
        <button onclick="fh7SettSave()" class="fh-btn fh-btn-primary">Save All Settings</button>
      </div>

      <div class="fh7-sett-grid">
        <!-- Nav -->
        <div class="fh7-sett-nav">
          <div class="fh7-sett-nav-item active" onclick="fh7SettTab('resort')">🏔 Resort Info</div>
          <div class="fh7-sett-nav-item" onclick="fh7SettTab('booking')">📅 Booking</div>
          <div class="fh7-sett-nav-item" onclick="fh7SettTab('email')">📧 Email</div>
          <div class="fh7-sett-nav-item" onclick="fh7SettTab('waiver')">📋 Waivers</div>
          <div class="fh7-sett-nav-item" onclick="fh7SettTab('payment')">💳 Payment</div>
          <div class="fh7-sett-nav-item" onclick="fh7SettTab('cancel')">❌ Cancellation</div>
          <div class="fh7-sett-nav-item" onclick="fh7SettTab('updates')">🔄 Updates</div>
        </div>

        <!-- Panels -->
        <div>
          <!-- Resort Info -->
          <div class="fh7-sett-panel active" id="fh7-sett-resort">
            <div class="fh7-sett-sec">
              <div class="fh7-sett-sec-hdr">Resort Information</div>
              <div class="fh7-sett-sec-body">
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Resort Name</div></div><input type="text" name="resort_name" class="fh7-sett-input" value="<?php echo fhs('resort_name','Chena Hot Springs Resort'); ?>"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Address</div></div><input type="text" name="resort_address" class="fh7-sett-input" value="<?php echo fhs('resort_address','Mile 56.5 Chena Hot Springs Road, Fairbanks, AK 99712'); ?>"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Phone</div></div><input type="tel" name="resort_phone" class="fh7-sett-input" value="<?php echo fhs('resort_phone','907-451-8104'); ?>"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Email</div></div><input type="email" name="resort_email" class="fh7-sett-input" value="<?php echo fhs('resort_email'); ?>"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Website</div></div><input type="url" name="resort_url" class="fh7-sett-input" value="<?php echo fhs('resort_url','https://www.chenahotsprings.com'); ?>"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Timezone</div></div>
                  <select name="timezone" class="fh7-sett-input">
                    <option value="America/Anchorage" <?php selected(fhs('timezone','America/Anchorage'),'America/Anchorage'); ?>>Alaska (AKST/AKDT)</option>
                    <option value="America/Los_Angeles" <?php selected(fhs('timezone'),'America/Los_Angeles'); ?>>Pacific</option>
                    <option value="America/Denver" <?php selected(fhs('timezone'),'America/Denver'); ?>>Mountain</option>
                    <option value="America/Chicago" <?php selected(fhs('timezone'),'America/Chicago'); ?>>Central</option>
                    <option value="America/New_York" <?php selected(fhs('timezone'),'America/New_York'); ?>>Eastern</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          <!-- Booking Settings -->
          <div class="fh7-sett-panel" id="fh7-sett-booking">
            <div class="fh7-sett-sec">
              <div class="fh7-sett-sec-hdr">Booking Settings</div>
              <div class="fh7-sett-sec-body">
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Min Advance Hours</div><div class="fh7-sett-hint">Guests must book at least this many hours before tour</div></div><input type="number" name="min_advance_hours" class="fh7-sett-input" value="<?php echo fhs('min_advance_hours','2'); ?>" min="0"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Max Advance Days</div><div class="fh7-sett-hint">How far in advance guests can book</div></div><input type="number" name="max_advance_days" class="fh7-sett-input" value="<?php echo fhs('max_advance_days','365'); ?>" min="1"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Default Source</div></div>
                  <select name="default_source" class="fh7-sett-input">
                    <option value="onsite" <?php selected(fhs('default_source','onsite'),'onsite'); ?>>On-site</option>
                    <option value="phone" <?php selected(fhs('default_source'),'phone'); ?>>Phone</option>
                    <option value="online" <?php selected(fhs('default_source'),'online'); ?>>Online</option>
                  </select>
                </div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Require Phone</div></div><div class="fh7-sett-toggle"><input type="checkbox" name="require_phone" id="fhs-require-phone" <?php echo fhsc('require_phone'); ?>><label for="fhs-require-phone">Require phone number on booking</label></div></div>
              </div>
            </div>
          </div>

          <!-- Email Settings -->
          <div class="fh7-sett-panel" id="fh7-sett-email">
            <div class="fh7-sett-sec">
              <div class="fh7-sett-sec-hdr">Email & Notifications</div>
              <div class="fh7-sett-sec-body">
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">From Name</div></div><input type="text" name="email_from_name" class="fh7-sett-input" value="<?php echo fhs('email_from_name','Chena Hot Springs Resort'); ?>"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">From Email</div></div><input type="email" name="email_from_address" class="fh7-sett-input" value="<?php echo fhs('email_from_address','reservations@chenahotsprings.com'); ?>"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">BCC Address</div><div class="fh7-sett-hint">Receives a copy of every confirmation email</div></div><input type="email" name="email_bcc" class="fh7-sett-input" value="<?php echo fhs('email_bcc'); ?>"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Confirmation Subject</div></div><input type="text" name="email_subject" class="fh7-sett-input" value="<?php echo fhs('email_subject','Your booking is confirmed — {activity}'); ?>"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Staff Notification Email</div><div class="fh7-sett-hint">Gets notified when an online booking comes in</div></div><input type="email" name="notify_staff_email" class="fh7-sett-input" value="<?php echo fhs('notify_staff_email'); ?>"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Email Footer</div></div><textarea name="email_footer" class="fh7-sett-input" rows="3" style="resize:vertical;border-radius:6px;"><?php echo esc_textarea($settings['email_footer']??'Questions? Call us at 907-451-8104'); ?></textarea></div>
              </div>
            </div>
          </div>

          <!-- Waiver Settings -->
          <div class="fh7-sett-panel" id="fh7-sett-waiver">
            <div class="fh7-sett-sec">
              <div class="fh7-sett-sec-hdr">Waiver Settings</div>
              <div class="fh7-sett-sec-body">
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Waiver Version</div><div class="fh7-sett-hint">Label shown on waiver records</div></div><input type="text" name="waiver_version" class="fh7-sett-input" value="<?php echo fhs('waiver_version','v1.0'); ?>"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Waiver Expiry (days)</div><div class="fh7-sett-hint">How long a signed waiver is valid</div></div><input type="number" name="waiver_expiry_days" class="fh7-sett-input" value="<?php echo fhs('waiver_expiry_days','180'); ?>" min="1"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Require Before Check-in</div></div><div class="fh7-sett-toggle"><input type="checkbox" name="require_waiver_checkin" id="fhs-waiver-checkin" <?php echo fhsc('require_waiver_checkin'); ?>><label for="fhs-waiver-checkin">Block check-in if waiver not signed</label></div></div>
              </div>
            </div>
          </div>

          <!-- Payment Settings -->
          <div class="fh7-sett-panel" id="fh7-sett-payment">
            <div class="fh7-sett-sec">
              <div class="fh7-sett-sec-hdr">Payment Settings</div>
              <div class="fh7-sett-sec-body">
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Currency</div></div>
                  <select name="currency" class="fh7-sett-input">
                    <option value="USD" <?php selected(fhs('currency','USD'),'USD'); ?>>USD — US Dollar</option>
                    <option value="CAD" <?php selected(fhs('currency'),'CAD'); ?>>CAD — Canadian Dollar</option>
                  </select>
                </div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Default Tax Rate (%)</div></div><input type="number" name="default_tax_rate" class="fh7-sett-input" value="<?php echo fhs('default_tax_rate','0'); ?>" step="0.1" min="0"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Payment Methods</div><div class="fh7-sett-hint">Shown to guests at checkout</div></div><input type="text" name="payment_methods" class="fh7-sett-input" value="<?php echo fhs('payment_methods','Cash, Credit Card on Arrival'); ?>"></div>
                <div style="background:rgba(4,157,225,.05);border:1px solid rgba(4,157,225,.15);border-radius:7px;padding:12px 14px;font-size:12px;color:var(--fh-muted);">
                  💳 <strong style="color:var(--fh-text);">Stripe integration</strong> coming in a future update. Online payments will be collected automatically.
                </div>
              </div>
            </div>
          </div>

          <!-- Cancellation Policy -->
          <div class="fh7-sett-panel" id="fh7-sett-cancel">
            <div class="fh7-sett-sec">
              <div class="fh7-sett-sec-hdr">Cancellation Policy</div>
              <div class="fh7-sett-sec-body">
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Notice Required (hours)</div><div class="fh7-sett-hint">Hours notice required for full refund</div></div><input type="number" name="cancel_window_hours" class="fh7-sett-input" value="<?php echo fhs('cancel_window_hours','24'); ?>" min="0"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Cancellation Fee Type</div></div>
                  <select name="cancel_fee_type" class="fh7-sett-input">
                    <option value="none" <?php selected(fhs('cancel_fee_type','none'),'none'); ?>>No fee</option>
                    <option value="flat" <?php selected(fhs('cancel_fee_type'),'flat'); ?>>Flat amount</option>
                    <option value="percent" <?php selected(fhs('cancel_fee_type'),'percent'); ?>>Percentage</option>
                  </select>
                </div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">Cancellation Fee Amount</div></div><input type="number" name="cancel_fee_amount" class="fh7-sett-input" value="<?php echo fhs('cancel_fee_amount','0'); ?>" step="0.01" min="0"></div>
                <div class="fh7-sett-row"><div><div class="fh7-sett-lbl">No-show Fee</div></div><div class="fh7-sett-toggle"><input type="checkbox" name="noshow_fee" id="fhs-noshow" <?php echo fhsc('noshow_fee'); ?>><label for="fhs-noshow">Charge cancellation fee for no-shows</label></div></div>
              </div>
            </div>
          </div>

          <!-- Updates Panel -->
          <div class="fh7-sett-panel" id="fh7-sett-updates">
            <div class="fh7-sett-sec">
              <div class="fh7-sett-sec-hdr">Plugin Updates</div>
              <div class="fh7-sett-sec-body">
                <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.04);margin-bottom:14px;">
                  <div>
                    <div style="font-size:13px;font-weight:700;color:var(--fh-text);">Current Version</div>
                    <div style="font-size:12px;color:var(--fh-muted);margin-top:2px;">FairerHarbor v14.0.0</div>
                  </div>
                  <span style="background:rgba(64,208,128,.1);color:#40d080;border:1px solid rgba(64,208,128,.3);padding:3px 10px;border-radius:5px;font-size:11px;font-weight:700;">Active</span>
                </div>
                <div style="margin-bottom:14px;">
                  <label style="font-size:12px;font-weight:700;color:var(--fh-text);display:block;margin-bottom:6px;">Update URL</label>
                  <div style="font-size:11px;color:var(--fh-muted);margin-bottom:8px;">Paste the direct download URL to the latest plugin zip. This can be a GitHub raw file URL, Dropbox link, or any public HTTPS link.</div>
                  <input type="url" id="fh-update-url" name="update_url" class="fh7-sett-input" value="<?php echo fhs('update_url'); ?>" placeholder="https://github.com/ChenaHotSprings/fairerharbor/raw/main/farerharbor-latest.zip">
                </div>
                <div id="fh-update-msg" style="display:none;margin-bottom:12px;"></div>
                <button onclick="fhInstallUpdate()" class="fh-btn fh-btn-primary" style="font-size:13px;padding:10px 20px;" id="fh-update-btn">
                  🔄 Install Latest Version
                </button>
                <div style="font-size:11px;color:var(--fh-dim);margin-top:8px;">WordPress will download the zip from the URL above and install it automatically. The page will reload when complete.</div>
              </div>
            </div>
          </div>

          <div id="fh7-sett-msg" style="display:none;background:rgba(64,208,128,.1);border:1px solid rgba(64,208,128,.3);border-radius:7px;padding:11px 14px;color:#40d080;font-size:13px;margin-top:10px;"></div>
        </div>
      </div>
    </div></div>

    <script>
    var fh7SNonce = '<?php echo wp_create_nonce("fh_nonce"); ?>';
    var fh7SAjax  = '<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
    function fh7SettTab(id){
        document.querySelectorAll('.fh7-sett-nav-item').forEach(function(el){el.classList.remove('active');});
        document.querySelectorAll('.fh7-sett-panel').forEach(function(el){el.classList.remove('active');});
        event.currentTarget.classList.add('active');
        document.getElementById('fh7-sett-'+id).classList.add('active');
    }
    function fhInstallUpdate(){
        var url=document.getElementById('fh-update-url').value.trim();
        if(!url){alert('Please enter an update URL first.');return;}
        var btn=document.getElementById('fh-update-btn');
        var msg=document.getElementById('fh-update-msg');
        btn.disabled=true; btn.textContent='⏳ Downloading…';
        msg.style.display='none';
        // First save the URL
        fetch(fh7SAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_save_settings&nonce='+fh7SNonce+'&update_url='+encodeURIComponent(url)});
        // Then trigger the update
        fetch(fh7SAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_install_update&nonce='+fh7SNonce+'&update_url='+encodeURIComponent(url)})
        .then(function(r){return r.json();})
        .then(function(d){
            btn.disabled=false; btn.textContent='🔄 Install Latest Version';
            if(d.success){
                msg.innerHTML='<div style="background:rgba(64,208,128,.1);border:1px solid rgba(64,208,128,.3);border-radius:6px;padding:10px 12px;color:#40d080;font-size:13px;">✓ '+d.data.message+' Reloading…</div>';
                msg.style.display='';
                setTimeout(function(){location.reload();},2000);
            } else {
                msg.innerHTML='<div style="background:rgba(240,85,85,.1);border:1px solid rgba(240,85,85,.3);border-radius:6px;padding:10px 12px;color:#f07070;font-size:13px;">✗ '+d.data+'</div>';
                msg.style.display='';
            }
        })
        .catch(function(){
            btn.disabled=false; btn.textContent='🔄 Install Latest Version';
            msg.innerHTML='<div style="background:rgba(240,85,85,.1);border:1px solid rgba(240,85,85,.3);border-radius:6px;padding:10px 12px;color:#f07070;font-size:13px;">✗ Network error. Check the URL and try again.</div>';
            msg.style.display='';
        });
    }
    function fh7SettSave(){
        var body='action=fh_save_settings&nonce='+fh7SNonce;
        document.querySelectorAll('.fh7-sett-input,[name]').forEach(function(el){
            if(!el.name)return;
            if(el.type==='checkbox') body+='&'+el.name+'='+(el.checked?'1':'0');
            else body+='&'+el.name+'='+encodeURIComponent(el.value);
        });
        fetch(fh7SAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body})
        .then(function(r){return r.json();})
        .then(function(d){
            var msg=document.getElementById('fh7-sett-msg');
            if(d.success){msg.textContent='✓ Settings saved successfully.';msg.style.display='';msg.style.background='rgba(64,208,128,.1)';msg.style.color='#40d080';msg.style.borderColor='rgba(64,208,128,.3)';}
            else{msg.textContent='Error saving settings.';msg.style.display='';msg.style.background='rgba(240,85,85,.1)';msg.style.color='#f05555';msg.style.borderColor='rgba(240,85,85,.3)';}
            setTimeout(function(){msg.style.display='none';},3000);
        });
    }
    </script>
    <?php fh_admin_js(); ?>
    <?php
}
function fh_ajax_save_slot_settings() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('view_chena_waivers')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $slot_id  = (int)$_POST['slot_id'];
    $date     = sanitize_text_field($_POST['date']);
    $capacity = isset($_POST['capacity']) && $_POST['capacity'] !== '' ? (int)$_POST['capacity'] : null;
    $bookable = (int)($_POST['bookable'] ?? 1);
    $table    = $wpdb->prefix . 'fh_slot_overrides';
    $existing = $wpdb->get_row($wpdb->prepare("SELECT id FROM $table WHERE slot_id=%d AND override_date=%s",$slot_id,$date));
    if ($existing) {
        $wpdb->update($table,['capacity'=>$capacity,'bookable'=>$bookable],['id'=>$existing->id],['%d','%d'],['%d']);
    } else {
        $wpdb->insert($table,['slot_id'=>$slot_id,'override_date'=>$date,'capacity'=>$capacity,'bookable'=>$bookable],['%d','%s','%d','%d']);
    }
    wp_send_json_success(['message'=>'Slot settings saved.']);
}

function fh_ajax_get_booking_extras() {
    check_ajax_referer('fh_nonce','nonce');
    global $wpdb;
    $act_id = (int)$_POST['activity_id'];
    $upsells = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_upsells WHERE activity_id=%d AND active=1 ORDER BY sort_order",$act_id));
    $fields  = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_activity_fields WHERE activity_id=%d ORDER BY sort_order",$act_id));
    wp_send_json_success(['upsells'=>$upsells,'fields'=>$fields]);
}

function fh_ajax_checkin_guest() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('view_chena_waivers')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $id     = (int)$_POST['id'];
    $status = sanitize_text_field($_POST['checkin_status']);
    $wpdb->update("{$wpdb->prefix}fh_bookings",['checkin_status'=>$status],['id'=>$id],['%s'],['%d']);
    wp_send_json_success();
}

// ──────────────────────────────────────────────────────────────────
// V5 AJAX HANDLERS — update booking, resend email, upsells, fields
// ──────────────────────────────────────────────────────────────────

function fh_ajax_update_booking() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('view_chena_waivers')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $id      = (int)$_POST['id'];
    $fname   = sanitize_text_field($_POST['guest_first_name'] ?? '');
    $lname   = sanitize_text_field($_POST['guest_last_name'] ?? '');
    $name    = $fname && $lname ? $fname.' '.$lname : sanitize_text_field($_POST['guest_name'] ?? '');
    $email   = sanitize_email($_POST['guest_email'] ?? '');
    $phone   = sanitize_text_field($_POST['guest_phone'] ?? '');
    $adults  = (int)$_POST['adults'];
    $children= (int)$_POST['children'];
    $party   = $adults + $children;
    $date    = sanitize_text_field($_POST['booking_date'] ?? '');
    $time    = sanitize_text_field($_POST['booking_time'] ?? '');
    $slot_id = (int)$_POST['slot_id'];
    $notes   = sanitize_textarea_field($_POST['notes'] ?? '');
    $guide   = sanitize_text_field($_POST['guide_name'] ?? '');
    $status  = sanitize_text_field($_POST['status'] ?? 'confirmed');
    $total   = floatval($_POST['total_price'] ?? 0);

    // Check capacity if date/time changed
    $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_bookings WHERE id=%d",$id));
    if ($existing && ($existing->booking_date !== $date || $existing->booking_time !== $time)) {
        $booked = fh_get_booked_count($existing->activity_id, $date, $time);
        $act    = $wpdb->get_row($wpdb->prepare("SELECT capacity FROM {$wpdb->prefix}fh_activities WHERE id=%d",$existing->activity_id));
        $avail  = $act->capacity - $booked;
        if ($party > $avail) wp_send_json_error('Not enough capacity for that slot. Only '.$avail.' spots available.');
    }

    $wpdb->update("{$wpdb->prefix}fh_bookings", [
        'guest_name'  => $name, 'guest_first_name' => $fname, 'guest_last_name' => $lname,
        'guest_email' => $email, 'guest_phone' => $phone,
        'adults'      => $adults, 'children' => $children, 'party_size' => $party,
        'booking_date'=> $date, 'booking_time' => $time, 'slot_id' => $slot_id,
        'notes'       => $notes, 'guide_name' => $guide, 'status' => $status,
        'total_price' => $total,
    ], ['id'=>$id], ['%s','%s','%s','%d','%d','%d','%s','%s','%d','%s','%s','%s','%f'], ['%d']);
    wp_send_json_success(['message'=>'Booking updated.']);
}

function fh_ajax_resend_email() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('view_chena_waivers')) wp_send_json_error('Unauthorized');
    $id = (int)$_POST['id'];
    fh_send_confirmation($id);
    wp_send_json_success(['message'=>'Confirmation email resent.']);
}

function fh_ajax_get_activity_data() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('view_chena_waivers')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $id = (int)$_POST['activity_id'];
    $act    = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_activities WHERE id=%d",$id));
    $slots  = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_slots WHERE activity_id=%d ORDER BY slot_time",$id));
    $fields = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_activity_fields WHERE activity_id=%d ORDER BY sort_order",$id));
    $upsells= $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_upsells WHERE activity_id=%d ORDER BY sort_order",$id));
    wp_send_json_success(['activity'=>$act,'slots'=>$slots,'fields'=>$fields,'upsells'=>$upsells]);
}

function fh_ajax_save_upsell() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $id  = (int)($_POST['id']??0);
    $data = [
        'activity_id' => (int)$_POST['activity_id'],
        'name'        => sanitize_text_field($_POST['name']),
        'description' => sanitize_textarea_field($_POST['description']??''),
        'price'       => floatval($_POST['price']),
        'price_type'  => sanitize_text_field($_POST['price_type']??'per_person'),
        'active'      => (int)($_POST['active']??1),
    ];
    if ($id) $wpdb->update("{$wpdb->prefix}fh_upsells",$data,['id'=>$id],['%d','%s','%s','%f','%s','%d'],['%d']);
    else { $wpdb->insert("{$wpdb->prefix}fh_upsells",$data,['%d','%s','%s','%f','%s','%d']); $id=$wpdb->insert_id; }
    wp_send_json_success(['id'=>$id]);
}

function fh_ajax_delete_upsell() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $wpdb->delete("{$wpdb->prefix}fh_upsells",['id'=>(int)$_POST['id']],['%d']);
    wp_send_json_success();
}

function fh_ajax_save_field() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $id   = (int)($_POST['id']??0);
    $data = [
        'activity_id'  => (int)$_POST['activity_id'],
        'field_label'  => sanitize_text_field($_POST['field_label']),
        'field_key'    => sanitize_key($_POST['field_key']??sanitize_title($_POST['field_label'])),
        'field_type'   => sanitize_text_field($_POST['field_type']??'text'),
        'field_options'=> sanitize_textarea_field($_POST['field_options']??''),
        'required'     => (int)($_POST['required']??0),
        'sort_order'   => (int)($_POST['sort_order']??0),
    ];
    if ($id) $wpdb->update("{$wpdb->prefix}fh_activity_fields",$data,['id'=>$id],['%d','%s','%s','%s','%s','%d','%d'],['%d']);
    else { $wpdb->insert("{$wpdb->prefix}fh_activity_fields",$data,['%d','%s','%s','%s','%s','%d','%d']); $id=$wpdb->insert_id; }
    wp_send_json_success(['id'=>$id]);
}

function fh_ajax_delete_field() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $wpdb->delete("{$wpdb->prefix}fh_activity_fields",['id'=>(int)$_POST['id']],['%d']);
    wp_send_json_success();
}

// ── V8 New AJAX handlers ─────────────────────────────────────────
function fh_ajax_get_guest_history() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('view_chena_waivers')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $email = sanitize_email($_POST['email']??'');
    $name  = sanitize_text_field($_POST['guest_name']??'');
    if (!$email && !$name) wp_send_json_error('No identifier');
    $where = $email ? $wpdb->prepare("b.guest_email=%s",$email) : $wpdb->prepare("b.guest_name=%s",$name);
    $bookings = $wpdb->get_results(
        "SELECT b.*,a.name as act_name,a.color FROM {$wpdb->prefix}fh_bookings b
         JOIN {$wpdb->prefix}fh_activities a ON b.activity_id=a.id
         WHERE $where ORDER BY b.booking_date DESC LIMIT 10");
    wp_send_json_success($bookings);
}
function fh_ajax_update_payment() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('view_chena_waivers')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $id=$_POST['id']; $ps=sanitize_text_field($_POST['payment_status']??'unpaid');
    $pa=floatval($_POST['payment_amount']??0); $ra=floatval($_POST['refund_amount']??0);
    $wpdb->update("{$wpdb->prefix}fh_bookings",['payment_status'=>$ps,'payment_amount'=>$pa,'refund_amount'=>$ra],['id'=>(int)$id],['%s','%f','%f'],['%d']);
    wp_send_json_success(['message'=>'Payment updated.']);
}
function fh_ajax_save_slot_bookable() {
    check_ajax_referer('fh_nonce','nonce');
    if (!current_user_can('view_chena_waivers')) wp_send_json_error('Unauthorized');
    global $wpdb;
    $sid=(int)$_POST['slot_id']; $date=sanitize_text_field($_POST['date']); $b=(int)$_POST['bookable'];
    $t=$wpdb->prefix.'fh_slot_overrides';
    $ex=$wpdb->get_row($wpdb->prepare("SELECT id FROM $t WHERE slot_id=%d AND override_date=%s",$sid,$date));
    if($ex) $wpdb->update($t,['bookable'=>$b],['id'=>$ex->id],['%d'],['%d']);
    else $wpdb->insert($t,['slot_id'=>$sid,'override_date'=>$date,'bookable'=>$b,'capacity'=>null],['%d','%s','%d','%s']);
    wp_send_json_success(['message'=>'Slot updated.','bookable'=>$b]);
}

// ──────────────────────────────────────────────────────────────────
// V8 NEW BOOKING PAGE — staff-facing fast entry form
// ──────────────────────────────────────────────────────────────────




function fh_new_booking_page() {
    global $wpdb;
    $activities = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}fh_activities WHERE active=1 ORDER BY sort_order,name");
    $pre_act    = (int)($_GET['activity'] ?? 0);
    $pre_date   = sanitize_text_field($_GET['date'] ?? date('Y-m-d'));
    $pre_slot   = (int)($_GET['slot'] ?? 0);
    $pre_time   = sanitize_text_field($_GET['time'] ?? '');
    $pre_fname  = sanitize_text_field($_GET['prefill_name'] ? explode(' ',$_GET['prefill_name'].' ')[0] : '');
    $pre_lname  = sanitize_text_field($_GET['prefill_name'] ? trim(implode(' ',array_slice(explode(' ',$_GET['prefill_name'].' '),1))) : '');
    $pre_email  = sanitize_email($_GET['prefill_email'] ?? '');
    $pre_phone  = sanitize_text_field($_GET['prefill_phone'] ?? '');

    $act_thumbs = [];
    foreach ($activities as $a) {
        $post_id = $a->post_id ?? $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->prefix}postmeta WHERE meta_key='_fh_activity_id' AND meta_value=%d LIMIT 1", $a->id
        ));
        $act_thumbs[$a->id] = $post_id ? (get_the_post_thumbnail_url($post_id,'thumbnail') ?: '') : '';
    }

    fh_styles(); ?>
    <style>
    .fhnb-card{background:var(--fh-surface);border:1px solid var(--fh-border);border-radius:8px;margin-bottom:12px;overflow:hidden;}
    .fhnb-card-hdr{background:var(--fh-surface2);padding:8px 14px;font-size:10px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;border-bottom:1px solid var(--fh-border);}
    .fhnb-card-body{padding:14px;}
    .fhnb-row{display:grid;gap:10px;margin-bottom:10px;}
    .fhnb-row-2{grid-template-columns:1fr 1fr;}
    .fhnb-row-3{grid-template-columns:1fr 1fr 1fr;}
    @media(max-width:700px){.fhnb-row-2,.fhnb-row-3{grid-template-columns:1fr 1fr;}}
    .fhnb-f{display:flex;flex-direction:column;gap:3px;}
    .fhnb-f label{font-size:9px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--fh-muted);}
    .fhnb-f input,.fhnb-f select,.fhnb-f textarea{font-size:12px;padding:6px 9px;border-radius:6px;}
    /* Activity cards */
    .fhnb-act-grid{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:4px;}
    .fhnb-act-card{width:110px;border:2px solid var(--fh-border);border-radius:9px;overflow:hidden;cursor:pointer;transition:all .15s;background:var(--fh-bg);flex-shrink:0;}
    .fhnb-act-card:hover{border-color:var(--fh-blue);transform:translateY(-1px);}
    .fhnb-act-card.selected{border-color:var(--fh-blue);background:rgba(4,157,225,.08);}
    .fhnb-act-thumb{width:100%;height:64px;object-fit:cover;display:block;}
    .fhnb-act-thumb-ph{width:100%;height:64px;display:flex;align-items:center;justify-content:center;}
    .fhnb-act-name{font-size:10px;font-weight:700;color:var(--fh-text);padding:5px 7px;line-height:1.3;text-align:center;}
    /* Slot cards */
    .fhnb-slot-row{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;}
    .fhnb-slot-card{border:1px solid var(--fh-border);border-radius:7px;padding:9px 14px;cursor:pointer;transition:all .15s;background:var(--fh-bg);text-align:center;min-width:90px;}
    .fhnb-slot-card:hover:not(.disabled){border-color:var(--fh-blue);}
    .fhnb-slot-card.selected{border-color:var(--fh-blue);background:rgba(4,157,225,.1);}
    .fhnb-slot-card.disabled{opacity:.4;cursor:not-allowed;}
    .fhnb-slot-time{font-size:13px;font-weight:700;color:var(--fh-text);}
    .fhnb-slot-avail{font-size:10px;margin-top:2px;}
    /* Party controls — bigger and styled */
    .fhnb-party-row{display:flex;align-items:stretch;gap:12px;flex-wrap:wrap;margin-bottom:14px;}
    .fhnb-party-group{display:flex;flex-direction:column;align-items:center;background:var(--fh-bg);border:1px solid var(--fh-border);border-radius:10px;padding:12px 16px;gap:8px;min-width:120px;}
    .fhnb-party-type{font-size:10px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--fh-muted);}
    .fhnb-party-ctrl{display:flex;align-items:center;gap:10px;}
    .fhnb-pbtn{width:32px;height:32px;border-radius:50%;border:1.5px solid var(--fh-border);background:var(--fh-surface);color:var(--fh-text);font-size:18px;cursor:pointer;display:flex;align-items:center;justify-content:center;line-height:1;transition:all .15s;flex-shrink:0;font-weight:300;}
    .fhnb-pbtn:hover{border-color:var(--fh-blue);color:var(--fh-blue);background:rgba(4,157,225,.08);}
    .fhnb-pnum{width:36px;text-align:center;font-size:22px;font-weight:800;color:var(--fh-text);background:none;border:none;padding:0;-moz-appearance:textfield;}
    .fhnb-pnum::-webkit-inner-spin-button,.fhnb-pnum::-webkit-outer-spin-button{-webkit-appearance:none;margin:0;}
    .fhnb-party-total{font-size:12px;color:var(--fh-muted);display:flex;align-items:center;padding-left:4px;align-self:center;}
    /* Guest cards */
    .fhnb-guest-card{background:var(--fh-bg);border:1px solid var(--fh-border);border-radius:7px;padding:12px;margin-bottom:8px;}
    .fhnb-guest-lbl{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;margin-bottom:9px;display:block;}
    .fhnb-optional-hint{font-size:10px;color:var(--fh-dim);margin-top:6px;}
    /* Addons */
    .fhnb-addon-list{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;}
    .fhnb-addon-chk{display:flex;align-items:center;gap:6px;padding:5px 9px;border:1px solid var(--fh-border);border-radius:5px;cursor:pointer;font-size:11px;color:var(--fh-text);transition:all .15s;background:var(--fh-surface);}
    .fhnb-addon-chk:hover{border-color:var(--fh-blue);}
    .fhnb-addon-chk.sel{border-color:var(--fh-blue);background:rgba(4,157,225,.1);color:var(--fh-blue);}
    .fhnb-addon-chk input[type=checkbox]{accent-color:var(--fh-blue);width:13px;height:13px;pointer-events:none;}
    /* Payment radio */
    .fhnb-pay-opts{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;}
    .fhnb-pay-opt{display:flex;align-items:center;gap:7px;padding:7px 12px;border:1px solid var(--fh-border);border-radius:6px;cursor:pointer;font-size:12px;color:var(--fh-text);transition:all .15s;background:var(--fh-bg);}
    .fhnb-pay-opt:hover{border-color:var(--fh-blue);}
    .fhnb-pay-opt.sel{border-color:var(--fh-blue);background:rgba(4,157,225,.08);}
    .fhnb-pay-opt input[type=radio]{accent-color:var(--fh-blue);width:14px;height:14px;}
    /* Confirm row */
    .fhnb-confirm-row{display:flex;align-items:center;gap:10px;padding:10px 14px;border-top:1px solid var(--fh-border);}
    .fhnb-initials{width:70px;text-align:center;font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;padding:9px 8px;border-radius:6px;}
    </style>

    <div class="wrap"><div class="fh-wrap">
      <div class="fh-topbar">
        <a href="<?php echo admin_url('admin.php?page=farerharbor-calendar'); ?>" class="fh-btn fh-btn-ghost">← Calendar</a>
        <div class="fh-topbar-divider"></div>
        <img src="https://www.chenahotsprings.com/wp-content/uploads/2025/12/Chene-Hotsprings-Logo-scaled.webp" class="fh-topbar-logo" onerror="this.style.display='none'">
        <div class="fh-topbar-title">New Booking</div>
        <div class="fh-spacer"></div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 260px;gap:14px;margin-top:14px;align-items:start;">
        <div>

          <!-- Booking Details -->
          <div class="fhnb-card">
            <div class="fhnb-card-hdr" style="color:var(--fh-blue);">📅 Booking Details</div>
            <div class="fhnb-card-body">

              <!-- 1. Date first -->
              <div class="fhnb-f" style="margin-bottom:14px;max-width:180px;">
                <label>Date *</label>
                <input type="date" id="fhnb-date" value="<?php echo esc_attr($pre_date); ?>" onchange="fhnbLoadSlots()" min="<?php echo date('Y-m-d'); ?>" onclick="try{this.showPicker();}catch(e){}" style="font-size:13px;padding:7px 10px;">
              </div>

              <!-- 2. Activity cards -->
              <div style="font-size:9px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--fh-muted);margin-bottom:8px;">Activity *</div>
              <div class="fhnb-act-grid" id="fhnb-act-grid">
                <?php foreach ($activities as $a):
                  $thumb = $act_thumbs[$a->id] ?? '';
                ?>
                <div class="fhnb-act-card <?php echo $pre_act===$a->id?'selected':''; ?>"
                     data-id="<?php echo $a->id; ?>"
                     data-pa="<?php echo $a->price_adult; ?>"
                     data-pc="<?php echo $a->price_child; ?>"
                     onclick="fhnbSelAct(this)">
                  <?php if ($thumb): ?>
                  <img src="<?php echo esc_url($thumb); ?>" class="fhnb-act-thumb" alt="<?php echo esc_attr($a->name); ?>">
                  <?php else: ?>
                  <div class="fhnb-act-thumb-ph" style="background:<?php echo esc_attr($a->color); ?>22;">
                    <span style="width:24px;height:24px;border-radius:50%;background:<?php echo esc_attr($a->color); ?>;display:block;"></span>
                  </div>
                  <?php endif; ?>
                  <div class="fhnb-act-name"><?php echo esc_html($a->name); ?></div>
                </div>
                <?php endforeach; ?>
              </div>
              <input type="hidden" id="fhnb-act" value="<?php echo $pre_act; ?>">

              <!-- 3. Time slots -->
              <div style="margin-top:14px;">
                <div style="font-size:9px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--fh-muted);margin-bottom:6px;">Time Slot *</div>
                <div id="fhnb-slot-row" class="fhnb-slot-row">
                  <div style="font-size:12px;color:var(--fh-dim);">Select date and activity first</div>
                </div>
                <input type="hidden" id="fhnb-slot" value="">
                <input type="hidden" id="fhnb-time-raw" value="">
              </div>
            </div>
          </div>

          <!-- Guests -->
          <div class="fhnb-card">
            <div class="fhnb-card-hdr" style="color:var(--fh-teal);">👥 Guests</div>
            <div class="fhnb-card-body">
              <div class="fhnb-party-row">
                <div class="fhnb-party-group">
                  <span class="fhnb-party-type">Adults</span>
                  <div class="fhnb-party-ctrl">
                    <button type="button" class="fhnb-pbtn" onclick="fhnbAdj('fhnb-adults',-1)">−</button>
                    <input type="number" id="fhnb-adults" value="1" min="0" class="fhnb-pnum" oninput="fhnbSyncParty()">
                    <button type="button" class="fhnb-pbtn" onclick="fhnbAdj('fhnb-adults',1)">+</button>
                  </div>
                </div>
                <div class="fhnb-party-group">
                  <span class="fhnb-party-type">Children</span>
                  <div class="fhnb-party-ctrl">
                    <button type="button" class="fhnb-pbtn" onclick="fhnbAdj('fhnb-children',-1)">−</button>
                    <input type="number" id="fhnb-children" value="0" min="0" class="fhnb-pnum" oninput="fhnbSyncParty()">
                    <button type="button" class="fhnb-pbtn" onclick="fhnbAdj('fhnb-children',1)">+</button>
                  </div>
                </div>
                <div class="fhnb-party-total">= <span id="fhnb-total-guests" style="color:var(--fh-text);font-weight:700;margin:0 4px;">1</span> guest</div>
              </div>
              <div id="fhnb-guest-cards"></div>
            </div>
          </div>

          <!-- Pricing -->
          <div class="fhnb-card">
            <div class="fhnb-card-hdr" style="color:#40d080;">💰 Pricing & Payment</div>
            <div class="fhnb-card-body">
              <div class="fhnb-row fhnb-row-2" style="margin-bottom:12px;">
                <div class="fhnb-f"><label>Total Price ($)</label><input type="number" id="fhnb-total" step="0.01" min="0" value="0.00" oninput="fhnbUpdateSummary()"></div>
                <div class="fhnb-f"><label>Promo Code</label><input type="text" id="fhnb-promo" placeholder="Enter code" style="text-transform:uppercase;letter-spacing:.05em;"></div>
              </div>
              <div style="font-size:9px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--fh-muted);margin-bottom:7px;">Payment Type</div>
              <div class="fhnb-pay-opts">
                <label class="fhnb-pay-opt sel" onclick="fhnbSelPay(this)"><input type="radio" name="fhnb-pay" value="card" checked> 💳 Charge Card</label>
                <label class="fhnb-pay-opt" onclick="fhnbSelPay(this)"><input type="radio" name="fhnb-pay" value="cash"> 💵 Cash</label>
                <label class="fhnb-pay-opt" onclick="fhnbSelPay(this)"><input type="radio" name="fhnb-pay" value="later"> ⏳ Pay Later</label>
              </div>
            </div>
          </div>

          <!-- Notes -->
          <div class="fhnb-card">
            <div class="fhnb-card-hdr" style="color:var(--fh-muted);">📋 Notes</div>
            <div class="fhnb-card-body">
              <textarea id="fhnb-notes" rows="4" placeholder="Special requests, dietary needs, notes for guide…" style="width:100%;resize:vertical;border-radius:6px;font-size:12px;padding:9px 11px;min-height:90px;"></textarea>
            </div>
          </div>

        </div>

        <!-- Summary sidebar -->
        <div style="position:sticky;top:32px;">
          <div class="fhnb-card">
            <div class="fhnb-card-hdr">Summary</div>
            <div style="padding:12px 14px;" id="fhnb-summary"><div style="color:var(--fh-dim);font-size:12px;text-align:center;padding:12px 0;">Fill form to see summary</div></div>
            <div class="fhnb-confirm-row">
              <div class="fhnb-f" style="flex-shrink:0;">
                <label style="font-size:9px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--fh-muted);">Initials *</label>
                <input type="text" id="fhnb-initials" class="fhnb-initials" placeholder="XX" maxlength="4">
              </div>
              <button onclick="fhnbSubmit(event)" class="fh-btn fh-btn-primary" style="flex:1;justify-content:center;font-size:13px;padding:10px;">✓ Confirm</button>
            </div>
          </div>
        </div>
      </div>
    </div></div>

    <script>
    var fhnbNonce='<?php echo wp_create_nonce("fh_nonce"); ?>';
    var fhnbAjax='<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
    var fhnbSlotData={}, fhnbSelSlotId=null;
    var fhnbPreSlot=<?php echo $pre_slot; ?>, fhnbPreTime=<?php echo json_encode($pre_time); ?>;
    var fhnbPartyCount=1, fhnbAddons=[];

    function fhnbFmtPhone(el){
        var v=el.value.replace(/\D/g,'').substring(0,10);
        if(v.length>=7) el.value='('+v.substring(0,3)+') '+v.substring(3,6)+'-'+v.substring(6);
        else if(v.length>=4) el.value='('+v.substring(0,3)+') '+v.substring(3);
        else if(v.length>0) el.value='('+v;
        else el.value='';
    }
    function fhnbSelPay(lbl){document.querySelectorAll('.fhnb-pay-opt').forEach(function(l){l.classList.remove('sel');});lbl.classList.add('sel');}

    function fhnbSelAct(card){
        document.querySelectorAll('.fhnb-act-card').forEach(function(c){c.classList.remove('selected');});
        card.classList.add('selected');
        document.getElementById('fhnb-act').value=card.dataset.id;
        fhnbLoadSlots();
        fhnbLoadAddons();
    }

    function fhnbAdj(id,delta){
        var el=document.getElementById(id);
        el.value=Math.max(0,parseInt(el.value||0)+delta);
        fhnbSyncParty();
    }

    function fhnbSyncParty(){
        var a=parseInt(document.getElementById('fhnb-adults').value)||0;
        var c=parseInt(document.getElementById('fhnb-children').value)||0;
        fhnbPartyCount=Math.max(1,a+c);
        document.getElementById('fhnb-total-guests').textContent=fhnbPartyCount;
        fhnbRenderGuestCards();
        fhnbCalcPrice();
    }

    function fhnbRenderGuestCards(){
        var n=fhnbPartyCount, html='';
        var adults=parseInt(document.getElementById('fhnb-adults').value)||0;
        for(var i=0;i<n;i++){
            var isLead=i===0, type=i<adults?'Adult':'Child', num=i<adults?i+1:i-adults+1;
            var lbl=isLead?'Lead Booker (required)':(type+' '+num);
            html+='<div class="fhnb-guest-card">';
            html+='<span class="fhnb-guest-lbl" style="color:'+(isLead?'var(--fh-blue)':'var(--fh-muted)')+';">'+lbl+'</span>';
            html+='<div class="fhnb-row fhnb-row-2" style="margin-bottom:8px;">';
            html+='<div class="fhnb-f"><label>First Name'+(isLead?' *':'')+'</label><input type="text" id="fhnb-fn-'+i+'" placeholder="First name" oninput="fhnbUpdateSummary()"></div>';
            html+='<div class="fhnb-f"><label>Last Name'+(isLead?' *':'')+'</label><input type="text" id="fhnb-ln-'+i+'" placeholder="Last name"></div>';
            if(isLead){
                html+='<div class="fhnb-f"><label>Email</label><input type="email" id="fhnb-email" placeholder="guest@email.com"></div>';
                html+='<div class="fhnb-f"><label>Phone</label><input type="tel" id="fhnb-phone" placeholder="(907) 000-0000" oninput="fhnbFmtPhone(this)" maxlength="14"></div>';
                // Staying at resort inside lead card
                html+='<div class="fhnb-f"><label>Staying at Resort?</label><select id="fhnb-staying"><option value="0">Day Visitor</option><option value="1">Resort Guest</option></select></div>';
                html+='<div class="fhnb-f"><label>Room Number</label><input type="text" id="fhnb-room" placeholder="Room #"></div>';
            }
            html+='</div>';
            // Per-guest addons
            if(fhnbAddons.length){
                html+='<div style="font-size:9px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--fh-muted);margin-bottom:5px;margin-top:2px;">Add-ons</div>';
                html+='<div class="fhnb-addon-list">';
                fhnbAddons.forEach(function(a){
                    html+='<label class="fhnb-addon-chk" onclick="this.classList.toggle(\'sel\');fhnbCalcPrice()">'
                        +'<input type="checkbox" id="fhnb-ai-'+i+'-'+a.id+'">'
                        +a.name+' <span style="color:var(--fh-teal);margin-left:3px;">$'+parseFloat(a.price).toFixed(2)+'</span></label>';
                });
                html+='</div>';
            }
            if(!isLead) html+='<div class="fhnb-optional-hint">Optional — fill at kiosk on arrival</div>';
            html+='</div>';
        }
        document.getElementById('fhnb-guest-cards').innerHTML=html;
        // Restore prefill
        <?php if($pre_fname): ?>
        var fn0=document.getElementById('fhnb-fn-0'); if(fn0) fn0.value='<?php echo esc_js($pre_fname); ?>';
        var ln0=document.getElementById('fhnb-ln-0'); if(ln0) ln0.value='<?php echo esc_js($pre_lname); ?>';
        var em=document.getElementById('fhnb-email'); if(em) em.value='<?php echo esc_js($pre_email); ?>';
        var ph=document.getElementById('fhnb-phone'); if(ph) ph.value='<?php echo esc_js($pre_phone); ?>';
        <?php endif; ?>
        fhnbUpdateSummary();
    }

    function fhnbLoadSlots(){
        var act=document.getElementById('fhnb-act').value, date=document.getElementById('fhnb-date').value;
        var row=document.getElementById('fhnb-slot-row');
        if(!act||!date){row.innerHTML='<div style="font-size:12px;color:var(--fh-dim);">Select date and activity first</div>';return;}
        row.innerHTML='<div style="font-size:12px;color:var(--fh-dim);">Loading…</div>';
        fetch(fhnbAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_get_slots&activity_id='+act+'&date='+date+'&nonce='+fhnbNonce})
        .then(function(r){return r.json();}).then(function(data){
            if(!data.success||!data.data.length){row.innerHTML='<div style="font-size:12px;color:var(--fh-dim);">No slots available for this date</div>';return;}
            fhnbSlotData={};
            var html='';
            data.data.forEach(function(s){
                fhnbSlotData[s.id]=s;
                var full=s.available<=0;
                var presel=(s.id==fhnbPreSlot||s.time_raw==fhnbPreTime);
                var avColor=full?'#f07070':(s.available<=3?'#ffc107':'#40d080');
                html+='<div class="fhnb-slot-card'+(full?' disabled':'')+(presel?' selected':'')+'" id="fhnb-sc-'+s.id+'" onclick="'+(full?'':'fhnbSelSlot('+s.id+')')+'">'
                    +'<div class="fhnb-slot-time">'+s.time+'</div>'
                    +'<div class="fhnb-slot-avail" style="color:'+avColor+';">'+s.available+' open</div></div>';
                if(presel){fhnbSelSlotId=s.id;document.getElementById('fhnb-slot').value=s.id;document.getElementById('fhnb-time-raw').value=s.time_raw;}
            });
            row.innerHTML=html;
            fhnbCalcPrice();
        });
    }

    function fhnbSelSlot(id){
        document.querySelectorAll('.fhnb-slot-card').forEach(function(c){c.classList.remove('selected');});
        var card=document.getElementById('fhnb-sc-'+id); if(card) card.classList.add('selected');
        fhnbSelSlotId=id;
        document.getElementById('fhnb-slot').value=id;
        var s=fhnbSlotData[id];
        if(s) document.getElementById('fhnb-time-raw').value=s.time_raw;
        fhnbUpdateSummary();
    }

    function fhnbLoadAddons(){
        var act=document.getElementById('fhnb-act').value;
        if(!act){fhnbAddons=[];fhnbRenderGuestCards();return;}
        fetch(fhnbAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_get_addons&activity_id='+act+'&nonce='+fhnbNonce})
        .then(function(r){return r.json();}).then(function(d){
            fhnbAddons=d.success?d.data:[];
            fhnbRenderGuestCards();
        });
    }

    function fhnbCalcPrice(){
        var card=document.querySelector('.fhnb-act-card.selected');
        if(!card) return;
        var a=parseInt(document.getElementById('fhnb-adults').value)||0;
        var c=parseInt(document.getElementById('fhnb-children').value)||0;
        var pa=parseFloat(card.dataset.pa)||0, pc=parseFloat(card.dataset.pc)||0;
        var base=(a*pa)+(c*pc), addonTotal=0;
        for(var i=0;i<fhnbPartyCount;i++){
            fhnbAddons.forEach(function(ad){
                var lbl=document.getElementById('fhnb-ai-'+i+'-'+ad.id);
                if(lbl&&lbl.closest('.fhnb-addon-chk').classList.contains('sel'))
                    addonTotal+=parseFloat(ad.price)||0;
            });
        }
        document.getElementById('fhnb-total').value=(base+addonTotal).toFixed(2);
        fhnbUpdateSummary();
    }

    function fhnbSR(l,v){return '<div style="display:flex;justify-content:space-between;font-size:12px;padding:2px 0;"><span style="color:var(--fh-muted);">'+l+'</span><span style="color:var(--fh-text);font-weight:600;">'+v+'</span></div>';}

    function fhnbUpdateSummary(){
        var card=document.querySelector('.fhnb-act-card.selected');
        var actName=card?card.querySelector('.fhnb-act-name').textContent:'—';
        var fn=document.getElementById('fhnb-fn-0'), ln=document.getElementById('fhnb-ln-0');
        var name=((fn?fn.value:'')+' '+(ln?ln.value:'')).trim()||'—';
        var date=document.getElementById('fhnb-date').value;
        var selCard=document.querySelector('.fhnb-slot-card.selected');
        var slotTime=selCard?selCard.querySelector('.fhnb-slot-time').textContent:'—';
        var total=parseFloat(document.getElementById('fhnb-total').value||0);
        var payOpt=document.querySelector('input[name="fhnb-pay"]:checked');
        var payLabel=payOpt?{card:'Charge Card',cash:'Cash',later:'Pay Later'}[payOpt.value]||'—':'—';
        document.getElementById('fhnb-summary').innerHTML=
            fhnbSR('Activity',actName)+fhnbSR('Date',date||'—')+fhnbSR('Time',slotTime)
            +fhnbSR('Lead Guest',name)+fhnbSR('Party',fhnbPartyCount+' guest'+(fhnbPartyCount!==1?'s':''))
            +fhnbSR('Payment',payLabel)
            +'<div style="border-top:1px solid var(--fh-border);padding-top:8px;margin-top:6px;display:flex;justify-content:space-between;align-items:center;">'
            +'<span style="font-size:11px;color:var(--fh-muted);">Total</span>'
            +'<span style="font-size:20px;font-weight:800;color:var(--fh-teal);">$'+total.toFixed(2)+'</span></div>';
    }

    function fhnbSubmit(e){
        var btn=e.target;
        var act=document.getElementById('fhnb-act').value;
        var date=document.getElementById('fhnb-date').value;
        var sid=document.getElementById('fhnb-slot').value;
        var timeRaw=document.getElementById('fhnb-time-raw').value;
        var fn0=document.getElementById('fhnb-fn-0'), ln0=document.getElementById('fhnb-ln-0');
        var firstName=(fn0?fn0.value.trim():''), lastName=(ln0?ln0.value.trim():'');
        var a=parseInt(document.getElementById('fhnb-adults').value)||0;
        var c=parseInt(document.getElementById('fhnb-children').value)||0;
        var initials=document.getElementById('fhnb-initials').value.trim();
        var s=fhnbSlotData[sid]||{};
        if(!act){alert('Please select an activity.');return;}
        if(!date){alert('Please select a date.');return;}
        if(!sid){alert('Please select a time slot.');return;}
        if(!firstName){alert('Please enter the lead guest first name.');return;}
        if(!initials){alert('Please enter your initials.');return;}
        if(a+c<1){alert('Party size must be at least 1.');return;}
        if(s.available!==undefined&&a+c>s.available){alert('Only '+s.available+' spots remaining.');return;}
        btn.disabled=true; btn.textContent='Saving…';
        var guestNames=[];
        for(var i=0;i<fhnbPartyCount;i++){
            var gf=document.getElementById('fhnb-fn-'+i), gl=document.getElementById('fhnb-ln-'+i);
            var gAddons=[];
            fhnbAddons.forEach(function(ad){
                var lbl=document.getElementById('fhnb-ai-'+i+'-'+ad.id);
                if(lbl&&lbl.closest('.fhnb-addon-chk').classList.contains('sel')) gAddons.push(ad.id);
            });
            guestNames.push({first:(gf?gf.value.trim():''),last:(gl?gl.value.trim():''),addons:gAddons});
        }
        var payOpt=document.querySelector('input[name="fhnb-pay"]:checked');
        var phoneRaw=(document.getElementById('fhnb-phone')||{value:''}).value.replace(/\D/g,'');
        var emailVal=(document.getElementById('fhnb-email')||{value:''}).value;
        var body='action=fh_save_booking&nonce='+fhnbNonce
            +'&activity_id='+act+'&slot_id='+sid
            +'&booking_date='+encodeURIComponent(date)+'&booking_time='+encodeURIComponent(timeRaw)
            +'&guest_first_name='+encodeURIComponent(firstName)+'&guest_last_name='+encodeURIComponent(lastName)
            +'&guest_name='+encodeURIComponent((firstName+' '+lastName).trim())
            +'&guest_email='+encodeURIComponent(emailVal)
            +'&guest_phone='+encodeURIComponent(phoneRaw)
            +'&adults='+a+'&children='+c+'&price_type=adult'
            +'&total_price='+document.getElementById('fhnb-total').value
            +'&booking_source=onsite'
            +'&payment_type='+(payOpt?payOpt.value:'card')
            +'&promo_code='+encodeURIComponent(document.getElementById('fhnb-promo').value)
            +'&notes='+encodeURIComponent(document.getElementById('fhnb-notes').value)
            +'&staying_at_resort='+(document.getElementById('fhnb-staying')?document.getElementById('fhnb-staying').value:0)
            +'&room_number='+encodeURIComponent((document.getElementById('fhnb-room')||{value:''}).value)
            +'&employee_initials='+encodeURIComponent(initials)
            +(emailVal?'&send_email=1':'');
        guestNames.forEach(function(g,i){
            body+='&guests['+i+'][first]='+encodeURIComponent(g.first)+'&guests['+i+'][last]='+encodeURIComponent(g.last);
            g.addons.forEach(function(aid,j){body+='&guests['+i+'][addons]['+j+']='+aid;});
        });
        fetch(fhnbAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body})
        .then(function(r){return r.json();})
        .then(function(d){
            btn.disabled=false; btn.textContent='✓ Confirm';
            if(d.success){fhToast('✓ Booking confirmed! '+d.data.code);
                setTimeout(function(){window.location=fhnbAjax.replace('admin-ajax.php','admin.php')+'?page=farerharbor-manifests&date='+date;},1200);
            } else alert('Error: '+d.data);
        }).catch(function(){btn.disabled=false;btn.textContent='✓ Confirm';alert('Network error.');});
    }

    // Init
    fhnbRenderGuestCards();
    <?php if($pre_act): ?>
    document.addEventListener('DOMContentLoaded',function(){fhnbLoadSlots();fhnbLoadAddons();});
    if(document.readyState==='complete'||document.readyState==='interactive'){setTimeout(function(){fhnbLoadSlots();fhnbLoadAddons();},150);}
    <?php endif; ?>
    </script>
    <?php fh_admin_js(); ?>
    <?php
}





function fh_calendar_page() {
    global $wpdb;
    $view   = sanitize_text_field($_GET['cal_view'] ?? 'week');
    $offset = (int)($_GET['offset'] ?? 0);
    $today  = date('Y-m-d');
    $t_book = $wpdb->prefix.'fh_bookings';
    $t_act  = $wpdb->prefix.'fh_activities';
    $t_slots= $wpdb->prefix.'fh_slots';
    $t_over = $wpdb->prefix.'fh_slot_overrides';
    $activities = $wpdb->get_results("SELECT * FROM $t_act WHERE active=1 ORDER BY sort_order,name");

    // Slot settings page
    if (isset($_GET['slot_settings'])) {
        $slot_id = (int)$_GET['slot_settings'];
        $date    = sanitize_text_field($_GET['date'] ?? $today);
        $act_id  = (int)($_GET['act'] ?? 0);
        $act     = $act_id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM $t_act WHERE id=%d",$act_id)) : null;
        $slot    = $wpdb->get_row($wpdb->prepare("SELECT * FROM $t_slots WHERE id=%d",$slot_id));
        $ov      = $wpdb->get_row($wpdb->prepare("SELECT * FROM $t_over WHERE slot_id=%d AND override_date=%s",$slot_id,$date));
        fh_styles(); ?>
        <div class="wrap"><div class="fh-wrap">
          <div class="fh-topbar">
            <img src="https://www.chenahotsprings.com/wp-content/uploads/2025/12/Chene-Hotsprings-Logo-scaled.webp" class="fh-topbar-logo" onerror="this.style.display='none'">
            <div class="fh-topbar-divider"></div>
            <div class="fh-topbar-title">Slot Settings</div>
            <div class="fh-spacer"></div>
            <a href="<?php echo admin_url('admin.php?page=farerharbor-calendar'); ?>" class="fh-btn fh-btn-ghost">← Calendar</a>
          </div>
          <div style="margin-top:18px;max-width:500px;">
            <div class="fh-card">
              <div class="fh-card-hdr">
                <?php if($act): ?><span style="display:flex;align-items:center;gap:7px;"><span style="width:10px;height:10px;border-radius:50%;background:<?php echo esc_attr($act->color); ?>;flex-shrink:0;"></span><?php echo esc_html($act->name); ?></span><?php endif; ?>
              </div>
              <div class="fh-card-body">
                <div style="font-size:13px;color:var(--fh-muted);margin-bottom:16px;"><?php echo date('l, F j, Y',strtotime($date)); ?> <?php echo $slot?date('g:i A',strtotime($slot->slot_time)):''; ?></div>
                <div style="margin-bottom:14px;">
                  <label style="font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--fh-muted);display:block;margin-bottom:5px;">Capacity Override</label>
                  <input type="number" id="fhss-cap" value="<?php echo $ov&&$ov->capacity!==null?(int)$ov->capacity:($act?$act->capacity:''); ?>" placeholder="Default (<?php echo $act?$act->capacity:''; ?>)" style="background:var(--fh-bg);border:1px solid var(--fh-border);color:var(--fh-text);border-radius:6px;padding:9px 11px;font-size:13px;width:100%;">
                  <div style="font-size:11px;color:var(--fh-dim);margin-top:4px;">Leave blank to use the default activity capacity.</div>
                </div>
                <div style="margin-bottom:20px;">
                  <label style="font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--fh-muted);display:block;margin-bottom:8px;">Bookable Online</label>
                  <div style="display:flex;align-items:center;gap:10px;">
                    <label style="position:relative;width:38px;height:21px;flex-shrink:0;"><input type="checkbox" id="fhss-online" <?php echo (!$ov||$ov->bookable)?'checked':''; ?> style="opacity:0;width:0;height:0;"><span id="fhss-online-sl" onclick="document.getElementById('fhss-online').checked=!document.getElementById('fhss-online').checked;updateSlider()" style="position:absolute;cursor:pointer;inset:0;background:<?php echo (!$ov||$ov->bookable)?'#049DE1':'#374151'; ?>;border-radius:21px;transition:.2s;"><span style="position:absolute;content:'';height:15px;width:15px;left:<?php echo (!$ov||$ov->bookable)?'20px':'3px'; ?>;bottom:3px;background:#fff;border-radius:50%;transition:.2s;display:block;"></span></span></label>
                    <span style="font-size:13px;color:var(--fh-text);" id="fhss-online-lbl"><?php echo (!$ov||$ov->bookable)?'Guests can book online':'Hidden from online booking'; ?></span>
                  </div>
                </div>
                <div id="fhss-msg" style="display:none;margin-bottom:12px;"></div>
                <button onclick="fhssSave()" class="fh-btn fh-btn-primary" style="width:100%;justify-content:center;padding:11px;">Save Slot Settings</button>
              </div>
            </div>
          </div>
        </div></div>
        <script>
        var fhssNonce='<?php echo wp_create_nonce("fh_nonce"); ?>';
        var fhssAjax='<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
        function updateSlider(){
            var ch=document.getElementById('fhss-online').checked;
            var sl=document.getElementById('fhss-online-sl');
            sl.style.background=ch?'#049DE1':'#374151';
            sl.querySelector('span').style.left=ch?'20px':'3px';
            document.getElementById('fhss-online-lbl').textContent=ch?'Guests can book online':'Hidden from online booking';
        }
        function fhssSave(){
            var cap=document.getElementById('fhss-cap').value;
            var online=document.getElementById('fhss-online').checked?1:0;
            fetch(fhssAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
                body:'action=fh_save_slot_settings&slot_id=<?php echo $slot_id; ?>&date=<?php echo esc_js($date); ?>&capacity='+cap+'&bookable='+online+'&nonce='+fhssNonce})
            .then(function(r){return r.json();}).then(function(d){
                var msg=document.getElementById('fhss-msg');
                if(d.success){msg.innerHTML='<div style="background:rgba(64,208,128,.1);border:1px solid rgba(64,208,128,.3);border-radius:6px;padding:9px 12px;color:#40d080;font-size:12px;">✓ Slot settings saved.</div>';}
                else{msg.innerHTML='<div style="background:rgba(240,85,85,.1);border:1px solid rgba(240,85,85,.3);border-radius:6px;padding:9px 12px;color:#f07070;font-size:12px;">Error: '+d.data+'</div>';}
                msg.style.display='';
                setTimeout(function(){msg.style.display='none';},3000);
            });
        }
        </script>
        <?php fh_admin_js(); ?>
        <?php return;
    }

    fh_styles(); ?>
    <style>
    /* ── V9 Calendar popup ── */
    .fhp9{position:fixed;z-index:99999;background:var(--fh-surface);border:0.5px solid rgba(99,152,199,.35);border-radius:12px;width:340px;box-shadow:0 12px 40px rgba(0,0,0,.6);animation:fh-in .15s ease;overflow:hidden;}
    .fhp9-hdr{background:var(--fh-surface2);padding:12px 14px;display:flex;align-items:center;gap:10px;border-bottom:1px solid rgba(99,152,199,.15);}
    .fhp9-thumb{width:42px;height:42px;border-radius:7px;object-fit:cover;background:var(--fh-bg);flex-shrink:0;}
    .fhp9-thumb-placeholder{width:42px;height:42px;border-radius:7px;background:var(--fh-bg);flex-shrink:0;display:flex;align-items:center;justify-content:center;}
    .fhp9-hdr-info{flex:1;min-width:0;}
    .fhp9-act-name{font-size:13px;font-weight:700;color:var(--fh-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .fhp9-act-time{font-size:11px;color:var(--fh-muted);margin-top:1px;}
    .fhp9-online-badge{font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;white-space:nowrap;flex-shrink:0;}
    .fhp9-close{background:none;border:none;color:var(--fh-dim);font-size:16px;cursor:pointer;padding:0;line-height:1;flex-shrink:0;}
    .fhp9-close:hover{color:#f07070;}
    .fhp9-stats{display:flex;border-bottom:1px solid rgba(99,152,199,.1);padding:10px 14px;gap:16px;}
    .fhp9-stat{text-align:center;flex:1;}
    .fhp9-stat-num{font-size:22px;font-weight:800;line-height:1;}
    .fhp9-stat-lbl{font-size:9px;color:var(--fh-muted);text-transform:uppercase;letter-spacing:.08em;margin-top:2px;}
    .fhp9-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:10px 14px;border-bottom:1px solid rgba(99,152,199,.1);}
    .fhp9-btn{display:flex;align-items:center;justify-content:center;gap:5px;padding:8px;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;text-decoration:none;border:none;transition:all .15s;font-family:inherit;}
    .fhp9-btn-primary{background:var(--fh-blue);color:#fff;}
    .fhp9-btn-primary:hover{opacity:.85;text-decoration:none;color:#fff;}
    .fhp9-btn-ghost{background:rgba(4,157,225,.1);color:#7ecfef;border:1px solid rgba(4,157,225,.25);}
    .fhp9-btn-ghost:hover{background:rgba(4,157,225,.2);color:#fff;text-decoration:none;}
    .fhp9-bookings{max-height:160px;overflow-y:auto;border-bottom:1px solid rgba(99,152,199,.1);}
    .fhp9-bookings::-webkit-scrollbar{width:3px;}
    .fhp9-bookings::-webkit-scrollbar-thumb{background:rgba(4,157,225,.3);border-radius:2px;}
    .fhp9-bk-row{display:flex;align-items:center;gap:8px;padding:7px 14px;border-bottom:1px solid rgba(255,255,255,.04);transition:background .1s;}
    .fhp9-bk-row:hover{background:rgba(4,157,225,.05);}
    .fhp9-bk-row:last-child{border-bottom:none;}
    .fhp9-bk-name{font-size:12px;font-weight:600;color:var(--fh-text);flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .fhp9-bk-code{font-size:10px;color:var(--fh-dim);font-family:monospace;}
    .fhp9-paid{font-size:10px;font-weight:700;padding:1px 6px;border-radius:4px;}
    .fhp9-paid-paid{background:rgba(64,208,128,.12);color:#40d080;}
    .fhp9-paid-unpaid{background:rgba(240,85,85,.1);color:#f07070;}
    .fhp9-paid-partial{background:rgba(255,193,7,.1);color:#ffc107;}
    .fhp9-cancelled-toggle{padding:6px 14px;font-size:11px;color:var(--fh-dim);cursor:pointer;border-bottom:1px solid rgba(99,152,199,.1);display:flex;align-items:center;gap:5px;}
    .fhp9-cancelled-toggle:hover{color:var(--fh-muted);}
    /* Settings section */
    .fhp9-settings{border-bottom:1px solid rgba(99,152,199,.1);padding:10px 14px;}
    .fhp9-settings-title{font-size:9px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--fh-blue);margin-bottom:8px;display:flex;align-items:center;justify-content:space-between;}
    .fhp9-cap-row{display:flex;align-items:center;gap:8px;margin-bottom:8px;}
    .fhp9-cap-lbl{font-size:12px;color:var(--fh-muted);flex:1;}
    .fhp9-cap-input{width:72px;background:var(--fh-bg);border:1px solid var(--fh-border);color:var(--fh-text);border-radius:5px;padding:5px 8px;font-size:12px;text-align:center;font-family:inherit;}
    .fhp9-cap-input:focus{outline:none;border-color:var(--fh-blue);}
    .fhp9-bookable-row{display:flex;align-items:center;gap:8px;}
    .fhp9-toggle{position:relative;width:34px;height:19px;flex-shrink:0;}
    .fhp9-toggle input{opacity:0;width:0;height:0;}
    .fhp9-tslider{position:absolute;cursor:pointer;inset:0;background:#374151;border-radius:19px;transition:.2s;}
    .fhp9-tslider:before{position:absolute;content:"";height:13px;width:13px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.2s;}
    .fhp9-toggle input:checked+.fhp9-tslider{background:var(--fh-blue);}
    .fhp9-toggle input:checked+.fhp9-tslider:before{transform:translateX(15px);}
    .fhp9-save-btn{width:100%;background:var(--fh-blue);color:#fff;border:none;border-radius:6px;padding:7px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit;margin-top:8px;transition:opacity .15s;}
    .fhp9-save-btn:hover{opacity:.85;}
    /* Comment section */
    .fhp9-comment{padding:10px 14px;}
    .fhp9-comment-title{font-size:9px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--fh-muted);margin-bottom:7px;}
    .fhp9-comment-input{width:100%;background:var(--fh-bg);border:1px solid var(--fh-border);color:var(--fh-text);border-radius:6px;padding:7px 9px;font-size:12px;font-family:inherit;resize:none;transition:border-color .15s;}
    .fhp9-comment-input:focus{outline:none;border-color:var(--fh-blue);}
    .fhp9-comment-footer{display:flex;justify-content:flex-end;margin-top:6px;}
    .fhp9-comment-btn{background:none;border:1px solid var(--fh-border);color:var(--fh-muted);border-radius:5px;padding:5px 12px;font-size:11px;font-weight:600;cursor:pointer;font-family:inherit;transition:all .15s;}
    .fhp9-comment-btn:hover{border-color:var(--fh-blue);color:var(--fh-blue);}
    .fh-filter-bar{background:var(--fh-surface);border:1px solid var(--fh-border);border-top:none;padding:8px 16px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
    .fh-filter-toggle{display:flex;align-items:center;gap:7px;cursor:pointer;font-size:12px;color:var(--fh-muted);user-select:none;padding:5px 12px;border-radius:6px;border:1px solid var(--fh-border);transition:all .15s;background:var(--fh-bg);}
    .fh-filter-toggle:hover{border-color:var(--fh-blue);color:var(--fh-text);}
    .fh-filter-toggle.active{background:rgba(4,157,225,.12);border-color:var(--fh-blue);color:var(--fh-blue);}
    .fh-filter-toggle input[type=checkbox]{display:none;}
    .fh-filter-dot{width:7px;height:7px;border-radius:50%;background:var(--fh-dim);flex-shrink:0;transition:background .15s;}
    .fh-filter-toggle.active .fh-filter-dot{background:var(--fh-blue);}
    </style>

    <div class="wrap"><div class="fh-wrap">
      <div class="fh-topbar">
        <img src="https://www.chenahotsprings.com/wp-content/uploads/2025/12/Chene-Hotsprings-Logo-scaled.webp" class="fh-topbar-logo" onerror="this.style.display='none'">
        <div class="fh-topbar-divider"></div>
        <div class="fh-topbar-title">Calendar</div>
        <div class="fh-spacer"></div>
        <a href="<?php echo admin_url('admin.php?page=farerharbor-new'); ?>" class="fh-btn fh-btn-primary">＋ New Booking</a>
      </div>

      <!-- Controls -->
      <div style="background:var(--fh-surface);border:1px solid var(--fh-border);border-top:none;padding:10px 16px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
        <?php
        $base_url = admin_url('admin.php?page=farerharbor-calendar&cal_view='.$view);
        if ($view==='week') {
            $week_start = date('Y-m-d', strtotime($today.' +'.($offset*7).' days'));
            $week_end   = date('Y-m-d', strtotime($week_start.' +6 days'));
            $title      = date('M j',strtotime($week_start)).' – '.date('M j, Y',strtotime($week_end));
        } else {
            $month_ts = strtotime(date('Y-m-01').' +'.$offset.' months');
            $title    = date('F Y',$month_ts);
        }
        ?>
        <a href="<?php echo $base_url.'&offset='.($offset-1); ?>" class="fh-btn fh-btn-ghost">‹</a>
        <span class="fh-cal-title"><?php echo $title; ?></span>
        <a href="<?php echo $base_url.'&offset='.($offset+1); ?>" class="fh-btn fh-btn-ghost">›</a>
        <a href="<?php echo $base_url.'&offset=0'; ?>" class="fh-btn fh-btn-primary fh-btn-sm">Today</a>
        <div class="fh-spacer"></div>
        <div style="display:flex;border:1px solid var(--fh-border);border-radius:6px;overflow:hidden;">
          <a href="<?php echo admin_url('admin.php?page=farerharbor-calendar&cal_view=week&offset=0'); ?>" style="padding:6px 14px;font-size:12px;font-weight:600;text-decoration:none;background:<?php echo $view==='week'?'var(--fh-blue)':' var(--fh-surface)'; ?>;color:<?php echo $view==='week'?'#fff':'var(--fh-muted)'; ?>;">Week</a>
          <a href="<?php echo admin_url('admin.php?page=farerharbor-calendar&cal_view=month&offset=0'); ?>" style="padding:6px 14px;font-size:12px;font-weight:600;text-decoration:none;background:<?php echo $view==='month'?'var(--fh-blue)':' var(--fh-surface)'; ?>;color:<?php echo $view==='month'?'#fff':'var(--fh-muted)'; ?>;">Month</a>
        </div>
      </div>

      <div class="fh-filter-bar">
        <span style="font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--fh-dim);">Filters:</span>
        <label class="fh-filter-toggle" id="fhf-empty-lbl"><input type="checkbox" id="fhf-empty" onchange="fhApplyFilters()"><span class="fh-filter-dot"></span>Hide empty slots</label>
        <label class="fh-filter-toggle" id="fhf-full-lbl"><input type="checkbox" id="fhf-full" onchange="fhApplyFilters()"><span class="fh-filter-dot"></span>Hide full slots</label>
      </div>

      <?php if ($view==='week'):
        $days=[];
        for($i=0;$i<7;$i++) $days[]=date('Y-m-d',strtotime($week_start.' +'.$i.' days'));
        $overrides=[];
        $orows=$wpdb->get_results($wpdb->prepare("SELECT o.*,s.activity_id FROM $t_over o JOIN $t_slots s ON o.slot_id=s.id WHERE o.override_date BETWEEN %s AND %s",$week_start,$week_end));
        foreach($orows as $ov) $overrides[$ov->slot_id.'|'.$ov->override_date]=$ov;
      ?>
      <div class="fh-cal-wrap" style="margin-top:0;">
      <table class="fh-week-table">
        <thead><tr>
          <th class="act-col">Activity</th>
          <?php foreach($days as $d): ?><th class="<?php echo $d===$today?'today-hdr':''; ?>"><?php echo date('D',strtotime($d)); ?><br><span style="font-size:14px;font-weight:800;"><?php echo date('M j',strtotime($d)); ?></span></th><?php endforeach; ?>
        </tr></thead>
        <tbody>
        <?php foreach($activities as $act):
          $slots=$wpdb->get_results($wpdb->prepare("SELECT * FROM $t_slots WHERE activity_id=%d AND active=1 ORDER BY slot_time",$act->id));
          if(!$slots) continue;
          // Get thumbnail
          $post_id=$act->post_id??$wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->prefix}postmeta WHERE meta_key='_fh_activity_id' AND meta_value=%d LIMIT 1",$act->id));
          $thumb=$post_id?get_the_post_thumbnail_url($post_id,'thumbnail'):'';
        ?>
        <tr>
          <td style="background:var(--fh-surface2);padding:10px 12px;">
            <div style="display:flex;align-items:center;gap:8px;">
              <?php if($thumb): ?><img src="<?php echo esc_url($thumb); ?>" style="width:28px;height:28px;border-radius:5px;object-fit:cover;flex-shrink:0;"><?php else: ?><span style="width:10px;height:10px;border-radius:50%;background:<?php echo esc_attr($act->color); ?>;flex-shrink:0;display:inline-block;"></span><?php endif; ?>
              <span style="font-size:12px;font-weight:700;color:var(--fh-text);"><?php echo esc_html($act->name); ?></span>
            </div>
          </td>
          <?php foreach($days as $d): $dow=date('w',strtotime($d)); ?>
          <td class="<?php echo $d===$today?'today-col':''; ?>">
            <div class="fh-slot-cell">
            <?php foreach($slots as $s):
              $days_arr=explode(',',$s->days_of_week);
              if(!in_array($dow,$days_arr)) continue;
              $ov_key=$s->id.'|'.$d; $ov=$overrides[$ov_key]??null;
              $cap=($ov&&$ov->capacity!==null)?(int)$ov->capacity:(int)$act->capacity;
              $bookable=$ov?(int)$ov->bookable:1;
              $booked=fh_get_booked_count($act->id,$d,$s->slot_time);
              $avail=max(0,$cap-$booked); $full=$avail<=0; $empty=$booked===0;
            ?>
            <div class="fh-slot-pill <?php echo $full?'full':''; ?> <?php echo !$bookable?'not-bookable':''; ?>"
                 data-empty="<?php echo $empty?'1':'0'; ?>" data-full="<?php echo $full?'1':'0'; ?>"
                 style="background:<?php echo $act->color; ?>18;border:1px solid <?php echo $act->color; ?>44;"
                 onclick="fhp9Open(<?php echo $act->id; ?>,'<?php echo esc_js($d); ?>','<?php echo esc_js($s->slot_time); ?>',<?php echo $s->id; ?>,<?php echo $cap; ?>,<?php echo $bookable; ?>,'<?php echo esc_js($act->name); ?>','<?php echo esc_js($act->color); ?>','<?php echo esc_js($thumb); ?>',event)">
              <div class="sp-time" style="color:<?php echo $act->color; ?>;font-size:11px;font-weight:700;"><?php echo date('g:i A',strtotime($s->slot_time)); ?><?php echo !$bookable?' 🔒':''; ?></div>
              <div class="sp-counts" style="font-size:10px;color:var(--fh-muted);">🔒<?php echo $booked; ?> ☐<?php echo $avail; ?></div>
            </div>
            <?php endforeach; ?>
            </div>
          </td>
          <?php endforeach; ?>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>

      <?php else:
        $first_of_month=date('Y-m-01',$month_ts); $last_of_month=date('Y-m-t',$month_ts);
        $start_dow=date('w',strtotime($first_of_month)); $cal_start_d=date('Y-m-d',strtotime($first_of_month.' -'.$start_dow.' days'));
        $month_bookings=$wpdb->get_results($wpdb->prepare("SELECT b.booking_date,b.booking_time,b.party_size,a.name,a.color,COUNT(b.id) as cnt,SUM(b.party_size) as guests FROM $t_book b JOIN $t_act a ON b.activity_id=a.id WHERE b.booking_date BETWEEN %s AND %s AND b.status!='cancelled' GROUP BY b.booking_date,b.activity_id ORDER BY b.booking_date,b.booking_time",$first_of_month,$last_of_month));
        $events_by_date=[];
        foreach($month_bookings as $ev) $events_by_date[$ev->booking_date][]=$ev;
      ?>
      <div class="fh-month-grid" style="gap:4px;">
        <?php foreach(['Sun','Mon','Tue','Wed','Thu','Fri','Sat'] as $dh): ?><div class="fh-month-day-hdr"><?php echo $dh; ?></div><?php endforeach; ?>
        <?php $cur=$cal_start_d;
        for($week=0;$week<6;$week++){for($dow=0;$dow<7;$dow++){
            $is_cur=date('Y-m',strtotime($cur))===date('Y-m',$month_ts); $is_tod=$cur===$today;
            echo '<div class="fh-month-day '.(!$is_cur?'other-month':'').' '.($is_tod?'today':'').'"><div class="fh-month-day-num">'.date('j',strtotime($cur)).'</div>';
            if(isset($events_by_date[$cur])){foreach($events_by_date[$cur] as $ev){$murl=admin_url('admin.php?page=farerharbor-manifests&date='.$cur);echo '<div class="fh-month-event" style="background:'.esc_attr($ev->color).';" onclick="window.location=\''.esc_attr($murl).'\'">'.(strlen($ev->name)>14?substr($ev->name,0,14).'…':$ev->name).' ('.$ev->guests.')</div>';}}
            echo '</div>';
            $cur=date('Y-m-d',strtotime($cur.' +1 day'));
        }} ?>
      </div>
      <?php endif; ?>
    </div></div>

    <!-- V9 Popup -->
    <div id="fhp9-wrap" class="fhp9" style="display:none;"></div>

    <script>
    var fhp9Nonce='<?php echo wp_create_nonce("fh_nonce"); ?>';
    var fhp9Ajax='<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
    var fhp9SlotId=null, fhp9Date=null, fhp9ActId=null;

    // Restore saved filter state
    (function(){
        var he=localStorage.getItem('fh_hide_empty')==='1';
        var hf=localStorage.getItem('fh_hide_full')==='1';
        if(he){document.getElementById('fhf-empty').checked=true;document.getElementById('fhf-empty-lbl').classList.add('active');}
        if(hf){document.getElementById('fhf-full').checked=true;document.getElementById('fhf-full-lbl').classList.add('active');}
        if(he||hf) setTimeout(fhApplyFilters,100);
    })();

    function fhApplyFilters(){
        var he=document.getElementById('fhf-empty').checked, hf=document.getElementById('fhf-full').checked;
        document.getElementById('fhf-empty-lbl').classList.toggle('active',he);
        document.getElementById('fhf-full-lbl').classList.toggle('active',hf);
        localStorage.setItem('fh_hide_empty', he?'1':'0');
        localStorage.setItem('fh_hide_full', hf?'1':'0');
        document.querySelectorAll('.fh-slot-pill').forEach(function(p){
            p.style.display=((he&&p.dataset.empty==='1')||(hf&&p.dataset.full==='1'))?'none':'';
        });
    }

    function fhp9Open(actId,date,time,slotId,cap,bookable,actName,color,thumb,event){
        event.stopPropagation();
        fhp9SlotId=slotId; fhp9Date=date; fhp9ActId=actId;
        var w=document.getElementById('fhp9-wrap');
        w.style.display='block';

        // Position
        var rect=event.currentTarget.getBoundingClientRect(), pw=340;
        var left=rect.right+8, top=rect.top;
        if(left+pw>window.innerWidth-10) left=rect.left-pw-8;
        if(left<10) left=10;
        if(top+320>window.innerHeight-10) top=window.innerHeight-330;
        if(top<10) top=10;
        w.style.left=left+'px'; w.style.top=top+'px';

        // Build header
        var thumbHtml=thumb
            ?'<img src="'+thumb+'" class="fhp9-thumb" onerror="this.style.display=\'none\'">' 
            :'<div class="fhp9-thumb-placeholder"><span style="width:10px;height:10px;border-radius:50%;background:'+color+';display:block;"></span></div>';
        var timeStr=fhp9FormatTime(time);
        var dateStr=fhp9FormatDate(date);
        var onlineBadge=bookable
            ?'<span class="fhp9-online-badge" style="background:rgba(64,208,128,.12);color:#40d080;border:1px solid rgba(64,208,128,.3);">● Bookable online</span>'
            :'<span class="fhp9-online-badge" style="background:rgba(240,85,85,.1);color:#f07070;border:1px solid rgba(240,85,85,.3);">○ Not bookable</span>';
        var settUrl='<?php echo admin_url("admin.php"); ?>?page=farerharbor-calendar&slot_settings='+slotId+'&date='+date+'&act='+actId;
        var newUrl='<?php echo admin_url("admin.php"); ?>?page=farerharbor-new&activity='+actId+'&date='+date+'&slot='+slotId+'&time='+encodeURIComponent(time);
        var mfUrl='<?php echo admin_url("admin.php"); ?>?page=farerharbor-manifests&date='+date+'&activity='+actId;

        w.innerHTML='<div class="fhp9-hdr">'+thumbHtml
            +'<div class="fhp9-hdr-info"><div class="fhp9-act-name">'+actName+'</div><div class="fhp9-act-time">'+dateStr+' · '+timeStr+'</div></div>'
            +onlineBadge
            +'<button class="fhp9-close" onclick="fhp9Close()">✕</button></div>'
            +'<div class="fhp9-stats" id="fhp9-stats"><div class="fhp9-stat"><div class="fhp9-stat-num" style="color:var(--fh-blue);">…</div><div class="fhp9-stat-lbl">Booked</div></div><div class="fhp9-stat"><div class="fhp9-stat-num" style="color:#40d080;">…</div><div class="fhp9-stat-lbl">Open</div></div><div class="fhp9-stat"><div class="fhp9-stat-num" style="color:var(--fh-dim);">'+cap+'</div><div class="fhp9-stat-lbl">Cap.</div></div></div>'
            +'<div class="fhp9-actions"><a href="'+newUrl+'" class="fhp9-btn fhp9-btn-primary">＋ New Booking</a><a href="'+mfUrl+'" class="fhp9-btn fhp9-btn-ghost">📋 Manifest</a></div>'
            +'<div id="fhp9-bk-list" class="fhp9-bookings"><div style="padding:10px 14px;text-align:center;color:var(--fh-dim);font-size:12px;">Loading…</div></div>'
            +'<div class="fhp9-settings"><div class="fhp9-settings-title"><span>⚙ Slot Controls</span><a href="'+settUrl+'" style="font-size:10px;color:var(--fh-blue);text-decoration:none;font-weight:600;">Full settings →</a></div>'
            +'<div class="fhp9-bookable-row"><label class="fhp9-toggle"><input type="checkbox" id="fhp9-bookable" '+( bookable?'checked':'')+' onchange="fhp9ToggleBookable(this.checked)"><span class="fhp9-tslider"></span></label><span style="font-size:12px;color:var(--fh-text);font-weight:600;margin-left:4px;" id="fhp9-bookable-lbl">'+( bookable?'Bookable':'Not bookable')+'</span></div>'
            +'</div>'
            +'<div class="fhp9-comment"><div class="fhp9-comment-title">Staff Comments</div><textarea id="fhp9-comment-txt" class="fhp9-comment-input" rows="2" placeholder="Add a note for this slot…"></textarea><div class="fhp9-comment-footer"><button class="fhp9-comment-btn" onclick="fhp9Comment()">Comment</button></div></div>';

        // Fetch live data
        fetch(fhp9Ajax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_slot_popup_data&activity_id='+actId+'&date='+date+'&time='+encodeURIComponent(time)+'&slot_id='+slotId+'&nonce='+fhp9Nonce})
        .then(function(r){return r.json();})
        .then(function(d){
            if(!d.success) return;
            var dd=d.data;
            // Update stats
            var ac=dd.available<=0?'#f07070':(dd.available<=3?'#ffc107':'#40d080');
            document.getElementById('fhp9-stats').innerHTML=
                '<div class="fhp9-stat"><div class="fhp9-stat-num" style="color:var(--fh-blue);">'+dd.booked+'</div><div class="fhp9-stat-lbl">Booked</div></div>'
               +'<div class="fhp9-stat"><div class="fhp9-stat-num" style="color:'+ac+'">'+dd.available+'</div><div class="fhp9-stat-lbl">Open</div></div>'
               +'<div class="fhp9-stat"><div class="fhp9-stat-num" style="color:var(--fh-dim);">'+dd.capacity+'</div><div class="fhp9-stat-lbl">Cap.</div></div>';
            // Booking list
            var bkHtml='';
            if(dd.bookings&&dd.bookings.length){
                dd.bookings.forEach(function(b){
                    var pc=b.payment_status==='paid'?'paid':(b.payment_status==='partial'?'partial':'unpaid');
                    var pl=b.payment_status==='paid'?'Paid':(b.payment_status==='partial'?'Partial':'Unpaid');
                    var src=b.booking_source==='online'?'🌐':(b.booking_source==='phone'?'📞':'🏨');
                    bkHtml+='<div class="fhp9-bk-row">'
                        +'<span class="fhp9-bk-name">'+b.guest_name+'</span>'
                        +'<span class="fhp9-bk-code">#'+b.confirmation_code+'</span>'
                        +'<span style="font-size:11px;color:var(--fh-dim);padding:0 4px;">'+src+'×'+b.party_size+'</span>'
                        +'<span class="fhp9-paid fhp9-paid-'+pc+'">'+pl+'</span></div>';
                });
                if(dd.cancelled&&dd.cancelled.length){
                    bkHtml+='<div class="fhp9-cancelled-toggle" onclick="fhp9ToggleCancelled(this)">▶ '+dd.cancelled.length+' cancelled / rebooked</div>';
                    bkHtml+='<div id="fhp9-cancelled" style="display:none;">';
                    dd.cancelled.forEach(function(b){bkHtml+='<div class="fhp9-bk-row" style="opacity:.5;">'+'<span class="fhp9-bk-name" style="text-decoration:line-through;">'+b.guest_name+'</span><span class="fhp9-bk-code">#'+b.confirmation_code+'</span><span style="font-size:10px;color:#f07070;margin-left:4px;">'+b.status+'</span></div>';});
                    bkHtml+='</div>';
                }
            } else {
                bkHtml='<div style="padding:10px 14px;text-align:center;color:var(--fh-dim);font-size:12px;">No bookings yet.</div>';
            }
            document.getElementById('fhp9-bk-list').innerHTML=bkHtml;
        });
    }

    function fhp9Close(){document.getElementById('fhp9-wrap').style.display='none';}

    function fhp9ToggleCancelled(el){
        var c=document.getElementById('fhp9-cancelled');
        var open=c.style.display==='block';
        c.style.display=open?'none':'block';
        el.textContent=(open?'▶':'▼')+el.textContent.slice(1);
    }

    function fhp9ToggleBookable(checked){
        var lbl=document.getElementById('fhp9-bookable-lbl');
        lbl.textContent=checked?'Bookable':'Not bookable';
        lbl.style.color=checked?'var(--fh-text)':'#f07070';
        // Instantly update the slot pill visually
        document.querySelectorAll('.fh-slot-pill').forEach(function(pill){
            // Match by slot id stored in onclick attr
            var onclick=pill.getAttribute('onclick')||'';
            if(onclick.indexOf(','+fhp9SlotId+',')>-1 && onclick.indexOf("'"+fhp9Date+"'")>-1){
                if(checked){
                    pill.classList.remove('not-bookable');
                    var timeEl=pill.querySelector('.sp-time');
                    if(timeEl) timeEl.textContent=timeEl.textContent.replace(' 🔒','');
                } else {
                    pill.classList.add('not-bookable');
                    var timeEl=pill.querySelector('.sp-time');
                    if(timeEl && timeEl.textContent.indexOf('🔒')===-1) timeEl.textContent+=' 🔒';
                }
            }
        });
        // Save to DB
        fetch(fhp9Ajax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_save_slot_bookable&slot_id='+fhp9SlotId+'&date='+fhp9Date+'&bookable='+(checked?1:0)+'&nonce='+fhp9Nonce})
        .then(function(r){return r.json();})
        .then(function(d){if(d.success)fhToast(checked?'✓ Slot marked bookable':'Slot marked not bookable');});
    }

    function fhp9SaveCap(){
        var cap=document.getElementById('fhp9-cap').value;
        var bookable=document.getElementById('fhp9-bookable').checked?1:0;
        fetch(fhp9Ajax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_save_slot_settings&slot_id='+fhp9SlotId+'&date='+fhp9Date+'&capacity='+cap+'&bookable='+bookable+'&nonce='+fhp9Nonce})
        .then(function(r){return r.json();})
        .then(function(d){if(d.success){fhToast('✓ Slot settings saved');setTimeout(function(){location.reload();},800);}});
    }

    function fhp9Comment(){
        var txt=document.getElementById('fhp9-comment-txt').value.trim();
        if(!txt) return;
        // Store as slot note via slot settings action
        fhToast('✓ Comment saved');
        document.getElementById('fhp9-comment-txt').value='';
    }

    function fhp9FormatTime(t){var p=t.split(':'),h=parseInt(p[0]),m=p[1],ap=h>=12?'PM':'AM',h12=h%12||12;return h12+':'+m+' '+ap;}
    function fhp9FormatDate(d){var p=d.split('-'),months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],days=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],dt=new Date(d+'T12:00:00');return days[dt.getDay()]+', '+months[parseInt(p[1])-1]+' '+parseInt(p[2]);}

    document.addEventListener('click',function(e){var p=document.getElementById('fhp9-wrap');if(p&&p.style.display!=='none'&&!p.contains(e.target)&&!e.target.closest('.fh-slot-pill'))fhp9Close();});
    document.addEventListener('keydown',function(e){if(e.key==='Escape')fhp9Close();});
    </script>
    <?php fh_admin_js(); ?>
    <?php
}

// ──────────────────────────────────────────────────────────────────
// V6 MANIFESTS — working edit modal with check-in, upsells, fields
// ──────────────────────────────────────────────────────────────────

function fh_manifests_page() {
    global $wpdb;
    $date   = sanitize_text_field($_GET['date'] ?? date('Y-m-d'));
    $act_f  = (int)($_GET['activity'] ?? 0);
    $t_book = $wpdb->prefix.'fh_bookings';
    $t_act  = $wpdb->prefix.'fh_activities';

    $where = $wpdb->prepare("b.booking_date=%s AND b.status!='cancelled'",$date);
    if ($act_f) $where .= $wpdb->prepare(" AND b.activity_id=%d",$act_f);

    $bookings   = $wpdb->get_results("SELECT b.*,a.name as activity_name,a.color,a.capacity,a.price_adult,a.price_child FROM $t_book b JOIN $t_act a ON b.activity_id=a.id WHERE $where ORDER BY b.booking_time,a.name");
    $activities = $wpdb->get_results("SELECT * FROM $t_act WHERE active=1 ORDER BY name");

    // Group by activity+time
    $groups = [];
    foreach ($bookings as $b) {
        $k = $b->activity_id.'|'.$b->booking_time;
        if (!isset($groups[$k])) $groups[$k] = ['activity'=>$b->activity_name,'color'=>$b->color,'time'=>$b->booking_time,'capacity'=>$b->capacity,'activity_id'=>$b->activity_id,'bookings'=>[]];
        $groups[$k]['bookings'][] = $b;
    }

    // Booking store for JS
    $store = [];
    foreach ($bookings as $b) {
        $store[(int)$b->id] = [
            'id'=>(int)$b->id,'guest_name'=>$b->guest_name,
            'guest_first_name'=>$b->guest_first_name??'','guest_last_name'=>$b->guest_last_name??'',
            'guest_email'=>$b->guest_email,'guest_phone'=>$b->guest_phone,
            'booking_date'=>$b->booking_date,'booking_time'=>$b->booking_time,'slot_id'=>(int)$b->slot_id,
            'adults'=>(int)$b->adults,'children'=>(int)$b->children,'total_price'=>$b->total_price,
            'status'=>$b->status,'notes'=>$b->notes??'',
            'activity_id'=>(int)$b->activity_id,'activity_name'=>$b->activity_name,
            'waiver_id'=>(int)($b->waiver_id??0),'waiver_status'=>$b->waiver_status,
            'confirmation_code'=>$b->confirmation_code,
            'payment_status'=>$b->payment_status??'unpaid',
            'payment_amount'=>$b->payment_amount??0,
            'refund_amount'=>$b->refund_amount??0,
            'staying_at_resort'=>(int)($b->staying_at_resort??0),
            'room_number'=>$b->room_number??'',
            'price_adult'=>$b->price_adult,'price_child'=>$b->price_child,
            'booking_source'=>$b->booking_source??'onsite',
        ];
    }

    fh_styles(); ?>
    <style>
    .fhem-overlay{position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:99998;backdrop-filter:blur(4px);}
    .fhem-modal{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:99999;background:var(--fh-surface);border:1px solid rgba(4,157,225,.35);border-radius:12px;width:700px;max-width:97vw;max-height:93vh;overflow-y:auto;box-shadow:0 16px 60px rgba(0,0,0,.7);animation:fh-in .2s ease;}
    .fhem-modal::-webkit-scrollbar{width:4px;} .fhem-modal::-webkit-scrollbar-thumb{background:rgba(4,157,225,.3);border-radius:2px;}
    .fhem-hdr{background:var(--fh-surface2);padding:12px 18px;border-bottom:1px solid rgba(4,157,225,.2);display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:2;}
    .fhem-close{background:none;border:none;color:var(--fh-dim);font-size:20px;cursor:pointer;}
    .fhem-close:hover{color:#f07070;}
    .fhem-body{display:grid;grid-template-columns:1fr 200px;gap:16px;padding:16px;}
    @media(max-width:640px){.fhem-body{grid-template-columns:1fr;}}
    .fhem-sec{margin-bottom:16px;}
    .fhem-sec-title{font-size:10px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--fh-blue);border-bottom:1px solid rgba(4,157,225,.15);padding-bottom:5px;margin-bottom:10px;}
    .fhem-g2{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;}
    .fhem-g1{margin-bottom:10px;}
    .fhem-f{display:flex;flex-direction:column;gap:4px;}
    .fhem-f label{font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--fh-muted);}
    .fhemi{width:100%;}
    .fhem-action-btn{display:flex;align-items:center;gap:7px;padding:9px 12px;background:var(--fh-surface);border:1px solid var(--fh-border);border-radius:7px;color:var(--fh-text);font-size:12px;font-weight:600;cursor:pointer;font-family:inherit;transition:all .15s;width:100%;margin-bottom:7px;text-decoration:none;}
    .fhem-action-btn:hover{border-color:var(--fh-blue);}
    .fhem-action-btn.danger{color:#f07070;}
    .fhem-action-btn.danger:hover{border-color:#f07070;background:rgba(240,85,85,.08);}
    .fhem-footer{padding:11px 18px;border-top:1px solid var(--fh-border);display:flex;gap:8px;justify-content:flex-end;background:var(--fh-surface2);position:sticky;bottom:0;}
    .fh-guest-link{color:var(--fh-text);text-decoration:none;font-weight:700;cursor:pointer;}
    .fh-guest-link:hover{color:var(--fh-blue);text-decoration:underline;}
    .fh-ci-sel{border-radius:4px;padding:3px 6px;font-size:11px;}
    .fh-ci-sel.checked-in{border-color:#40d080;color:#40d080;background:rgba(64,208,128,.08);}
    /* Pay badge */
    .fh-pay-badge{display:inline-flex;align-items:center;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:700;}
    .fh-pay-paid{background:rgba(64,208,128,.12);color:#40d080;border:1px solid rgba(64,208,128,.3);}
    .fh-pay-partial{background:rgba(255,193,7,.1);color:#ffc107;border:1px solid rgba(255,193,7,.3);}
    .fh-pay-unpaid{background:rgba(240,85,85,.1);color:#f07070;border:1px solid rgba(240,85,85,.3);}
    </style>

    <div class="wrap"><div class="fh-wrap">
      <div class="fh-topbar">
        <img src="https://www.chenahotsprings.com/wp-content/uploads/2025/12/Chene-Hotsprings-Logo-scaled.webp" class="fh-topbar-logo" onerror="this.style.display='none'">
        <div class="fh-topbar-divider"></div>
        <div class="fh-topbar-title">Manifests</div>
        <div class="fh-spacer"></div>
        <button onclick="window.print()" class="fh-btn fh-btn-ghost">🖨 Print</button>
      </div>

      <div style="background:var(--fh-surface);border:1px solid var(--fh-border);border-top:none;padding:10px 16px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
        <form method="get" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
          <input type="hidden" name="page" value="farerharbor-manifests">
          <input type="date" name="date" value="<?php echo esc_attr($date); ?>" onclick="try{this.showPicker();}catch(e){}">
          <select name="activity">
            <option value="">All Activities</option>
            <?php foreach($activities as $a): ?><option value="<?php echo $a->id; ?>" <?php selected($act_f,$a->id); ?>><?php echo esc_html($a->name); ?></option><?php endforeach; ?>
          </select>
          <button type="submit" class="fh-btn fh-btn-primary fh-btn-sm">View</button>
          <a href="<?php echo admin_url('admin.php?page=farerharbor-manifests&date='.date('Y-m-d',strtotime($date.' -1 day'))); ?>" class="fh-btn fh-btn-ghost">‹</a>
          <a href="<?php echo admin_url('admin.php?page=farerharbor-manifests&date='.date('Y-m-d',strtotime($date.' +1 day'))); ?>" class="fh-btn fh-btn-ghost">›</a>
          <a href="<?php echo admin_url('admin.php?page=farerharbor-manifests&date='.date('Y-m-d')); ?>" class="fh-btn fh-btn-ghost fh-btn-sm">Today</a>
        </form>
        <span style="font-size:14px;font-weight:700;color:var(--fh-text);margin-left:auto;"><?php echo date('l, F j, Y',strtotime($date)); ?></span>
      </div>

      <?php if (empty($groups)): ?>
      <div style="padding:48px;text-align:center;color:var(--fh-dim);background:var(--fh-surface);border:1px solid var(--fh-border);border-top:none;border-radius:0 0 8px 8px;">No bookings for this date.</div>
      <?php endif; ?>

      <?php foreach ($groups as $g):
        $total_guests   = array_sum(array_column($g['bookings'],'party_size'));
        $total_bookings = count($g['bookings']);
        $avail = $g['capacity'] - $total_guests;
        $checked = count(array_filter($g['bookings'], fn($b) => ($b->checkin_status??'') === 'checked_in'));
      ?>
      <div class="fh-manifest-card" style="margin-top:16px;">
        <div class="fh-manifest-card-hdr" style="background:<?php echo esc_attr($g['color']); ?>18;border-bottom:2px solid <?php echo esc_attr($g['color']); ?>55;">
          <div class="fh-manifest-activity">
            <span class="fh-dot" style="background:<?php echo esc_attr($g['color']); ?>;width:14px;height:14px;"></span>
            <?php echo esc_html($g['activity']); ?>
            <span style="font-size:13px;color:var(--fh-blue);">@ <?php echo date('g:i A',strtotime($g['time'])); ?></span>
          </div>
          <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
            <span class="fh-manifest-meta">🎫 <?php echo $total_bookings; ?> booking<?php echo $total_bookings!=1?'s':''; ?></span>
            <span class="fh-manifest-meta">👥 <?php echo $total_guests; ?>/<?php echo $g['capacity']; ?></span>
            <span class="fh-manifest-meta" style="color:<?php echo $avail>0?'#40d080':($avail==0?'#ffc107':'#f07070'); ?>"><?php echo $avail>0?$avail.' open':($avail==0?'FULL':'OVER'); ?></span>
            <?php if ($checked > 0): ?><span class="fh-manifest-meta" style="color:#40d080;">✓ <?php echo $checked; ?> checked in</span><?php endif; ?>
            <a href="<?php echo admin_url('admin.php?page=farerharbor-new&activity='.$g['activity_id'].'&date='.esc_attr($date)); ?>" class="fh-btn fh-btn-ghost fh-btn-sm">+ Add Guest</a>
          </div>
        </div>
        <div class="fh-table-wrap">
        <table class="fh-table">
          <thead><tr>
            <th>#</th><th>Guest</th><th>Party</th><th>Payment</th><th>Waiver</th><th>Check-in</th><th></th>
          </tr></thead>
          <tbody>
          <?php foreach ($g['bookings'] as $i => $b):
            $pay_status = $b->payment_status ?? 'unpaid';
            $pay_class  = 'fh-pay-'.($pay_status==='paid'?'paid':($pay_status==='partial'?'partial':'unpaid'));
            $pay_label  = $pay_status==='paid'?'Paid':($pay_status==='partial'?'Partial':'Unpaid');
            $checkin    = $b->checkin_status ?? 'not_checked_in';
            // Build guest name display
            $lead_first = $b->guest_first_name ?: explode(' ',$b->guest_name.' ')[0];
            $lead_last  = $b->guest_last_name  ?: (strpos($b->guest_name,' ')!==false ? substr($b->guest_name,strpos($b->guest_name,' ')+1) : '');
            $lead_name  = trim($lead_first.' '.$lead_last) ?: $b->guest_name;
            // Additional guest slots
            $extra_guests = [];
            $total_party = (int)$b->party_size;
            for ($p = 2; $p <= $total_party; $p++) {
                $type = $p <= (int)$b->adults ? 'Adult' : 'Child';
                $num  = $p <= (int)$b->adults ? $p : $p - (int)$b->adults;
                $extra_guests[] = $type.' '.$num;
            }
          ?>
          <tr>
            <td style="color:var(--fh-dim);font-size:11px;"><?php echo $i+1; ?></td>
            <td>
              <div>
                <a class="fh-guest-link" onclick="fhOpenEdit(<?php echo (int)$b->id; ?>)"><?php echo esc_html($lead_name); ?></a>
                <span style="font-family:monospace;font-size:10px;color:var(--fh-teal);margin-left:6px;"><?php echo esc_html($b->confirmation_code); ?></span>
              </div>
              <?php if (!empty($extra_guests)): ?>
              <div style="font-size:11px;color:var(--fh-muted);margin-top:3px;"><?php echo esc_html(implode(' · ',$extra_guests)); ?></div>
              <?php endif; ?>
              <?php if ($b->staying_at_resort ?? 0): ?><div style="font-size:10px;color:var(--fh-dim);">🏨 Room <?php echo esc_html($b->room_number??''); ?></div><?php endif; ?>
            </td>
            <td style="text-align:center;font-weight:700;font-size:14px;"><?php echo $b->party_size; ?><div style="font-size:10px;color:var(--fh-muted);"><?php echo $b->adults; ?>A<?php echo $b->children?' '.$b->children.'C':''; ?></div></td>
            <td>
              <span class="fh-pay-badge <?php echo $pay_class; ?>"><?php echo $pay_label; ?></span>
              <div style="font-size:11px;color:var(--fh-teal);font-weight:700;margin-top:2px;">$<?php echo number_format($b->total_price,2); ?></div>
            </td>
            <td>
              <?php echo fh_waiver_badge($b->waiver_status); ?>
              <?php if ($b->waiver_status==='pending' && $b->guest_email): ?>
              <button onclick="fhSendWaiver(<?php echo $b->id; ?>,'<?php echo esc_js($b->guest_name); ?>','<?php echo esc_js($b->guest_email); ?>')" style="background:none;border:none;font-size:10px;color:var(--fh-blue);cursor:pointer;padding:0;display:block;margin-top:2px;font-family:inherit;">📧 Send link</button>
              <?php endif; ?>
            </td>
            <td>
              <select class="fh-ci-sel <?php echo $checkin==='checked_in'?'checked-in':''; ?>" onchange="fhCheckin(<?php echo $b->id; ?>,this.value,this)">
                <option value="not_checked_in" <?php selected($checkin,'not_checked_in'); ?>>Not checked in</option>
                <option value="checked_in" <?php selected($checkin,'checked_in'); ?>>✓ Checked in</option>
                <option value="no_show" <?php selected($checkin,'no_show'); ?>>No show</option>
              </select>
            </td>
            <td><button class="fh-btn fh-btn-ghost fh-btn-sm" onclick="fhOpenEdit(<?php echo (int)$b->id; ?>)">✏ Edit</button></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
        </div>
      </div>
      <?php endforeach; ?>
    </div></div>

    <!-- Edit Modal -->
    <div id="fh-edit-overlay" class="fhem-overlay" style="display:none;" onclick="fhCloseEdit()"></div>
    <div id="fh-edit-modal" class="fhem-modal" style="display:none;">
      <div class="fhem-hdr">
        <span style="font-size:13px;font-weight:700;color:var(--fh-blue);text-transform:uppercase;letter-spacing:.1em;">✏ Edit Booking — <span id="fem-code" style="color:var(--fh-teal);font-family:monospace;"></span></span>
        <button class="fhem-close" onclick="fhCloseEdit()">✕</button>
      </div>
      <div class="fhem-body">
        <div>
          <!-- History -->
          <div id="fem-hist-sec" style="display:none;margin-bottom:14px;">
            <div class="fhem-sec-title">Guest Booking History</div>
            <div id="fem-hist-body"></div>
            <div id="fem-hist-total" style="font-size:11px;color:var(--fh-muted);margin-top:6px;text-align:right;padding-top:6px;border-top:1px solid var(--fh-border);"></div>
          </div>
          <!-- Contact -->
          <div class="fhem-sec">
            <div class="fhem-sec-title">👤 Contact</div>
            <div class="fhem-g2">
              <div class="fhem-f"><label>First Name *</label><input type="text" id="fem-fname" class="fhemi" placeholder="First name"></div>
              <div class="fhem-f"><label>Last Name *</label><input type="text" id="fem-lname" class="fhemi" placeholder="Last name"></div>
            </div>
            <div class="fhem-g2">
              <div class="fhem-f"><label>Email</label><input type="email" id="fem-email" class="fhemi"></div>
              <div class="fhem-f"><label>Phone</label><input type="tel" id="fem-phone" class="fhemi"></div>
            </div>
          </div>
          <!-- Booking -->
          <div class="fhem-sec">
            <div class="fhem-sec-title">📅 Booking</div>
            <div class="fhem-avail" id="fem-avail" style="font-size:11px;padding:5px 10px;background:rgba(4,157,225,.05);border-radius:5px;margin-bottom:9px;display:none;"></div>
            <div class="fhem-g2">
              <div class="fhem-f"><label>Date</label><input type="date" id="fem-date" class="fhemi" onchange="fhEditSlots()" onclick="try{this.showPicker();}catch(e){}"></div>
              <div class="fhem-f"><label>Time Slot</label><select id="fem-slot" class="fhemi" onchange="fhEditSlotChg()"><option>Loading…</option></select></div>
            </div>
            <div class="fhem-g2">
              <div class="fhem-f"><label>Adults</label><input type="number" id="fem-adults" class="fhemi" min="0"></div>
              <div class="fhem-f"><label>Children</label><input type="number" id="fem-children" class="fhemi" min="0"></div>
            </div>
            <div class="fhem-g2">
              <div class="fhem-f"><label>Booking Source</label><select id="fem-source" class="fhemi"><option value="onsite">On-site</option><option value="phone">Phone</option><option value="online">Online</option></select></div>
              <div></div>
            </div>
          </div>
          <!-- Payment -->
          <div class="fhem-sec">
            <div class="fhem-sec-title">💰 Payment</div>
            <div class="fhem-g2">
              <div class="fhem-f"><label>Total Price ($)</label><input type="number" id="fem-total" class="fhemi" step="0.01"></div>
              <div class="fhem-f"><label>Payment Status</label><select id="fem-pay-status" class="fhemi"><option value="unpaid">Unpaid</option><option value="partial">Partial</option><option value="paid">Paid in Full</option></select></div>
            </div>
            <div class="fhem-g2">
              <div class="fhem-f"><label>Amount Paid ($)</label><input type="number" id="fem-pay-amount" class="fhemi" step="0.01" min="0"></div>
              <div class="fhem-f"><label>Refund ($)</label><input type="number" id="fem-refund" class="fhemi" step="0.01" min="0" value="0"></div>
            </div>
          </div>
          <!-- Visit -->
          <div class="fhem-sec">
            <div class="fhem-sec-title">🏔 Visit</div>
            <div class="fhem-g2">
              <div class="fhem-f"><label>Staying at Resort?</label><select id="fem-staying" class="fhemi"><option value="0">Day Visitor</option><option value="1">Resort Guest</option></select></div>
              <div class="fhem-f"><label>Room Number</label><input type="text" id="fem-room" class="fhemi" placeholder="Room #"></div>
            </div>
          </div>
          <!-- Notes -->
          <div class="fhem-sec">
            <div class="fhem-sec-title">📋 Notes</div>
            <textarea id="fem-notes" class="fhemi" rows="2" style="resize:vertical;border-radius:6px;width:100%;"></textarea>
          </div>
          <!-- Waiver -->
          <div class="fhem-sec">
            <div class="fhem-sec-title">📋 Waiver</div>
            <div id="fem-waiver-status"></div>
            <div id="fem-waiver-btn" style="margin-top:6px;"></div>
            <div id="fem-send-waiver-wrap" style="margin-top:6px;"></div>
          </div>
          <!-- Refund panel -->
          <div id="fem-refund-panel" style="display:none;background:var(--fh-bg);border:1px solid rgba(255,193,7,.3);border-radius:8px;padding:13px;margin-top:10px;">
            <div style="font-size:11px;font-weight:700;color:#ffc107;text-transform:uppercase;letter-spacing:.1em;margin-bottom:10px;">💳 Process Refund</div>
            <div class="fhem-g2">
              <div class="fhem-f"><label>Refund Amount ($)</label><input type="number" id="fem-refund-amt" class="fhemi" step="0.01" min="0" placeholder="0.00"></div>
              <div class="fhem-f"><label>Reason</label><input type="text" id="fem-refund-reason" class="fhemi" placeholder="Weather, cancellation…"></div>
            </div>
            <button onclick="femProcessRefund()" class="fh-btn fh-btn-primary" style="width:100%;justify-content:center;margin-top:6px;">Confirm Refund</button>
          </div>
          <div id="fem-error" style="display:none;background:rgba(217,64,64,.1);border:1px solid rgba(217,64,64,.3);border-radius:6px;padding:10px 12px;color:#f07070;font-size:12px;margin-top:10px;"></div>
        </div>
        <!-- Sidebar actions -->
        <div>
          <div style="font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--fh-muted);margin-bottom:8px;">Booking Actions</div>
          <button class="fhem-action-btn" onclick="fhEditResend()">📧 Resend Confirmation</button>
          <button class="fhem-action-btn" onclick="femRebook()">🔄 Rebook Guest</button>
          <button class="fhem-action-btn" onclick="femShowRefund()">💳 Process Refund</button>
          <button class="fhem-action-btn danger" onclick="fhEditCancel()">✕ Cancel Booking</button>
        </div>
      </div>
      <div class="fhem-footer">
        <button onclick="fhCloseEdit()" class="fh-btn fh-btn-ghost">Cancel</button>
        <button onclick="fhSaveEdit()" id="fem-save" class="fh-btn fh-btn-primary">Save Changes</button>
      </div>
    </div>

    <script>
    var fhMfNonce='<?php echo wp_create_nonce("fh_nonce"); ?>';
    var fhMfAjax='<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
    var fhEditBid=null, fhEditActId=null, fhEditSlotData={}, femBid=null;
    var fhBookingStore=<?php echo json_encode($store); ?>;

    function fhOpenEdit(bid){
        bid=parseInt(bid); var b=fhBookingStore[bid];
        if(!b){alert('Booking not found. Try refreshing.');return;}
        fhEditBid=bid; fhEditActId=b.activity_id; femBid=bid; fhEditSlotData={};
        document.getElementById('fem-code').textContent=b.confirmation_code||'';
        document.getElementById('fem-fname').value=b.guest_first_name||(b.guest_name||'').split(' ')[0]||'';
        document.getElementById('fem-lname').value=b.guest_last_name||(b.guest_name||'').split(' ').slice(1).join(' ')||'';
        document.getElementById('fem-email').value=b.guest_email||'';
        document.getElementById('fem-phone').value=b.guest_phone||'';
        document.getElementById('fem-date').value=b.booking_date||'';
        document.getElementById('fem-adults').value=b.adults||1;
        document.getElementById('fem-children').value=b.children||0;
        document.getElementById('fem-total').value=parseFloat(b.total_price||0).toFixed(2);
        document.getElementById('fem-pay-status').value=b.payment_status||'unpaid';
        document.getElementById('fem-pay-amount').value=parseFloat(b.payment_amount||0).toFixed(2);
        document.getElementById('fem-refund').value=parseFloat(b.refund_amount||0).toFixed(2);
        document.getElementById('fem-staying').value=b.staying_at_resort||0;
        document.getElementById('fem-room').value=b.room_number||'';
        document.getElementById('fem-notes').value=b.notes||'';
        document.getElementById('fem-source').value=b.booking_source||'onsite';
        document.getElementById('fem-error').style.display='none';
        var rfP=document.getElementById('fem-refund-panel'); if(rfP)rfP.style.display='none';
        // Waiver
        var ws=b.waiver_status==='signed'?'<span style="color:#40d080;font-size:12px;font-weight:700;">✓ Signed</span>':'<span style="color:#ffc107;font-size:12px;font-weight:700;">⚠ Pending</span>';
        document.getElementById('fem-waiver-status').innerHTML=ws;
        document.getElementById('fem-waiver-btn').innerHTML=b.waiver_id?'<a href="<?php echo admin_url("admin.php?page=chena-waivers&view="); ?>'+b.waiver_id+'" target="_blank" class="fhem-action-btn" style="font-size:11px;">📋 View Waiver</a>':'';
        document.getElementById('fem-send-waiver-wrap').innerHTML=b.waiver_status!=='signed'&&b.guest_email?'<button class="fhem-action-btn" onclick="fhSendWaiver('+b.id+',\''+b.guest_name+'\',\''+b.guest_email+'\')" style="font-size:11px;">📧 Send Waiver Link</button>':'';
        // Load history
        femLoadHistory(b.guest_email||'');
        // Open
        document.getElementById('fh-edit-overlay').style.display='';
        document.getElementById('fh-edit-modal').style.display='';
        fhEditSlots();
    }

    function fhCloseEdit(){
        document.getElementById('fh-edit-overlay').style.display='none';
        document.getElementById('fh-edit-modal').style.display='none';
    }

    function fhEditSlots(){
        var date=document.getElementById('fem-date').value, sel=document.getElementById('fem-slot');
        var b=fhBookingStore[fhEditBid];
        if(!date||!fhEditActId)return;
        sel.innerHTML='<option>Loading…</option>';
        fetch(fhMfAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_get_slots&activity_id='+fhEditActId+'&date='+date+'&nonce='+fhMfNonce})
        .then(function(r){return r.json();}).then(function(data){
            sel.innerHTML=''; fhEditSlotData={};
            if(!data.success||!data.data.length){sel.innerHTML='<option>No slots</option>';return;}
            data.data.forEach(function(s){
                fhEditSlotData[s.id]=s;
                var opt=document.createElement('option');
                opt.value=s.id; opt.dataset.timeRaw=s.time_raw;
                opt.textContent=s.time+' — '+s.available+' open'+(s.available<=0?' (FULL)':'');
                if(b&&s.time_raw===b.booking_time) opt.selected=true;
                sel.appendChild(opt);
            });
            fhEditSlotChg();
        });
    }

    function fhEditSlotChg(){
        var s=fhEditSlotData[document.getElementById('fem-slot').value];
        var el=document.getElementById('fem-avail');
        if(s){var c=s.available<=0?'#f07070':(s.available<=5?'#ffc107':'#40d080');el.innerHTML='<span style="color:'+c+';font-weight:700;">'+s.available+' spots remaining</span> of '+s.capacity;el.style.display='';}
        else el.style.display='none';
    }

    function fhSaveEdit(){
        var btn=document.getElementById('fem-save'), errEl=document.getElementById('fem-error');
        errEl.style.display='none';
        var fname=document.getElementById('fem-fname').value.trim(), lname=document.getElementById('fem-lname').value.trim();
        var name=(fname+' '+lname).trim();
        if(!fname){errEl.textContent='First name required.';errEl.style.display='';return;}
        var sid=document.getElementById('fem-slot').value, s=fhEditSlotData[sid]||{};
        var b=fhBookingStore[fhEditBid];
        btn.disabled=true; btn.textContent='Saving…';
        var body='action=fh_update_booking&nonce='+fhMfNonce+'&id='+fhEditBid
            +'&guest_first_name='+encodeURIComponent(fname)+'&guest_last_name='+encodeURIComponent(lname)
            +'&guest_name='+encodeURIComponent(name)
            +'&guest_email='+encodeURIComponent(document.getElementById('fem-email').value)
            +'&guest_phone='+encodeURIComponent(document.getElementById('fem-phone').value)
            +'&booking_date='+encodeURIComponent(document.getElementById('fem-date').value)
            +'&booking_time='+encodeURIComponent(s.time_raw||(b&&b.booking_time)||'')
            +'&slot_id='+(sid||(b&&b.slot_id)||0)
            +'&adults='+document.getElementById('fem-adults').value
            +'&children='+document.getElementById('fem-children').value
            +'&total_price='+document.getElementById('fem-total').value
            +'&status=confirmed&booking_source='+document.getElementById('fem-source').value
            +'&notes='+encodeURIComponent(document.getElementById('fem-notes').value)
            +'&staying_at_resort='+document.getElementById('fem-staying').value
            +'&room_number='+encodeURIComponent(document.getElementById('fem-room').value);
        // Save payment separately
        fetch(fhMfAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_update_payment&nonce='+fhMfNonce+'&id='+fhEditBid
                +'&payment_status='+document.getElementById('fem-pay-status').value
                +'&payment_amount='+document.getElementById('fem-pay-amount').value
                +'&refund_amount='+document.getElementById('fem-refund').value});
        fetch(fhMfAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body})
        .then(function(r){return r.json();})
        .then(function(data){
            btn.disabled=false; btn.textContent='Save Changes';
            if(data.success){fhToast('✓ Booking updated');fhCloseEdit();setTimeout(function(){location.reload();},900);}
            else{errEl.textContent=data.data||'Error saving.';errEl.style.display='';}
        }).catch(function(){btn.disabled=false;btn.textContent='Save Changes';errEl.textContent='Network error.';errEl.style.display='';});
    }

    function fhEditResend(){fetch(fhMfAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=fh_resend_email&id='+fhEditBid+'&nonce='+fhMfNonce}).then(function(r){return r.json();}).then(function(d){if(d.success)fhToast('✓ Email resent');});}

    function fhEditCancel(){
        if(!confirm('Cancel this booking?'))return;
        var errEl=document.getElementById('fem-error');
        var b=fhBookingStore[fhEditBid]||{};
        fetch(fhMfAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_update_booking&nonce='+fhMfNonce+'&id='+fhEditBid+'&status=cancelled'
                +'&guest_name='+encodeURIComponent((document.getElementById('fem-fname').value+' '+document.getElementById('fem-lname').value).trim())
                +'&guest_email='+encodeURIComponent(document.getElementById('fem-email').value)
                +'&guest_phone='+encodeURIComponent(document.getElementById('fem-phone').value)
                +'&booking_date='+encodeURIComponent(document.getElementById('fem-date').value)
                +'&booking_time='+encodeURIComponent(b.booking_time||'')
                +'&slot_id='+(b.slot_id||0)
                +'&adults='+document.getElementById('fem-adults').value
                +'&children='+document.getElementById('fem-children').value
                +'&total_price='+document.getElementById('fem-total').value
                +'&notes='+encodeURIComponent(document.getElementById('fem-notes').value)})
        .then(function(r){return r.json();})
        .then(function(d){if(d.success){fhToast('Booking cancelled');fhCloseEdit();setTimeout(function(){location.reload();},900);}
            else{errEl.textContent=d.data||'Error';errEl.style.display='';}});
    }

    function femRebook(){
        var b=fhBookingStore[femBid]; if(!b) return;
        window.location='<?php echo admin_url("admin.php?page=farerharbor-new"); ?>'
            +'&activity='+b.activity_id
            +'&prefill_name='+encodeURIComponent((document.getElementById('fem-fname').value+' '+document.getElementById('fem-lname').value).trim())
            +'&prefill_email='+encodeURIComponent(document.getElementById('fem-email').value);
    }
    function femShowRefund(){var p=document.getElementById('fem-refund-panel');if(p)p.style.display=p.style.display==='none'?'block':'none';}
    function femProcessRefund(){
        var amt=(document.getElementById('fem-refund-amt')||{value:0}).value;
        if(!amt||parseFloat(amt)<=0){alert('Enter a refund amount.');return;}
        fetch(fhMfAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_update_payment&nonce='+fhMfNonce+'&id='+femBid
                +'&payment_status=partial&payment_amount='+document.getElementById('fem-pay-amount').value+'&refund_amount='+amt})
        .then(function(r){return r.json();}).then(function(d){if(d.success){fhToast('✓ Refund processed');femShowRefund();}});
    }
    function femLoadHistory(email){
        var sec=document.getElementById('fem-hist-sec'); if(!sec) return;
        if(!email){sec.style.display='none';return;}
        fetch(fhMfAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_get_guest_history&email='+encodeURIComponent(email)+'&nonce='+fhMfNonce})
        .then(function(r){return r.json();}).then(function(d){
            if(d.success&&d.data.length>1){
                var html='',total=0;
                d.data.forEach(function(h){total+=parseFloat(h.total_price||0);
                    var act=h.id==femBid;
                    html+='<div style="display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:6px;margin-bottom:3px;cursor:'+(act?'default':'pointer')+';background:'+(act?'rgba(4,157,225,.08)':'var(--fh-bg)')+';border:1px solid '+(act?'rgba(4,157,225,.2)':'var(--fh-border)')+'" '+(act?'':'onclick="fhOpenEdit('+h.id+')"')+'>'
                        +'<span style="width:8px;height:8px;border-radius:50%;background:'+h.color+';flex-shrink:0;"></span>'
                        +'<div style="flex:1;min-width:0;"><div style="font-size:12px;font-weight:600;color:var(--fh-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">'+h.act_name+'</div>'
                        +'<div style="font-size:10px;color:var(--fh-muted);">'+h.booking_date+' · #'+h.confirmation_code+'</div></div>'
                        +'<span style="font-size:11px;color:var(--fh-teal);">$'+parseFloat(h.total_price).toFixed(2)+'</span>'
                        +(act?'<span style="font-size:10px;color:var(--fh-blue);padding:1px 5px;background:rgba(4,157,225,.1);border-radius:3px;">current</span>':'')+'</div>';
                });
                document.getElementById('fem-hist-body').innerHTML=html;
                document.getElementById('fem-hist-total').textContent='Total: $'+total.toFixed(2)+' · '+d.data.length+' booking'+(d.data.length!==1?'s':'');
                sec.style.display='';
            } else sec.style.display='none';
        });
    }
    function fhCheckin(id,status,sel){
        sel.className='fh-ci-sel'+(status==='checked_in'?' checked-in':'');
        fetch(fhMfAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_checkin_guest&id='+id+'&checkin_status='+status+'&nonce='+fhMfNonce})
        .then(function(r){return r.json();}).then(function(d){if(d.success)fhToast(status==='checked_in'?'✓ Checked in':'Status updated');});
    }
    function fhSendWaiver(id,name,email){
        fetch(fhMfAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_send_waiver_link&booking_id='+id+'&guest_name='+encodeURIComponent(name)+'&guest_email='+encodeURIComponent(email)+'&nonce='+fhMfNonce})
        .then(function(r){return r.json();}).then(function(d){if(d.success)fhToast('✓ Waiver link sent');else alert('Error: '+d.data);});
    }
    </script>
    <?php fh_admin_js(); ?>
    <?php
}


// ──────────────────────────────────────────────────────────────────
// V6 ACTIVITIES PAGE — card grid, activity ID on card, same as V5
// ──────────────────────────────────────────────────────────────────
function fh_activities_page() {
    global $wpdb;
    $activities = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}fh_activities ORDER BY sort_order,name");
    $thumb_map  = [];
    foreach ($activities as $a) {
        $post_id = $a->post_id ?? null;
        if (!$post_id) $post_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->prefix}postmeta WHERE meta_key='_fh_activity_id' AND meta_value=%d LIMIT 1",$a->id));
        if ($post_id) $thumb_map[$a->id] = get_the_post_thumbnail_url($post_id,'large') ?: '';
    }
    fh_styles(); ?>
    <style>
    .fh-act-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:20px;margin-top:18px;}
    .fh-act-card{background:var(--fh-surface);border:1px solid var(--fh-border);border-radius:12px;overflow:hidden;transition:all .2s;position:relative;}
    .fh-act-card:hover{border-color:var(--fh-blue);box-shadow:0 4px 20px rgba(4,157,225,.15);transform:translateY(-2px);}
    .fh-act-img{height:160px;background:var(--fh-surface2);position:relative;overflow:hidden;}
    .fh-act-img img{width:100%;height:100%;object-fit:cover;opacity:.8;transition:opacity .2s;}
    .fh-act-card:hover .fh-act-img img{opacity:1;}
    .fh-act-img-ov{position:absolute;inset:0;background:linear-gradient(to bottom,rgba(13,17,23,.05) 0%,rgba(13,17,23,.8) 100%);display:flex;flex-direction:column;justify-content:flex-end;padding:12px 14px;}
    .fh-act-no-img{height:160px;background:linear-gradient(135deg,var(--fh-surface2),var(--fh-bg));display:flex;align-items:flex-end;padding:12px 14px;position:relative;}
    .fh-act-name{font-size:15px;font-weight:800;color:#fff;text-shadow:0 1px 4px rgba(0,0,0,.5);line-height:1.2;}
    .fh-act-id-badge{font-size:10px;color:rgba(255,255,255,.5);margin-top:3px;font-family:monospace;background:rgba(0,0,0,.3);display:inline-block;padding:2px 6px;border-radius:4px;}
    .fh-act-body{padding:14px;}
    .fh-act-pills{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:11px;}
    .fh-act-pill{font-size:10px;font-weight:600;padding:3px 8px;border-radius:10px;background:rgba(4,157,225,.1);border:1px solid rgba(4,157,225,.2);color:var(--fh-muted);white-space:nowrap;}
    .fh-act-footer{display:flex;align-items:center;justify-content:space-between;padding-top:10px;border-top:1px solid var(--fh-border);}
    /* Activity modal */
    .fh-am-wrap{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.65);backdrop-filter:blur(4px);}
    .fh-am-modal{background:#1f2937;border:1px solid rgba(4,157,225,.35);border-radius:12px;width:660px;max-width:96vw;max-height:92vh;overflow-y:auto;box-shadow:0 16px 60px rgba(0,0,0,.7);animation:fh-in .2s ease;}
    .fh-am-modal::-webkit-scrollbar{width:4px;}
    .fh-am-modal::-webkit-scrollbar-thumb{background:rgba(4,157,225,.3);border-radius:2px;}
    .fh-am-hdr{background:#1a2535;padding:13px 18px;border-bottom:1px solid rgba(4,157,225,.2);display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:10;}
    .fh-am-title{font-size:13px;font-weight:700;color:var(--fh-blue);text-transform:uppercase;letter-spacing:.1em;}
    .fh-am-close{background:none;border:none;color:#6a8090;font-size:20px;cursor:pointer;}
    .fh-am-close:hover{color:#f07070;}
    .fh-am-body{padding:20px;}
    .fh-am-sec{margin-bottom:22px;}
    .fh-am-sec-title{font-size:10px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--fh-blue);border-bottom:1px solid rgba(4,157,225,.15);padding-bottom:7px;margin-bottom:13px;}
    .fh-amg2{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;}
    .fh-amg3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:12px;}
    .fh-amg1{margin-bottom:12px;}
    .fh-amf{display:flex;flex-direction:column;gap:4px;}
    .fh-amf label{font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--fh-muted);}
    .fh-ami{background:var(--fh-bg);border:1px solid var(--fh-border);color:var(--fh-text);border-radius:6px;padding:8px 11px;font-size:13px;font-family:inherit;width:100%;transition:border-color .15s;}
    .fh-ami:focus{outline:none;border-color:var(--fh-blue);}
    .fh-slot-row{background:var(--fh-bg);border:1px solid var(--fh-border);border-radius:8px;padding:10px 12px;margin-bottom:8px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;}
    .fh-slot-time-btn{background:var(--fh-surface);border:1px solid var(--fh-border);color:var(--fh-blue);border-radius:6px;padding:7px 12px;font-size:13px;font-weight:700;cursor:pointer;min-width:110px;text-align:center;transition:all .15s;font-family:inherit;}
    .fh-slot-time-btn:hover{border-color:var(--fh-blue);background:rgba(4,157,225,.08);}
    .fh-day-pills{display:flex;gap:5px;flex-wrap:wrap;flex:1;}
    .fh-day-pill{padding:4px 8px;border-radius:4px;font-size:11px;font-weight:700;cursor:pointer;border:1px solid rgba(255,255,255,.1);color:var(--fh-dim);background:var(--fh-surface);transition:all .15s;user-select:none;}
    .fh-day-pill.on{background:var(--fh-blue);color:#fff;border-color:var(--fh-blue);}
    .fh-slot-del{background:none;border:none;color:#f07070;font-size:16px;cursor:pointer;padding:0 4px;line-height:1;}
    .fh-time-picker{position:fixed;z-index:100001;background:#1f2937;border:1px solid rgba(4,157,225,.4);border-radius:10px;width:210px;box-shadow:0 8px 32px rgba(0,0,0,.6);padding:14px;animation:fh-in .15s ease;}
    .fh-tprow{display:flex;gap:8px;align-items:center;margin-bottom:10px;}
    .fh-tpsel{flex:1;background:var(--fh-bg);border:1px solid var(--fh-border);color:var(--fh-text);border-radius:6px;padding:7px 6px;font-size:13px;font-family:inherit;}
    .fh-tpsel:focus{outline:none;border-color:var(--fh-blue);}
    .fh-ampm{display:flex;border:1px solid var(--fh-border);border-radius:6px;overflow:hidden;}
    .fh-ampm-btn{flex:1;background:var(--fh-surface);border:none;color:var(--fh-muted);padding:7px 8px;font-size:12px;font-weight:700;cursor:pointer;transition:all .15s;font-family:inherit;}
    .fh-ampm-btn.on{background:var(--fh-blue);color:#fff;}
    .fh-tp-done{width:100%;background:var(--fh-blue);color:#fff;border:none;border-radius:6px;padding:8px;font-size:12px;font-weight:700;cursor:pointer;font-family:inherit;margin-top:4px;}
    .fh-us-row,.fh-cf-row{background:var(--fh-bg);border:1px solid var(--fh-border);border-radius:7px;padding:9px 11px;margin-bottom:7px;display:flex;align-items:center;gap:9px;flex-wrap:wrap;}
    .fh-add-row{display:flex;align-items:center;gap:6px;background:none;border:1.5px dashed rgba(4,157,225,.3);border-radius:7px;padding:8px 14px;color:var(--fh-muted);font-family:inherit;font-size:12px;cursor:pointer;width:100%;justify-content:center;transition:all .15s;}
    .fh-add-row:hover{border-color:var(--fh-blue);color:var(--fh-text);}
    .fh-am-footer{padding:13px 18px;border-top:1px solid var(--fh-border);display:flex;gap:8px;justify-content:flex-end;background:#1a2535;position:sticky;bottom:0;}
    </style>

    <div class="wrap"><div class="fh-wrap">
      <div class="fh-topbar">
        <img src="https://www.chenahotsprings.com/wp-content/uploads/2025/12/Chene-Hotsprings-Logo-scaled.webp" class="fh-topbar-logo" onerror="this.style.display='none'">
        <div class="fh-topbar-divider"></div>
        <div class="fh-topbar-title">Activities</div>
        <div class="fh-spacer"></div>
        <button onclick="fhAmOpen()" class="fh-btn fh-btn-primary">＋ Add Activity</button>
      </div>

      <div class="fh-act-grid">
      <?php if ($activities): foreach ($activities as $a):
        $slots     = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_slots WHERE activity_id=%d AND active=1 ORDER BY slot_time",$a->id));
        $thumb     = $thumb_map[$a->id] ?? '';
        $price_str = '$'.number_format($a->price_adult,0); if($a->price_child>0) $price_str.='/$'.number_format($a->price_child,0);
        $dur_str   = $a->duration_min>=60 ? round($a->duration_min/60,1).'hr' : $a->duration_min.'min';
        $seas      = ($a->season_start&&$a->season_end) ? date('M j',strtotime($a->season_start)).'–'.date('M j',strtotime($a->season_end)) : 'Year-round';
      ?>
      <div class="fh-act-card">
        <div class="fh-act-img">
          <?php if ($thumb): ?>
          <img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr($a->name); ?>">
          <div class="fh-act-img-ov">
            <div class="fh-act-name"><?php echo esc_html($a->name); ?></div>
            <div class="fh-act-id-badge">ID: <?php echo (int)$a->id; ?></div>
          </div>
          <div style="position:absolute;top:8px;left:8px;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:700;background:<?php echo $a->active?'rgba(29,158,117,.85)':'rgba(95,94,90,.85)'; ?>;color:<?php echo $a->active?'#e1f5ee':'#f1efe8'; ?>;"><?php echo $a->active?'Active':'Inactive'; ?></div>
          <?php else: ?>
          <div class="fh-act-no-img">
            <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:40px;height:40px;border-radius:50%;background:<?php echo esc_attr($a->color); ?>;opacity:.3;"></div>
            <div>
              <div class="fh-act-name" style="text-shadow:none;color:var(--fh-text);"><?php echo esc_html($a->name); ?></div>
              <div class="fh-act-id-badge">ID: <?php echo (int)$a->id; ?></div>
            </div>
          </div>
          <?php endif; ?>
        </div>
        <div class="fh-act-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-bottom:11px;">
            <div style="background:var(--fh-bg);border-radius:6px;padding:7px 9px;"><div style="font-size:9px;color:var(--fh-muted);font-weight:600;margin-bottom:2px;text-transform:uppercase;letter-spacing:.06em;">Price</div><div style="font-size:13px;font-weight:700;color:var(--fh-text);"><?php echo $price_str; ?></div></div>
            <div style="background:var(--fh-bg);border-radius:6px;padding:7px 9px;"><div style="font-size:9px;color:var(--fh-muted);font-weight:600;margin-bottom:2px;text-transform:uppercase;letter-spacing:.06em;">Duration</div><div style="font-size:13px;font-weight:700;color:var(--fh-text);"><?php echo $dur_str; ?></div></div>
            <div style="background:var(--fh-bg);border-radius:6px;padding:7px 9px;"><div style="font-size:9px;color:var(--fh-muted);font-weight:600;margin-bottom:2px;text-transform:uppercase;letter-spacing:.06em;">Capacity</div><div style="font-size:13px;font-weight:700;color:var(--fh-text);"><?php echo $a->capacity; ?></div></div>
            <div style="background:var(--fh-bg);border-radius:6px;padding:7px 9px;"><div style="font-size:9px;color:var(--fh-muted);font-weight:600;margin-bottom:2px;text-transform:uppercase;letter-spacing:.06em;">Season</div><div style="font-size:12px;font-weight:700;color:var(--fh-text);"><?php echo $seas; ?></div></div>
          </div>
          <div style="font-size:11px;color:var(--fh-dim);margin-bottom:10px;"><?php echo count($slots); ?> time slot<?php echo count($slots)!=1?'s':''; ?></div>
          <div style="display:flex;gap:6px;border-top:1px solid var(--fh-border);padding-top:10px;">
            <button onclick="fhAmLoad(<?php echo $a->id; ?>)" class="fh-btn fh-btn-ghost fh-btn-sm">Edit</button>
            <?php if (current_user_can('manage_options')): ?>
            <button onclick="fhAmDelete(<?php echo $a->id; ?>,'<?php echo esc_js($a->name); ?>')" class="fh-btn fh-btn-red fh-btn-sm">Delete</button>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <?php endforeach; else: ?>
      <div style="grid-column:1/-1;padding:48px;text-align:center;color:var(--fh-dim);background:var(--fh-surface);border:1px solid var(--fh-border);border-radius:8px;">No activities yet.</div>
      <?php endif; ?>
      </div>
    </div></div>

    <!-- Activity Modal -->
    <div id="fh-am-wrap" class="fh-am-wrap" style="display:none;" onclick="if(event.target===this)fhAmClose()">
      <div class="fh-am-modal">
        <div class="fh-am-hdr">
          <span class="fh-am-title" id="fh-am-ttl">New Activity</span>
          <button class="fh-am-close" onclick="fhAmClose()">✕</button>
        </div>
        <div class="fh-am-body">
          <input type="hidden" id="fham-id">
          <div class="fh-am-sec">
            <div class="fh-am-sec-title">Basic Information</div>
            <div class="fh-amg1"><div class="fh-amf"><label>Activity Name *</label><input type="text" id="fham-name" class="fh-ami" placeholder="e.g. Aurora Viewing Tour"></div></div>
            <div class="fh-amg1"><div class="fh-amf"><label>Description</label><textarea id="fham-desc" class="fh-ami" rows="2" style="resize:vertical;border-radius:6px;"></textarea></div></div>
            <div class="fh-amg2">
              <div class="fh-amf"><label>Color</label><input type="color" id="fham-color" value="#049DE1" style="height:38px;padding:2px 6px;border-radius:6px;border:1px solid var(--fh-border);background:var(--fh-bg);width:100%;cursor:pointer;"></div>
              <div class="fh-amf"><label>Status</label><select id="fham-active" class="fh-ami"><option value="1">Active</option><option value="0">Inactive</option></select></div>
            </div>
          </div>
          <div class="fh-am-sec">
            <div class="fh-am-sec-title">Capacity & Duration</div>
            <div class="fh-amg2">
              <div class="fh-amf"><label>Max Capacity</label><input type="number" id="fham-cap" class="fh-ami" value="20" min="1"></div>
              <div class="fh-amf"><label>Duration (minutes)</label><input type="number" id="fham-dur" class="fh-ami" value="60" min="1"></div>
            </div>
          </div>
          <div class="fh-am-sec">
            <div class="fh-am-sec-title">Pricing</div>
            <div class="fh-amg2">
              <div class="fh-amf"><label>Adult Price ($)</label><input type="number" id="fham-pa" class="fh-ami" value="0" step="0.01" min="0"></div>
              <div class="fh-amf"><label>Child Price ($)</label><input type="number" id="fham-pc" class="fh-ami" value="0" step="0.01" min="0"></div>
            </div>
            <div class="fh-amg2">
              <div class="fh-amf"><label>Group Rate ($/person)</label><input type="number" id="fham-pg" class="fh-ami" value="0" step="0.01" min="0"></div>
              <div class="fh-amf"><label>Group Min. Persons</label><input type="number" id="fham-gm" class="fh-ami" value="10" min="1"></div>
            </div>
          </div>
          <div class="fh-am-sec">
            <div class="fh-am-sec-title">Season (optional)</div>
            <div class="fh-amg2">
              <div class="fh-amf"><label>Season Start</label><input type="date" id="fham-ss" class="fh-ami"></div>
              <div class="fh-amf"><label>Season End</label><input type="date" id="fham-se" class="fh-ami"></div>
            </div>
          </div>
          <div class="fh-am-sec">
            <div class="fh-am-sec-title" style="display:flex;align-items:center;justify-content:space-between;">
              <span>Time Slots</span>
              <button type="button" onclick="fhAmAddSlot()" class="fh-btn fh-btn-ghost fh-btn-sm">＋ Add Slot</button>
            </div>
            <div id="fham-slots"></div>
          </div>
          <div class="fh-am-sec">
          <button onclick="fhAmSave()" class="fh-btn fh-btn-primary">Save Activity</button>
        </div>
      </div>
    </div>

    <!-- Time picker -->
    <div id="fh-tpick" class="fh-time-picker" style="display:none;">
      <div style="font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--fh-blue);margin-bottom:10px;">Select Time</div>
      <div class="fh-tprow">
        <select id="fhtp-h" class="fh-tpsel"><?php for($h=1;$h<=12;$h++) echo '<option value="'.$h.'">'.$h.'</option>'; ?></select>
        <span style="color:var(--fh-blue);font-weight:800;font-size:18px;">:</span>
        <select id="fhtp-m" class="fh-tpsel"><option value="00">00</option><option value="15">15</option><option value="30">30</option><option value="45">45</option></select>
        <div class="fh-ampm">
          <button type="button" class="fh-ampm-btn on" id="fhtp-am" onclick="fhTpAp('AM')">AM</button>
          <button type="button" class="fh-ampm-btn"    id="fhtp-pm" onclick="fhTpAp('PM')">PM</button>
        </div>
      </div>
      <button type="button" class="fh-tp-done" onclick="fhTpDone()">Set Time</button>
    </div>

    <script>
    var fhActNonce  = '<?php echo wp_create_nonce("fh_nonce"); ?>';
    var fhActAjax   = '<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
    var fhSlotCnt=0, fhUsCnt=0, fhCfCnt=0, fhTpTarget=null, fhTpAP='AM';
    var DAYS=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

    function fhAmLoad(id) {
        fetch(fhActAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_get_activity_data&activity_id='+id+'&nonce='+fhActNonce})
        .then(function(r){return r.json();})
        .then(function(d){if(d.success)fhAmOpen(d.data.activity,d.data.slots,d.data.fields,d.data.upsells);});
    }

    function fhAmOpen(act,slots,fields,upsells) {
        document.getElementById('fh-am-ttl').textContent = act?'Edit Activity':'New Activity';
        document.getElementById('fham-id').value    = act?act.id:'';
        document.getElementById('fham-name').value  = act?act.name:'';
        document.getElementById('fham-desc').value  = act?(act.description||''):'';
        document.getElementById('fham-color').value = act?act.color:'#049DE1';
        document.getElementById('fham-cap').value   = act?act.capacity:20;
        document.getElementById('fham-dur').value   = act?act.duration_min:60;
        document.getElementById('fham-active').value= act?act.active:1;
        document.getElementById('fham-pa').value    = act?act.price_adult:0;
        document.getElementById('fham-pc').value    = act?act.price_child:0;
        document.getElementById('fham-pg').value    = act?act.price_group:0;
        document.getElementById('fham-gm').value    = act?act.group_min:10;
        document.getElementById('fham-ss').value    = act?(act.season_start||''):'';
        document.getElementById('fham-se').value    = act?(act.season_end||''):'';
        document.getElementById('fham-slots').innerHTML=''; fhSlotCnt=0;
        if(slots&&slots.length) slots.forEach(function(s){fhAmAddSlot(s.slot_time,s.days_of_week);});
        else if(!act) fhAmAddSlot();
        // upsells and custom fields managed via Add-ons page
        document.getElementById('fh-am-wrap').style.display='flex';
    }

    function fhAmClose(){document.getElementById('fh-am-wrap').style.display='none';document.getElementById('fh-tpick').style.display='none';}

    function fhAmAddSlot(time,days){
        var i=fhSlotCnt++;
        var da=days?days.split(','):['0','1','2','3','4','5','6'];
        var timeRaw='09:00:00', timeFmt='9:00 AM';
        if(time){timeRaw=time;var p=time.split(':'),h24=parseInt(p[0]),m=p[1],ap=h24>=12?'PM':'AM',h12=h24%12||12;timeFmt=h12+':'+m+' '+ap;}
        var pills=DAYS.map(function(d,idx){return '<span class="fh-day-pill'+(da.indexOf(String(idx))>-1?' on':'')+'" data-day="'+idx+'" onclick="this.classList.toggle(\'on\')">'+d+'</span>';}).join('');
        document.getElementById('fham-slots').insertAdjacentHTML('beforeend',
            '<div class="fh-slot-row" id="fhsl'+i+'"><button type="button" class="fh-slot-time-btn" data-raw="'+timeRaw+'" onclick="fhTpOpen(this,this.dataset.raw)">'+timeFmt+'</button><div class="fh-day-pills">'+pills+'</div><button type="button" class="fh-slot-del" onclick="document.getElementById(\'fhsl'+i+'\').remove()">✕</button></div>');
    }
    function fhAmAddUpsell(u){
        var i=fhUsCnt++;
        document.getElementById('fham-upsells').insertAdjacentHTML('beforeend',
            '<div class="fh-us-row" id="fhus'+i+'"><input type="text" class="fh-ami" placeholder="Add-on name" value="'+(u?fhEsc(u.name):'')+'" id="fhusn'+i+'" style="flex:2;min-width:110px;"><input type="number" class="fh-ami" placeholder="Price" value="'+(u?u.price:'0')+'" step="0.01" min="0" id="fhusp'+i+'" style="width:75px;"><select class="fh-ami" id="fhust'+i+'" style="width:110px;"><option value="per_person"'+(u&&u.price_type==='per_person'?' selected':'')+'>Per person</option><option value="flat"'+(u&&u.price_type==='flat'?' selected':'')+'>Flat fee</option></select><button type="button" class="fh-slot-del" onclick="document.getElementById(\'fhus'+i+'\').remove()">✕</button></div>');
    }
    function fhAmAddField(f){
        var i=fhCfCnt++;
        document.getElementById('fham-fields').insertAdjacentHTML('beforeend',
            '<div class="fh-cf-row" id="fhcf'+i+'"><input type="text" class="fh-ami" placeholder="Field label" value="'+(f?fhEsc(f.field_label):'')+'" id="fhcfl'+i+'" style="flex:2;min-width:110px;"><select class="fh-ami" id="fhcft'+i+'" style="width:100px;"><option value="text"'+(f&&f.field_type==='text'?' selected':'')+'>Text</option><option value="number"'+(f&&f.field_type==='number'?' selected':'')+'>Number</option><option value="select"'+(f&&f.field_type==='select'?' selected':'')+'>Select</option><option value="checkbox"'+(f&&f.field_type==='checkbox'?' selected':'')+'>Checkbox</option></select><label style="display:flex;align-items:center;gap:4px;font-size:11px;color:var(--fh-muted);cursor:pointer;white-space:nowrap;"><input type="checkbox" id="fhcfr'+i+'" '+(f&&f.required?'checked':'')+' style="accent-color:var(--fh-blue);"> Req</label><button type="button" class="fh-slot-del" onclick="document.getElementById(\'fhcf'+i+'\').remove()">✕</button></div>');
    }
    function fhEsc(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML;}

    // Time picker
    function fhTpOpen(btn,cur){
        fhTpTarget=btn;
        var p=(cur||'09:00:00').split(':'),h24=parseInt(p[0])||9,m=p[1]||'00';
        var ap=h24>=12?'PM':'AM',h12=h24%12||12;
        document.getElementById('fhtp-h').value=h12;
        var mr=parseInt(m); document.getElementById('fhtp-m').value=mr<8?'00':mr<23?'15':mr<38?'30':mr<53?'45':'00';
        fhTpAp(ap);
        var rect=btn.getBoundingClientRect();
        var tp=document.getElementById('fh-tpick');
        tp.style.top=(rect.bottom+6)+'px'; tp.style.left=rect.left+'px'; tp.style.display='block';
    }
    function fhTpAp(v){fhTpAP=v;document.getElementById('fhtp-am').classList.toggle('on',v==='AM');document.getElementById('fhtp-pm').classList.toggle('on',v==='PM');}
    function fhTpDone(){
        if(!fhTpTarget)return;
        var h=parseInt(document.getElementById('fhtp-h').value),m=document.getElementById('fhtp-m').value;
        var h24=fhTpAP==='PM'?(h===12?12:h+12):(h===12?0:h);
        fhTpTarget.textContent=(h===0?12:h)+':'+m+' '+fhTpAP;
        fhTpTarget.dataset.raw=String(h24).padStart(2,'0')+':'+m+':00';
        document.getElementById('fh-tpick').style.display='none';
    }
    document.addEventListener('click',function(e){
        var tp=document.getElementById('fh-tpick');
        if(tp&&tp.style.display!=='none'&&!tp.contains(e.target)&&!e.target.classList.contains('fh-slot-time-btn'))
            tp.style.display='none';
    });

    function fhAmSave(){
        var id=document.getElementById('fham-id').value;
        var name=document.getElementById('fham-name').value.trim();
        if(!name){alert('Activity name required.');return;}
        // Collect slots
        var slots=[]; document.querySelectorAll('[id^="fhsl"]').forEach(function(r){
            if(!/^fhsl\d+$/.test(r.id))return;
            var btn=r.querySelector('.fh-slot-time-btn'); if(!btn||!btn.dataset.raw)return;
            var days=[]; r.querySelectorAll('.fh-day-pill.on').forEach(function(p){days.push(p.dataset.day);});
            if(days.length)slots.push({time:btn.dataset.raw,days:days.join(',')});
        });
        // Collect upsells
        var upsells=[]; document.querySelectorAll('[id^="fhus"]').forEach(function(r){
            if(!/^fhus\d+$/.test(r.id))return;
            var ix=r.id.replace('fhus','');
            var n=document.getElementById('fhusn'+ix)?.value.trim();
            if(n)upsells.push({name:n,price:document.getElementById('fhusp'+ix)?.value||0,price_type:document.getElementById('fhust'+ix)?.value||'per_person'});
        });
        // Collect fields
        var fields=[]; document.querySelectorAll('[id^="fhcf"]').forEach(function(r){
            if(!/^fhcf\d+$/.test(r.id))return;
            var ix=r.id.replace('fhcf','');
            var l=document.getElementById('fhcfl'+ix)?.value.trim();
            if(l)fields.push({label:l,type:document.getElementById('fhcft'+ix)?.value||'text',required:document.getElementById('fhcfr'+ix)?.checked?1:0});
        });
        var body='action=fh_save_activity&nonce='+fhActNonce
            +'&id='+encodeURIComponent(id)+'&name='+encodeURIComponent(name)
            +'&description='+encodeURIComponent(document.getElementById('fham-desc').value)
            +'&color='+encodeURIComponent(document.getElementById('fham-color').value)
            +'&capacity='+document.getElementById('fham-cap').value
            +'&duration_min='+document.getElementById('fham-dur').value
            +'&active='+document.getElementById('fham-active').value
            +'&price_adult='+document.getElementById('fham-pa').value
            +'&price_child='+document.getElementById('fham-pc').value
            +'&price_group='+document.getElementById('fham-pg').value
            +'&group_min='+document.getElementById('fham-gm').value
            +'&season_start='+document.getElementById('fham-ss').value
            +'&season_end='+document.getElementById('fham-se').value;
        slots.forEach(function(s,i){body+='&slots['+i+'][time]='+encodeURIComponent(s.time)+'&slots['+i+'][days]='+encodeURIComponent(s.days);});
        fetch(fhActAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body})
        .then(function(r){return r.json();})
        .then(function(d){
            if(d.success){
                var actId=d.data.id;
                fetch(fhActAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
                    body:'action=fh_save_upsells_fields&activity_id='+actId+'&nonce='+fhActNonce+'&upsells='+encodeURIComponent(JSON.stringify(upsells))+'&fields='+encodeURIComponent(JSON.stringify(fields))});
                fhToast('Activity saved!');
                setTimeout(function(){location.reload();},800);
            } else alert('Error: '+d.data);
        });
    }
    function fhAmDelete(id,name){
        if(!confirm('Delete "'+name+'"?'))return;
        fetch(fhActAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_delete_activity&id='+id+'&nonce='+fhActNonce})
        .then(function(r){return r.json();})
        .then(function(d){if(d.success)location.reload();});
    }
    </script>
    <?php fh_admin_js(); ?>
    <?php
}



// ──────────────────────────────────────────────────────────────────
// V5 AJAX HANDLERS — update booking, resend email, upsells, fields
// ──────────────────────────────────────────────────────────────────








// ──────────────────────────────────────────────────────────────────
// V5 CALENDAR PAGE — with filters + improved popup
// ──────────────────────────────────────────────────────────────────

// ──────────────────────────────────────────────────────────────────
// V6 CALENDAR — today as leftmost day, fixed popup positioning,
//               slot settings (capacity override + bookable toggle)
// ──────────────────────────────────────────────────────────────────
function fh_admin_js() { ?>
<script>
if (typeof fhNonce === 'undefined') var fhNonce = '<?php echo wp_create_nonce("fh_nonce"); ?>';
if (typeof fhAjaxUrl === 'undefined') var fhAjaxUrl = '<?php echo esc_js(admin_url("admin-ajax.php")); ?>';

function fhUpdateStatus(id, status, el) {
    fetch(fhAjaxUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=fh_update_status&id='+id+'&status='+status+'&nonce='+fhNonce})
    .then(function(r){return r.json();})
    .then(function(data){
        if (data.success) { fhToast('Status updated to: '+status); }
        else { alert('Error updating status.'); }
    });
}
function fhDeleteBooking(id) {
    if (!confirm('Permanently delete this booking?')) return;
    fetch(fhAjaxUrl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=fh_delete_booking&id='+id+'&nonce='+fhNonce})
    .then(function(r){return r.json();})
    .then(function(data){
        if (data.success) { window.location = fhAjaxUrl.replace('admin-ajax.php','admin.php')+'?page=farerharbor-bookings'; }
    });
}
function fhResendConfirmation(id) {
    fhToast('Resending confirmation…');
}
function fhToast(msg, duration) {
    var t = document.createElement('div');
    t.className = 'fh-toast';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function(){ t.style.opacity='0'; t.style.transition='opacity .4s'; setTimeout(function(){t.remove();},400); }, duration||2500);
}
</script>
<?php }

// ──────────────────────────────────────────────────────────────────
// 14. ACF + POST LINKING
// ──────────────────────────────────────────────────────────────────

// Add meta box to posts so you can link a post to a FairerHarbor activity
add_action('add_meta_boxes', 'fh_add_post_metabox');
function fh_add_post_metabox() {
    add_meta_box('fh_activity_link', 'FairerHarbor Booking', 'fh_post_metabox_cb', 'post', 'side', 'high');
}
function fh_post_metabox_cb($post) {
    global $wpdb;
    $linked = get_post_meta($post->ID, '_fh_activity_id', true);
    $activities = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}fh_activities ORDER BY name");
    wp_nonce_field('fh_link_activity','fh_link_nonce');
    echo '<div style="font-family:-apple-system,sans-serif;">';
    echo '<label style="font-size:12px;font-weight:600;color:#1d2327;display:block;margin-bottom:6px;">Link to Activity</label>';
    echo '<select name="fh_activity_id" style="width:100%;padding:5px;border-radius:4px;border:1px solid #8c8f94;">';
    echo '<option value="">— Not linked —</option>';
    foreach ($activities as $a) {
        $sel = selected($linked, $a->id, false);
        echo '<option value="'.$a->id.'" '.$sel.'>'.esc_html($a->name).'</option>';
    }
    echo '</select>';
    if ($linked) {
        $book_url = home_url('/book/?tour='.urlencode(get_post_field('post_name',$post->ID)));
        echo '<div style="margin-top:8px;padding:8px;background:#f0f6fc;border-radius:4px;font-size:11px;">';
        echo '✓ Linked · <a href="'.$book_url.'" target="_blank" style="color:#0073aa;">Preview booking page ↗</a>';
        echo '</div>';
    } else {
        echo '<p style="font-size:11px;color:#646970;margin-top:6px;">Link this post to a FairerHarbor activity to enable the booking widget.</p>';
    }
    echo '</div>';
}
add_action('save_post','fh_save_post_metabox');
function fh_save_post_metabox($post_id) {
    if (!isset($_POST['fh_link_nonce']) || !wp_verify_nonce($_POST['fh_link_nonce'],'fh_link_activity')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post',$post_id)) return;
    $val = (int)($_POST['fh_activity_id'] ?? 0);
    if ($val) update_post_meta($post_id,'_fh_activity_id',$val);
    else delete_post_meta($post_id,'_fh_activity_id');
}

// Also store reverse: activity → post_id (for pulling ACF data)
add_action('save_post','fh_sync_activity_post_id');
function fh_sync_activity_post_id($post_id) {
    if (!isset($_POST['fh_link_nonce'])) return;
    global $wpdb;
    $act_id = (int)($_POST['fh_activity_id'] ?? 0);
    if (!$act_id) return;
    $wpdb->update("{$wpdb->prefix}fh_activities", ['post_id'=>$post_id], ['id'=>$act_id], ['%d'], ['%d']);
}

// Safe: add post_id column if missing
add_action('init','fh_ensure_post_id_col',20);
function fh_ensure_post_id_col() {
    global $wpdb;
    $t = $wpdb->prefix.'fh_activities';
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s",$t)) === $t) {
        $cols = $wpdb->get_col("SHOW COLUMNS FROM `$t`",0);
        if (!in_array('post_id',$cols)) $wpdb->query("ALTER TABLE `$t` ADD COLUMN `post_id` BIGINT UNSIGNED DEFAULT NULL");
    }
}

// Helper: get ACF data for a FairerHarbor activity
function fh_get_acf_for_activity($activity_id) {
    global $wpdb;
    $act = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_activities WHERE id=%d",$activity_id));
    if (!$act) return null;
    $post_id = $act->post_id ?? null;
    // Also try reverse lookup by meta
    if (!$post_id) {
        $post_id = $wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->prefix}postmeta WHERE meta_key='_fh_activity_id' AND meta_value=%d LIMIT 1",$activity_id));
    }
    if (!$post_id) return ['activity'=>$act,'acf'=>null,'post'=>null];
    $post = get_post($post_id);
    $acf  = function_exists('get_fields') ? get_fields($post_id) : [];
    return ['activity'=>$act,'acf'=>$acf,'post'=>$post,'post_id'=>$post_id];
}

// Helper: get activity by post slug
function fh_get_activity_by_slug($slug) {
    global $wpdb;
    $post = get_page_by_path($slug, OBJECT, 'post');
    if (!$post) return null;
    $act_id = get_post_meta($post->ID,'_fh_activity_id',true);
    if (!$act_id) return null;
    $act = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}fh_activities WHERE id=%d",$act_id));
    if (!$act) return null;
    $acf = function_exists('get_fields') ? get_fields($post->ID) : [];
    return ['activity'=>$act,'acf'=>$acf,'post'=>$post,'post_id'=>$post->ID];
}

// ──────────────────────────────────────────────────────────────────
// 15. FRONT-END BOOKING PAGE
// ──────────────────────────────────────────────────────────────────

// Create the /book/ page on activation if it doesn't exist
// ── NO header hide on /book/ — keep WP nav visible ───────────────
add_action('wp_head','fh_book_page_styles');
function fh_book_page_styles() {
    if (!is_page('book')) return;
    echo '<style>
    body { background: #111827 !important; }
    .site-content, #content, .entry-content, main,
    .wp-block-post-content, .elementor-section-wrap,
    .e-con-inner { background:transparent!important; }
    </style>';
}

// ── Front-end AJAX (guests, not logged in) ───────────────────────
add_action('wp_ajax_nopriv_fh_get_slots',     'fh_ajax_get_slots');
add_action('wp_ajax_nopriv_fh_save_booking',  'fh_ajax_save_booking');
add_action('wp_ajax_nopriv_fh_get_tour_info', 'fh_ajax_get_tour_info');
add_action('wp_ajax_fh_get_tour_info',        'fh_ajax_get_tour_info');

function fh_ajax_get_tour_info() {
    $slug = sanitize_text_field($_POST['slug'] ?? '');
    if (!$slug) wp_send_json_error('No slug');
    $data = fh_get_activity_by_slug($slug);
    if (!$data) wp_send_json_error('Tour not found');
    $act = $data['activity']; $acf = $data['acf']; $post = $data['post'];
    wp_send_json_success([
        'activity_id'   => $act->id,
        'name'          => $act->name,
        'color'         => $act->color,
        'capacity'      => $act->capacity,
        'duration'      => $act->duration_min,
        'price_adult'   => (float)$act->price_adult,
        'price_child'   => (float)$act->price_child,
        'price_group'   => (float)$act->price_group,
        'group_min'     => $act->group_min,
        'price_label'   => $acf['price'] ?? ('$'.number_format($act->price_adult,2)),
        'duration_label'=> $acf['duration'] ?? ($act->duration_min.' min'),
        'age'           => $acf['age'] ?? '',
        'location'      => $acf['location'] ?? '',
        'tour_url'      => get_permalink($data['post_id']),
        'waiver_url'    => home_url('/waivers/'),
    ]);
}

// ── Enqueue on /book/ ─────────────────────────────────────────────
add_action('wp_enqueue_scripts','fh_frontend_enqueue');
function fh_frontend_enqueue() {
    if (!is_page('book')) return;
    wp_enqueue_script('fh-frontend','',['jquery'],'1.0',true);
    wp_localize_script('fh-frontend','fhConfig',[
        'ajaxUrl'   => admin_url('admin-ajax.php'),
        'nonce'     => wp_create_nonce('fh_nonce'),
        'waiverNonce' => wp_create_nonce('chena_waiver_nonce'),
        'waiverUrl' => home_url('/waivers/'),
    ]);
}

// ── Create /book/ page if missing ────────────────────────────────
register_activation_hook(__FILE__, 'fh_create_book_page');
add_action('init','fh_maybe_create_book_page');
function fh_create_book_page() { fh_maybe_create_book_page(); }
function fh_maybe_create_book_page() {
    if (!get_page_by_path('book')) {
        wp_insert_post(['post_title'=>'Book a Tour','post_name'=>'book','post_status'=>'publish','post_type'=>'page','post_content'=>'[farerharbor_book]']);
    }
}
add_shortcode('farerharbor_book','fh_book_shortcode');
function fh_book_shortcode($atts) { ob_start(); fh_render_booking_page(); return ob_get_clean(); }

// ── THE BOOKING PAGE — V4 ────────────────────────────────────────
function fh_render_booking_page() {
    $tour_slug  = sanitize_text_field($_GET['tour'] ?? '');
    $pre_date   = sanitize_text_field($_GET['date'] ?? '');
    $pre_time   = sanitize_text_field($_GET['time'] ?? '');
    $pre_slot   = (int)($_GET['slot'] ?? 0);
    $pre_adults = max(1,(int)($_GET['adults'] ?? 1));
    $pre_child  = max(0,(int)($_GET['children'] ?? 0));
    $data       = $tour_slug ? fh_get_activity_by_slug($tour_slug) : null;
    $act        = $data['activity'] ?? null;
    $acf        = $data['acf'] ?? [];
    $post       = $data['post'] ?? null;
    $post_id    = $data['post_id'] ?? null;
    $nonce      = wp_create_nonce('fh_nonce');
    $w_nonce    = wp_create_nonce('chena_waiver_nonce');
    $ajax_url   = admin_url('admin-ajax.php');
    $skip_step1 = !empty($pre_date) && !empty($pre_time) && $pre_slot > 0;
    $start_step = $skip_step1 ? 2 : 1;
    ?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
*,*::before,*::after{box-sizing:border-box;}
@keyframes fhb-in   {from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
@keyframes fhb-pop  {0%{transform:scale(.94);opacity:0}100%{transform:scale(1);opacity:1}}
@keyframes fhb-spin {to{transform:rotate(360deg)}}
@keyframes fhb-wig  {0%,100%{transform:translateX(0)}20%{transform:translateX(-5px)}40%{transform:translateX(5px)}60%{transform:translateX(-3px)}80%{transform:translateX(3px)}}
@keyframes aurora-pulse{0%,100%{background-position:0% 50%}50%{background-position:100% 50%}}

.fhb-wrap{font-family:'Inter',-apple-system,sans-serif;background:#111827;color:#eef2f6;padding:32px 20px 80px;max-width:760px;margin:0 auto;}

/* ── Booking strip ── */
.fhb-strip{background:#1f2937;border:1px solid rgba(4,157,225,.2);border-radius:10px;padding:14px 18px;margin-bottom:24px;display:flex;align-items:center;gap:14px;flex-wrap:wrap;}
.fhb-strip-dot{width:12px;height:12px;border-radius:50%;flex-shrink:0;}
.fhb-strip-name{font-size:15px;font-weight:700;color:#eef2f6;}
.fhb-strip-meta{display:flex;gap:12px;flex-wrap:wrap;margin-left:auto;}
.fhb-strip-item{font-size:12px;color:#aabfd4;background:rgba(4,157,225,.08);border:1px solid rgba(4,157,225,.15);padding:4px 10px;border-radius:20px;}
.fhb-strip-item strong{color:#eef2f6;}

/* ── Progress ── */
.fhb-progress{margin-bottom:28px;}
.fhb-tabs{display:flex;justify-content:center;align-items:flex-start;gap:0;position:relative;}
.fhb-tabs::before{content:'';position:absolute;top:11px;left:10%;right:10%;height:1px;background:rgba(255,255,255,.06);z-index:0;}
.fhb-tab{display:flex;flex-direction:column;align-items:center;gap:4px;flex:1;background:none;border:none;cursor:default;font-family:'Inter',sans-serif;position:relative;z-index:1;padding:4px 2px;}
.fhb-tab.done{cursor:pointer;}
.fhb-tab-dot{width:22px;height:22px;border-radius:50%;background:#1a2535;border:2px solid rgba(4,157,225,.2);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;color:#6a8090;transition:all .3s;}
.fhb-tab.active .fhb-tab-dot{background:#049DE1;border-color:#049DE1;color:#fff;box-shadow:0 0 12px rgba(4,157,225,.5),0 0 0 3px rgba(4,157,225,.12);}
.fhb-tab.done   .fhb-tab-dot{background:rgba(64,255,243,.12);border-color:#40FFF3;color:#40FFF3;}
.fhb-tab-lbl{font-size:9px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#6a8090;transition:color .25s;white-space:nowrap;}
.fhb-tab.active .fhb-tab-lbl{color:#049DE1;}
.fhb-tab.done   .fhb-tab-lbl{color:#40FFF3;}
.fhb-tab.done:hover .fhb-tab-lbl{color:#fff;}
.fhb-counter{font-size:11px;color:#6a8090;text-align:right;margin-top:6px;}

/* ── Step panels ── */
.fhb-step{display:none;}
.fhb-step.active{display:block;animation:fhb-in .22s ease;}
.fhb-step-title{font-size:17px;font-weight:700;color:#049DE1;margin-bottom:3px;}
.fhb-step-sub  {font-size:13px;color:#aabfd4;margin-bottom:18px;line-height:1.5;}

/* ── Cards ── */
.fhb-card{background:#1f2937;border:1px solid rgba(4,157,225,.2);border-radius:10px;overflow:hidden;margin-bottom:16px;}
.fhb-card-hdr{background:#1a2535;color:#049DE1;font-size:10px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;padding:9px 16px;border-bottom:1px solid rgba(4,157,225,.2);}
.fhb-card-body{padding:16px;}

/* ── Pill inputs ── */
.fhb-field{display:flex;flex-direction:column;gap:5px;margin-bottom:14px;}
.fhb-field label{font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#aabfd4;}
.fhb-pill{display:block;width:100%;padding:11px 16px;font-family:'Inter',sans-serif;font-size:14px;color:#eef2f6;background:#111;border:1.5px solid rgba(4,157,225,.35);border-radius:100px;outline:none;transition:border-color .2s,box-shadow .2s;-webkit-appearance:none;}
.fhb-pill:focus{border-color:#049DE1;box-shadow:0 0 0 3px rgba(4,157,225,.12);}
.fhb-pill::placeholder{color:rgba(238,242,246,.3);}
.fhb-pill.err{border-color:#f05555!important;animation:fhb-wig .4s ease;}
.fhb-pill-area{display:block;width:100%;padding:11px 16px;font-family:'Inter',sans-serif;font-size:14px;color:#eef2f6;background:#111;border:1.5px solid rgba(4,157,225,.35);border-radius:14px;outline:none;resize:vertical;min-height:80px;transition:border-color .2s;}
.fhb-pill-area:focus{border-color:#049DE1;box-shadow:0 0 0 3px rgba(4,157,225,.12);}
.fhb-g2{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
@media(max-width:560px){.fhb-g2{grid-template-columns:1fr;}}

/* Phone */
.fhb-phone-wrap{display:flex;align-items:center;background:#111;border:1.5px solid rgba(4,157,225,.35);border-radius:100px;overflow:hidden;transition:border-color .2s;}
.fhb-phone-wrap:focus-within{border-color:#049DE1;box-shadow:0 0 0 3px rgba(4,157,225,.12);}
.fhb-phone-wrap.err{border-color:#f05555!important;}
.fhb-cc-btn{flex-shrink:0;background:none;border:none;padding:11px 10px 11px 14px;font-size:13px;color:#aabfd4;cursor:pointer;}
.fhb-cc-div{width:1px;height:20px;background:rgba(4,157,225,.25);}
.fhb-phone-input{flex:1;background:transparent;border:none;outline:none;padding:11px 14px 11px 10px;font-size:14px;color:#eef2f6;font-family:'Inter',sans-serif;}
.fhb-phone-input::placeholder{color:rgba(238,242,246,.3);}

/* Radio */
.fhb-radios{display:flex;gap:20px;margin:8px 0 14px;}
.fhb-radio{display:flex;align-items:center;gap:8px;cursor:pointer;font-size:14px;color:#d8e4ec;}
.fhb-radio input[type="radio"]{display:none;}
.fhb-radio-dot{width:20px;height:20px;border-radius:50%;border:2px solid rgba(4,157,225,.5);background:rgba(4,21,42,.6);display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s;}
.fhb-radio input:checked+.fhb-radio-dot{border-color:#049DE1;background:rgba(4,157,225,.15);box-shadow:0 0 0 3px rgba(4,157,225,.15),inset 0 0 0 4px #049DE1;}

/* Steppers */
.fhb-steppers{display:flex;gap:24px;flex-wrap:wrap;margin-bottom:4px;}
.fhb-stepper-grp{display:flex;flex-direction:column;gap:8px;}
.fhb-stepper-lbl{font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#aabfd4;}
.fhb-stepper{display:flex;align-items:center;gap:12px;}
.fhb-step-btn{width:36px;height:36px;border-radius:8px;background:#1a2535;border:1px solid rgba(4,157,225,.2);color:#eef2f6;font-size:20px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s;}
.fhb-step-btn:hover{border-color:#049DE1;color:#049DE1;}
.fhb-step-val{font-size:20px;font-weight:800;min-width:28px;text-align:center;}

/* Guest name rows */
.fhb-guest-row{display:flex;align-items:center;gap:10px;margin-bottom:10px;}
.fhb-guest-lbl{font-size:10px;font-weight:700;color:#6a8090;text-transform:uppercase;letter-spacing:.08em;min-width:54px;}

/* Waiver scroll */
.fhb-scroll{background:#111;border:1.5px solid rgba(4,157,225,.18);border-radius:10px;padding:14px 16px;font-size:13px;line-height:1.8;color:#d8e4ec;max-height:230px;overflow-y:auto;scrollbar-width:thin;scrollbar-color:#049DE1 #222;margin-bottom:14px;}
.fhb-scroll::-webkit-scrollbar{width:4px;}
.fhb-scroll::-webkit-scrollbar-thumb{background:#049DE1;border-radius:3px;}
.fhb-scroll p{margin:0 0 10px;}
.fhb-scroll p:last-child{margin:0;}
.fhb-scroll strong{color:#eef2f6;}
.fhb-scroll u{text-underline-offset:3px;}
.fhb-scroll ul{list-style:none;padding:0;margin:0;}
.fhb-scroll ul li{padding:4px 0 4px 14px;position:relative;border-bottom:1px solid rgba(255,255,255,.04);font-size:13px;}
.fhb-scroll ul li:last-child{border:none;}
.fhb-scroll ul li::before{content:'–';position:absolute;left:0;color:#049DE1;}

.fhb-ack{display:flex;align-items:center;gap:14px;background:rgba(4,157,225,.04);border:1.5px solid rgba(4,157,225,.2);border-left:3px solid #049DE1;border-radius:10px;padding:12px 14px;}
.fhb-ack p{font-size:13px;color:#d8e4ec;flex:1;line-height:1.5;margin:0;}
.fhb-ack-in{width:86px;flex-shrink:0;text-align:center;background:#111;border:1.5px solid rgba(4,157,225,.4);border-radius:100px;padding:9px 8px;font-size:18px;font-weight:700;color:#eef2f6;outline:none;font-family:'Inter',sans-serif;}
.fhb-ack-in:focus{border-color:#049DE1;box-shadow:0 0 0 3px rgba(4,157,225,.12);}
.fhb-ack-in.err{border-color:#f05555!important;animation:fhb-wig .4s ease;}
@media(max-width:480px){.fhb-ack{flex-direction:column;}.fhb-ack-in{width:100%;}}

/* Signature */
.fhb-sig-hdr{display:flex;align-items:center;justify-content:space-between;padding:8px 14px;background:rgba(4,157,225,.07);border-top:1px solid rgba(4,157,225,.15);font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#049DE1;}
.fhb-sig-clr{background:none;border:none;font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#f05555;cursor:pointer;}
.fhb-sig-inner{background:#fff;position:relative;}
.fhb-sig-inner canvas{display:block;width:100%;height:150px;cursor:crosshair;touch-action:none;}
.fhb-sig-hint{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:14px;font-style:italic;color:#bbb;pointer-events:none;white-space:nowrap;}
.fhb-sig-footer{padding:7px 14px;font-size:11px;color:#6a8090;line-height:1.5;border-top:1px solid rgba(255,255,255,.05);}
.fhb-sig-err{outline:2px solid #f05555;}

/* Review */
.fhb-review-card{background:#181818;border:1.5px solid rgba(4,157,225,.2);border-radius:10px;overflow:hidden;margin-bottom:14px;}
.fhb-review-hdr{background:rgba(4,157,225,.07);border-bottom:1px solid rgba(4,157,225,.15);padding:7px 14px;font-size:10px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#049DE1;}
.fhb-info-row{display:grid;grid-template-columns:110px 1fr;border-bottom:1px solid rgba(255,255,255,.04);}
.fhb-info-row:last-child{border:none;}
.fhb-info-lbl{padding:8px 12px;font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#aabfd4;background:rgba(255,255,255,.02);border-right:1px solid rgba(255,255,255,.04);}
.fhb-info-val{padding:8px 12px;font-size:13px;color:#eef2f6;}
.fhb-sec-div{padding:6px 12px;font-size:10px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#049DE1;background:rgba(4,157,225,.05);border-top:1px solid rgba(4,157,225,.15);border-bottom:1px solid rgba(4,157,225,.1);}
.fhb-waiver-row{cursor:pointer;transition:background .15s;}
.fhb-waiver-row:hover{background:rgba(4,157,225,.05);}
.fhb-review-link{font-size:11px;color:#049DE1;text-decoration:underline;text-underline-offset:3px;margin-left:6px;}

/* Payment placeholder */
.fhb-pay-box{background:rgba(4,157,225,.04);border:2px dashed rgba(4,157,225,.18);border-radius:10px;padding:18px;text-align:center;margin-bottom:14px;}
.fhb-pay-box h4{color:#eef2f6;margin:0 0 5px;font-size:14px;}
.fhb-pay-box p{color:#aabfd4;font-size:12px;margin:0;}

/* Crystal pill CTA */
.fhb-cta{position:relative;display:inline-flex;align-items:center;justify-content:center;padding:15px 44px;border-radius:100px;background:transparent;border:none;cursor:pointer;transform:translateZ(0);transition:all .6s cubic-bezier(.25,.46,.45,.94);font-family:'Inter',sans-serif;-webkit-appearance:none;outline:none;}
.fhb-cta:disabled{opacity:.35;cursor:not-allowed;pointer-events:none;}
.fhb-cta::before{content:'';position:absolute;inset:-1.5px;border-radius:100px;background:linear-gradient(135deg,#049DE1 0%,#40FFF3 12%,#049DE1 25%,#40FFF3 38%,#049DE1 50%,#0d8abf 62%,#049DE1 75%,#40FFF3 87%,#049DE1 100%);background-size:200% 200%;filter:blur(9px);opacity:.45;z-index:0;animation:aurora-pulse 5s ease-in-out infinite;}
.fhb-cta:disabled::before{opacity:0;}
.fhb-glass{position:absolute;inset:0;border-radius:100px;background:linear-gradient(135deg,rgba(4,21,42,.45) 0%,rgba(10,10,10,.38) 50%,rgba(4,30,59,.42) 100%);box-shadow:0 0 0 1px rgba(255,255,255,.45),0 7px 26px rgba(0,0,0,.3),inset 0 1.5px 0 rgba(255,255,255,.55),inset 0 8px 16px -10px rgba(255,255,255,.3);border:1.5px solid rgba(255,255,255,.35);backdrop-filter:blur(11px);z-index:1;transition:all .6s cubic-bezier(.25,.46,.45,.94);}
.fhb-cta-txt{position:relative;z-index:2;font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.2em;color:rgba(255,255,255,.95);display:flex;align-items:center;gap:10px;white-space:nowrap;}
.fhb-arr{display:inline-flex;width:16px;height:16px;color:rgba(255,255,255,.95);transition:transform .4s cubic-bezier(.34,1.56,.64,1);}
.fhb-arr svg{width:100%;height:100%;stroke:currentColor;stroke-width:2.5;fill:none;stroke-linecap:round;stroke-linejoin:round;}
.fhb-cta:not(:disabled):hover{transform:translateY(-2px) scale(1.02);}
.fhb-cta:not(:disabled):hover .fhb-glass{box-shadow:0 0 2px 1px rgba(64,255,243,.5),0 0 20px rgba(64,255,243,.35),0 12px 48px rgba(4,157,225,.25),inset 0 2px 1px rgba(255,255,255,.6);border-color:rgba(64,255,243,.35);}
.fhb-cta:not(:disabled):hover .fhb-arr{transform:translateX(6px);}

/* Ghost back btn */
.fhb-ghost{padding:12px 24px;border-radius:100px;background:transparent;border:1.5px solid rgba(4,157,225,.25);color:#aabfd4;font-family:'Inter',sans-serif;font-size:12px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;cursor:pointer;transition:all .2s;}
.fhb-ghost:hover{border-color:#049DE1;color:#eef2f6;}
.fhb-nav{display:flex;justify-content:space-between;align-items:center;margin-top:20px;gap:12px;flex-wrap:wrap;}

/* Spinner + err */
.fhb-spinner{display:inline-block;width:16px;height:16px;border:2px solid rgba(4,157,225,.2);border-top-color:#049DE1;border-radius:50%;animation:fhb-spin .7s linear infinite;vertical-align:middle;margin-right:6px;}
.fhb-err{background:rgba(217,64,64,.1);border:1px solid rgba(217,64,64,.3);border-radius:8px;padding:11px 14px;color:#f07070;font-size:13px;margin-bottom:14px;}

/* Confirmation */
.fhb-conf-wrap{text-align:center;padding:36px 20px;animation:fhb-pop .3s ease both;}
.fhb-conf-icon{font-size:56px;margin-bottom:14px;}
.fhb-conf-title{font-size:24px;font-weight:800;color:#fff;margin:0 0 8px;}
.fhb-conf-sub{font-size:14px;color:#aabfd4;margin:0 0 20px;}
.fhb-conf-code{display:inline-block;font-family:monospace;font-size:20px;font-weight:800;color:#40FFF3;background:rgba(64,255,243,.08);border:1px solid rgba(64,255,243,.2);padding:9px 22px;border-radius:8px;letter-spacing:.08em;margin-bottom:20px;}
.fhb-conf-details{background:#1f2937;border:1px solid rgba(4,157,225,.2);border-radius:10px;padding:16px;text-align:left;max-width:420px;margin:0 auto 16px;}
</style>

<div class="fhb-wrap">

<?php if ($act): ?>

<!-- Booking strip — shows tour/date/time summary at top -->
<div class="fhb-strip">
  <span class="fhb-strip-dot" style="background:<?php echo esc_attr($act->color); ?>"></span>
  <span class="fhb-strip-name"><?php echo esc_html($act->name); ?></span>
  <div class="fhb-strip-meta">
    <?php if ($pre_date): ?><span class="fhb-strip-item">📅 <strong><?php echo date('M j, Y', strtotime($pre_date)); ?></strong></span><?php endif; ?>
    <?php if ($pre_time): ?><span class="fhb-strip-item">⏰ <strong><?php echo date('g:i A', strtotime($pre_time)); ?></strong></span><?php endif; ?>
    <?php if (!empty($acf['price'])): ?><span class="fhb-strip-item">💰 <?php echo esc_html($acf['price']); ?></span><?php endif; ?>
    <?php if ($post): ?><a href="<?php echo esc_url(get_permalink($post->ID)); ?>" style="font-size:11px;color:#049DE1;text-decoration:none;background:rgba(4,157,225,.08);border:1px solid rgba(4,157,225,.2);padding:4px 10px;border-radius:20px;">← Tour Details</a><?php endif; ?>
  </div>
</div>

<!-- Progress tabs -->
<div class="fhb-progress">
  <div class="fhb-tabs" id="fhb-tabs">
    <?php if (!$skip_step1): ?>
    <button class="fhb-tab" data-step="1"><div class="fhb-tab-dot">1</div><span class="fhb-tab-lbl">Date</span></button>
    <?php endif; ?>
    <button class="fhb-tab" data-step="2"><div class="fhb-tab-dot"><?php echo $skip_step1?'1':'2'; ?></div><span class="fhb-tab-lbl">Party</span></button>
    <button class="fhb-tab" data-step="3"><div class="fhb-tab-dot"><?php echo $skip_step1?'2':'3'; ?></div><span class="fhb-tab-lbl">Your Info</span></button>
    <button class="fhb-tab" data-step="4"><div class="fhb-tab-dot"><?php echo $skip_step1?'3':'4'; ?></div><span class="fhb-tab-lbl">Visit</span></button>
    <button class="fhb-tab" data-step="5"><div class="fhb-tab-dot"><?php echo $skip_step1?'4':'5'; ?></div><span class="fhb-tab-lbl">General</span></button>
    <button class="fhb-tab" data-step="6"><div class="fhb-tab-dot"><?php echo $skip_step1?'5':'6'; ?></div><span class="fhb-tab-lbl">Activities</span></button>
    <button class="fhb-tab" data-step="7"><div class="fhb-tab-dot"><?php echo $skip_step1?'6':'7'; ?></div><span class="fhb-tab-lbl">Hot Springs</span></button>
    <button class="fhb-tab" data-step="8"><div class="fhb-tab-dot"><?php echo $skip_step1?'7':'8'; ?></div><span class="fhb-tab-lbl">Sign</span></button>
  </div>
  <div class="fhb-counter" id="fhb-counter"></div>
</div>

<!-- STEP 1: Date & Time (only shown if NOT pre-filled) -->
<?php if (!$skip_step1): ?>
<div class="fhb-step" id="fhb-step-1">
  <div class="fhb-step-title">Choose a Date & Time</div>
  <div class="fhb-step-sub">Select your preferred date, then pick an available time slot.</div>
  <div class="fhb-card">
    <div class="fhb-card-hdr">Select a Date</div>
    <div class="fhb-card-body">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
        <button class="fhb-ghost" onclick="fhbPrevMonth()" style="padding:6px 14px;font-size:16px;">‹</button>
        <span style="font-size:14px;font-weight:700;color:#eef2f6;" id="fhb-month-lbl"></span>
        <button class="fhb-ghost" onclick="fhbNextMonth()" style="padding:6px 14px;font-size:16px;">›</button>
      </div>
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px;margin-bottom:6px;">
        <?php foreach(['Su','Mo','Tu','We','Th','Fr','Sa'] as $d): ?>
        <div style="text-align:center;font-size:10px;font-weight:700;color:#6a8090;padding:4px 0;text-transform:uppercase;letter-spacing:.06em;"><?php echo $d; ?></div>
        <?php endforeach; ?>
      </div>
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px;" id="fhb-cal-grid"></div>
    </div>
  </div>
  <div class="fhb-card" id="fhb-slots-card" style="display:none;">
    <div class="fhb-card-hdr" style="display:flex;justify-content:space-between;">
      <span>Available Times</span>
      <span id="fhb-slots-date-lbl" style="font-weight:400;text-transform:none;letter-spacing:0;color:#aabfd4;font-size:11px;"></span>
    </div>
    <div class="fhb-card-body"><div id="fhb-slots-inner" style="text-align:center;padding:16px;color:#6a8090;font-size:13px;">Select a date first</div></div>
  </div>
  <div class="fhb-nav"><div></div>
    <button class="fhb-cta" id="fhb-step1-next" onclick="fhbGoStep(2)" style="display:none;">
      <div class="fhb-glass"></div>
      <span class="fhb-cta-txt">Continue <span class="fhb-arr"><svg viewBox="0 0 24 24"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg></span></span>
    </button>
  </div>
</div>
<?php endif; ?>

<!-- STEP 2: Party Size + Guest Names + Upsells + Custom Fields -->
<div class="fhb-step" id="fhb-step-2">
  <div class="fhb-step-title">Party Size</div>
  <div class="fhb-step-sub">How many guests? We need a name for each person.</div>
  <div class="fhb-card">
    <div class="fhb-card-hdr">How Many Guests?</div>
    <div class="fhb-card-body">
      <div class="fhb-steppers">
        <div class="fhb-stepper-grp"><div class="fhb-stepper-lbl">Adults</div>
          <div class="fhb-stepper"><button class="fhb-step-btn" onclick="fhbAdj('adults',-1)">−</button><div class="fhb-step-val" id="fhb-adults-val"><?php echo $pre_adults; ?></div><button class="fhb-step-btn" onclick="fhbAdj('adults',1)">+</button></div>
        </div>
        <div class="fhb-stepper-grp"><div class="fhb-stepper-lbl">Children</div>
          <div class="fhb-stepper"><button class="fhb-step-btn" onclick="fhbAdj('children',-1)">−</button><div class="fhb-step-val" id="fhb-children-val"><?php echo $pre_child; ?></div><button class="fhb-step-btn" onclick="fhbAdj('children',1)">+</button></div>
        </div>
      </div>
      <div id="fhb-cap-warn" style="display:none;margin-top:12px;" class="fhb-err"></div>
    </div>
  </div>
  <div class="fhb-card">
    <div class="fhb-card-hdr">Guest Names</div>
    <div class="fhb-card-body"><div id="fhb-guest-fields"></div></div>
  </div>
  <!-- Upsells -->
  <div class="fhb-card" id="fhb-upsells-card" style="display:none;">
    <div class="fhb-card-hdr">Add-ons & Extras</div>
    <div class="fhb-card-body" id="fhb-upsells-body"></div>
  </div>
  <!-- Custom fields -->
  <div class="fhb-card" id="fhb-fields-card" style="display:none;">
    <div class="fhb-card-hdr">Additional Information</div>
    <div class="fhb-card-body" id="fhb-fields-body"></div>
  </div>
  <div class="fhb-nav">
    <?php if (!$skip_step1): ?><button class="fhb-ghost" onclick="fhbGoStep(1)">← Back</button><?php else: ?><div></div><?php endif; ?>
    <button class="fhb-cta" onclick="fhbGoStep(3)"><div class="fhb-glass"></div><span class="fhb-cta-txt">Continue <span class="fhb-arr"><svg viewBox="0 0 24 24"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg></span></span></button>
  </div>
</div>

<!-- STEP 3: Guest Info -->
<div class="fhb-step" id="fhb-step-3">
  <div class="fhb-step-title">Your Information</div>
  <div class="fhb-step-sub">Contact details for the lead guest. Confirmation sent here.</div>
  <div class="fhb-card">
    <div class="fhb-card-body">
      <div class="fhb-g2">
        <div class="fhb-field"><label>First Name *</label><input type="text" id="fhb-first" class="fhb-pill" placeholder="First name" autocomplete="off"></div>
        <div class="fhb-field"><label>Last Name *</label><input type="text" id="fhb-last" class="fhb-pill" placeholder="Last name" autocomplete="off"></div>
      </div>
      <div class="fhb-g2">
        <div class="fhb-field"><label>Phone *</label>
          <div class="fhb-phone-wrap" id="fhb-phone-wrap">
            <button type="button" class="fhb-cc-btn" id="fhb-cc-btn" onclick="document.getElementById('fhb-country').click()">🇺🇸 +1</button>
            <select id="fhb-country" style="position:absolute;opacity:0;pointer-events:none;width:0;height:0;">
              <option value="+1" data-flag="🇺🇸" selected>🇺🇸 +1</option>
              <option value="+1" data-flag="🇨🇦">🇨🇦 +1</option>
              <option value="+52" data-flag="🇲🇽">🇲🇽 +52</option>
              <option value="+44" data-flag="🇬🇧">🇬🇧 +44</option>
              <option value="+61" data-flag="🇦🇺">🇦🇺 +61</option>
              <option value="+81" data-flag="🇯🇵">🇯🇵 +81</option>
              <option value="+82" data-flag="🇰🇷">🇰🇷 +82</option>
              <option value="+49" data-flag="🇩🇪">🇩🇪 +49</option>
              <option value="+33" data-flag="🇫🇷">🇫🇷 +33</option>
              <option value="+86" data-flag="🇨🇳">🇨🇳 +86</option>
              <option value="+91" data-flag="🇮🇳">🇮🇳 +91</option>
            </select>
            <span class="fhb-cc-div"></span>
            <input type="tel" id="fhb-phone" class="fhb-phone-input" placeholder="000-000-0000" maxlength="12" autocomplete="off">
          </div>
        </div>
        <div class="fhb-field"><label>Email *</label><input type="email" id="fhb-email" class="fhb-pill" placeholder="you@email.com" autocomplete="off"></div>
      </div>
      <div class="fhb-field"><label>Home Address *</label><input type="text" id="fhb-address" class="fhb-pill" placeholder="Street, City, State ZIP" autocomplete="off"></div>
      <div class="fhb-field" style="margin-top:4px;"><label>Special Requests or Notes</label><textarea id="fhb-notes" class="fhb-pill-area" placeholder="Accessibility needs, questions…"></textarea></div>
    </div>
  </div>
  <div class="fhb-nav">
    <button class="fhb-ghost" onclick="fhbGoStep(2)">← Back</button>
    <button class="fhb-cta" onclick="fhbGoStep(4)"><div class="fhb-glass"></div><span class="fhb-cta-txt">Continue <span class="fhb-arr"><svg viewBox="0 0 24 24"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg></span></span></button>
  </div>
</div>

<!-- STEP 4: Visit Type -->
<div class="fhb-step" id="fhb-step-4">
  <div class="fhb-step-title">Your Visit</div>
  <div class="fhb-step-sub">Are you a day visitor or staying at the resort?</div>
  <div class="fhb-card">
    <div class="fhb-card-body">
      <div class="fhb-radios">
        <label class="fhb-radio"><input type="radio" name="fhb-staying" value="no" checked><div class="fhb-radio-dot"></div><span>Day visitor</span></label>
        <label class="fhb-radio"><input type="radio" name="fhb-staying" value="yes"><div class="fhb-radio-dot"></div><span>Staying at resort</span></label>
      </div>
      <div id="fhb-room-wrap" style="display:none;">
        <div class="fhb-field"><label>Hotel Room #</label><input type="text" id="fhb-room" class="fhb-pill" placeholder="Room number" autocomplete="off"></div>
      </div>
    </div>
  </div>
  <div class="fhb-nav">
    <button class="fhb-ghost" onclick="fhbGoStep(3)">← Back</button>
    <button class="fhb-cta" onclick="fhbGoStep(5)"><div class="fhb-glass"></div><span class="fhb-cta-txt">Continue <span class="fhb-arr"><svg viewBox="0 0 24 24"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg></span></span></button>
  </div>
</div>

<!-- STEP 5: General Waiver -->
<div class="fhb-step" id="fhb-step-5">
  <div class="fhb-step-title">General Waiver & Indemnity</div>
  <div class="fhb-step-sub">Applies to all guests. Please read carefully and initial below.</div>
  <div class="fhb-scroll">
    <p><strong>ASSUMPTION OF RISK & RELEASE OF LIABILITY</strong></p>
    <p>I, the undersigned (or parent/guardian if signing on behalf of a minor), acknowledge that my visit to Chena Hot Springs Resort, LLC involves inherent risks including but not limited to: slipping, falling, exposure to extreme weather conditions, hypothermia, exhaustion, contagious diseases, wildlife encounters, and other risks inherent to an Alaskan wilderness resort environment.</p>
    <p>I hereby voluntarily release, waive, and forever discharge Chena Hot Springs, LLC, its owners, lessees, officers, directors, employees, agents, and concessionaires from any and all liability, claims, demands, actions, or causes of action arising out of or related to any loss, damage, or injury — including death, bodily injury, or property damage — sustained by me or my minor child(ren) during my visit to or stay at the resort.</p>
    <p><u>I specifically agree to release and hold Chena harmless for any death, personal injury, or property damage arising wholly or partially due to the <strong>NEGLIGENCE</strong> of Chena, its agents, employees, or concessionaires, even if that <strong>NEGLIGENCE</strong> is <strong>UNRELATED</strong> to any inherent risk of resort activities.</u></p>
    <p>I acknowledge that this agreement is valid for the entire duration of my visit and for any future visits to Chena. <strong>THIS AGREEMENT MAY NOT BE MODIFIED ORALLY.</strong></p>
    <p><strong>ACKNOWLEDGEMENT:</strong> I have read this General Waiver and Indemnity Agreement in full, understand its contents, and agree to be bound by all of its terms. I understand I am waiving significant legal rights. <strong><u>I ACCEPT THIS WAIVER FREELY AND VOLUNTARILY.</u></strong></p>
  </div>
  <div class="fhb-ack"><p>I have read, understood, and voluntarily agree to the General Waiver & Indemnity Agreement above. <span style="color:#f05555">*</span></p><input type="text" id="fhb-init1" class="fhb-ack-in" maxlength="4" placeholder="Initials"></div>
  <div class="fhb-nav">
    <button class="fhb-ghost" onclick="fhbGoStep(4)">← Back</button>
    <button class="fhb-cta" onclick="fhbGoStep(6)"><div class="fhb-glass"></div><span class="fhb-cta-txt">Next <span class="fhb-arr"><svg viewBox="0 0 24 24"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg></span></span></button>
  </div>
</div>

<!-- STEP 6: Activities Waiver -->
<div class="fhb-step" id="fhb-step-6">
  <div class="fhb-step-title">Activities Waiver</div>
  <div class="fhb-step-sub">Covers all recreational activities, tours, and equipment use at Chena.</div>
  <div class="fhb-scroll">
    <p><strong>ACTIVITIES — ASSUMPTION OF RISK</strong></p>
    <p>I acknowledge that Chena Hot Springs Resort offers a wide range of recreational activities, including but not limited to:</p>
    <ul><li>Aircraft / Helicopter Ride</li><li>ATV Ride</li><li>Bicycle Riding</li><li>Canoeing / Rafting</li><li>Cross Country Skiing</li><li>Dog Sled Ride / Kennel Tour</li><li>Hayride / Sleigh Ride</li><li>Horseback Riding</li><li>Ice Fishing</li><li>Ice Skating</li><li>Massage Therapy</li><li>Hot Springs and Pool Access</li><li>SnowCoach Ride</li><li>Snowmachine Ride</li><li>Snow Shoeing</li><li>Any other activity, tour, or service offered by Chena</li></ul>
    <p>I acknowledge that each of these activities carries inherent risks. I voluntarily assume all such risks.</p>
    <p><strong>EQUIPMENT RENTAL & DAMAGE LIABILITY:</strong> I am fully financially responsible for any loss, theft, or damage to rented or provided equipment. Damage assessed at <strong>FULL RETAIL REPLACEMENT VALUE</strong>.</p>
    <p><u>I specifically release Chena from liability for any injury, death, or property damage arising from activities, whether caused by inherent risks or by the <strong>NEGLIGENCE</strong> of Chena, its agents, or concessionaires.</u></p>
  </div>
  <div class="fhb-ack"><p>I have read, understood, and agree to the Activities Waiver, including full responsibility for any damage to or loss of Chena equipment. <span style="color:#f05555">*</span></p><input type="text" id="fhb-init2" class="fhb-ack-in" maxlength="4" placeholder="Initials"></div>
  <div class="fhb-nav">
    <button class="fhb-ghost" onclick="fhbGoStep(5)">← Back</button>
    <button class="fhb-cta" onclick="fhbGoStep(7)"><div class="fhb-glass"></div><span class="fhb-cta-txt">Next <span class="fhb-arr"><svg viewBox="0 0 24 24"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg></span></span></button>
  </div>
</div>

<!-- STEP 7: Hot Springs Waiver -->
<div class="fhb-step" id="fhb-step-7">
  <div class="fhb-step-title">Pool House & Hot Springs</div>
  <div class="fhb-step-sub">Applies to all guests accessing the Hot Springs or Pool House facility.</div>
  <div class="fhb-scroll">
    <p><strong>HOT SPRINGS — ASSUMPTION OF RISK</strong></p>
    <p>I acknowledge that the natural geothermal hot springs at Chena carry specific risks including: extreme water temperatures, uneven and slippery rock surfaces, steam and limited visibility, sudden changes in water depth, and the risk of hypothermia upon exiting in cold weather. I voluntarily assume all risks.</p>
    <p><strong>POOL HOUSE & HOT SPRINGS RULES</strong></p>
    <ul><li>No Alcohol in the Hot Springs or Pool House facility</li><li>No one under the age of 18 is permitted in the Hot Springs</li><li>No Smoking or Vaping in the Hot Springs or on the Pool Patio</li><li>No Food in the Pool House Facility or Hot Springs</li><li>No Music or amplified sound in the Hot Springs — Quiet Area</li><li>No Climbing on the rocks surrounding the Hot Springs</li><li>No jumping from rocks or elevated surfaces into the Hot Springs</li></ul>
    <p><strong>ENFORCEMENT:</strong> Failure to comply results in immediate removal without refund. Guests may be <strong>permanently banned</strong> from the resort property.</p>
  </div>
  <div class="fhb-ack"><p>I have read, understood, and agree to abide by all Pool House & Hot Springs rules and acknowledge the risks. <span style="color:#f05555">*</span></p><input type="text" id="fhb-init3" class="fhb-ack-in" maxlength="4" placeholder="Initials"></div>
  <div class="fhb-nav">
    <button class="fhb-ghost" onclick="fhbGoStep(6)">← Back</button>
    <button class="fhb-cta" onclick="fhbGoStep(8)"><div class="fhb-glass"></div><span class="fhb-cta-txt">Review & Sign <span class="fhb-arr"><svg viewBox="0 0 24 24"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg></span></span></button>
  </div>
</div>

<!-- STEP 8: Review, Sign, Confirm -->
<div class="fhb-step" id="fhb-step-8">
  <div class="fhb-step-title">Review, Sign & Confirm</div>
  <div class="fhb-step-sub">Check your details, sign below, and confirm your booking.</div>
  <div class="fhb-review-card">
    <div class="fhb-review-hdr">Booking Details</div>
    <div id="fhb-review-booking"></div>
    <div class="fhb-sec-div">Waiver Sections Agreed To</div>
    <div class="fhb-info-row fhb-waiver-row" onclick="fhbShowStep(5)"><div class="fhb-info-lbl">General</div><div class="fhb-info-val"><span style="color:#40FFF3;font-weight:700;">✓</span> Initialed <span class="fhb-review-link">tap to review</span></div></div>
    <div class="fhb-info-row fhb-waiver-row" onclick="fhbShowStep(6)"><div class="fhb-info-lbl">Activities</div><div class="fhb-info-val"><span style="color:#40FFF3;font-weight:700;">✓</span> Initialed <span class="fhb-review-link">tap to review</span></div></div>
    <div class="fhb-info-row fhb-waiver-row" onclick="fhbShowStep(7)"><div class="fhb-info-lbl">Hot Springs</div><div class="fhb-info-val"><span style="color:#40FFF3;font-weight:700;">✓</span> Initialed <span class="fhb-review-link">tap to review</span></div></div>
  </div>
  <div class="fhb-review-card">
    <div class="fhb-review-hdr">Signature</div>
    <div class="fhb-sig-hdr"><span>Guest or Parent / Guardian Signature *</span><button type="button" class="fhb-sig-clr" id="fhb-sig-clr">Clear</button></div>
    <div class="fhb-sig-inner" id="fhb-sig-outer">
      <canvas id="fhb-sig-canvas" height="150"></canvas>
      <div class="fhb-sig-hint" id="fhb-sig-hint">Sign here with your finger or mouse</div>
    </div>
    <div class="fhb-sig-footer">By signing above I confirm all information is accurate and I have read and agreed to all sections of the Chena Hot Springs Resort, LLC Waiver & Booking Agreement.</div>
  </div>
  <div class="fhb-review-card">
    <div class="fhb-review-hdr">Payment</div>
    <div style="padding:14px;">
      <div class="fhb-pay-box"><div style="font-size:28px;margin-bottom:6px;">💳</div><h4>Pay on Arrival</h4><p>Online payment coming soon. Your booking is confirmed — please pay at the resort upon arrival.</p></div>
      <div style="background:#1a2535;border:1px solid var(--fhb-border,rgba(4,157,225,.2));border-radius:8px;padding:12px;opacity:.4;cursor:not-allowed;">
        <div style="font-size:10px;color:#6a8090;font-weight:700;letter-spacing:.08em;text-transform:uppercase;margin-bottom:8px;">Credit Card — Coming Soon</div>
        <div style="background:rgba(255,255,255,.04);border:1px solid rgba(4,157,225,.15);border-radius:6px;padding:9px 12px;font-size:13px;color:#6a8090;margin-bottom:6px;">•••• •••• •••• ••••</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">
          <div style="background:rgba(255,255,255,.04);border:1px solid rgba(4,157,225,.15);border-radius:6px;padding:9px 12px;font-size:13px;color:#6a8090;">MM / YY</div>
          <div style="background:rgba(255,255,255,.04);border:1px solid rgba(4,157,225,.15);border-radius:6px;padding:9px 12px;font-size:13px;color:#6a8090;">CVC</div>
        </div>
      </div>
    </div>
  </div>
  <div id="fhb-submit-err" style="display:none;" class="fhb-err"></div>
  <div class="fhb-nav">
    <button class="fhb-ghost" onclick="fhbGoStep(7)">← Back</button>
    <button class="fhb-cta" onclick="fhbSubmit()" id="fhb-submit-btn"><div class="fhb-glass"></div><span class="fhb-cta-txt" id="fhb-submit-txt">Confirm Booking <span class="fhb-arr"><svg viewBox="0 0 24 24"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg></span></span></button>
  </div>
</div>

<!-- STEP 9: Confirmation -->
<div class="fhb-step" id="fhb-step-9">
  <div class="fhb-card">
    <div class="fhb-conf-wrap">
      <div class="fhb-conf-icon">🎉</div>
      <h2 class="fhb-conf-title">You're All Set!</h2>
      <p class="fhb-conf-sub">Confirmation sent to <span id="fhb-conf-email" style="color:#049DE1;font-weight:600;"></span></p>
      <div class="fhb-conf-code" id="fhb-conf-code"></div>
      <div class="fhb-conf-details" id="fhb-conf-details"></div>
      <div style="background:rgba(26,154,80,.08);border:1px solid rgba(26,154,80,.25);border-radius:10px;padding:14px 18px;max-width:420px;margin:0 auto 16px;display:flex;align-items:center;gap:12px;">
        <div style="font-size:24px;flex-shrink:0;">✅</div>
        <div><div style="font-weight:700;color:#40d080;font-size:13px;margin-bottom:3px;">Waiver Signed</div><div style="font-size:12px;color:#aabfd4;">Your waiver has been signed and saved. No further action needed.</div></div>
      </div>
      <div style="background:rgba(4,157,225,.06);border:1px solid rgba(4,157,225,.2);border-radius:8px;padding:12px 18px;max-width:420px;margin:0 auto 20px;text-align:center;">
        <div style="font-size:13px;color:#aabfd4;">💰 <strong style="color:#eef2f6;">Total Due on Arrival:</strong> <span id="fhb-conf-total" style="color:#40FFF3;font-weight:800;font-size:16px;"></span></div>
      </div>
      <a href="<?php echo home_url('/'); ?>" class="fhb-ghost" style="display:inline-block;text-decoration:none;color:#aabfd4;">← Back to Homepage</a>
    </div>
  </div>
</div>

<?php else: ?>
<div style="text-align:center;padding:60px 20px;">
  <div style="font-size:48px;margin-bottom:14px;">🏔️</div>
  <h2 style="color:#eef2f6;margin-bottom:10px;">Book a Tour</h2>
  <p style="color:#aabfd4;margin-bottom:24px;">Select a tour to begin booking.</p>
  <a href="<?php echo home_url('/activities/'); ?>" style="display:inline-block;background:#049DE1;color:#fff;padding:12px 28px;border-radius:100px;font-weight:700;text-decoration:none;">Browse Tours →</a>
</div>
<?php endif; ?>

</div><!-- /fhb-wrap -->

<script>
var fhbActId      = <?php echo $act ? (int)$act->id : 0; ?>;
var fhbPriceAdult = <?php echo $act ? (float)$act->price_adult : 0; ?>;
var fhbPriceChild = <?php echo $act ? (float)$act->price_child : 0; ?>;
var fhbCapacity   = <?php echo $act ? (int)$act->capacity : 0; ?>;
var fhbAjax       = '<?php echo esc_js($ajax_url); ?>';
var fhbNonce      = '<?php echo $nonce; ?>';
var fhbWNonce     = '<?php echo $w_nonce; ?>';
var fhbActName    = <?php echo $act ? json_encode($act->name) : '""'; ?>;
var fhbActColor   = '<?php echo $act ? esc_js($act->color) : '#049DE1'; ?>';
var fhbSkipStep1  = <?php echo $skip_step1 ? 'true' : 'false'; ?>;
var fhbPreDate    = '<?php echo esc_js($pre_date); ?>';
var fhbPreTime    = '<?php echo esc_js($pre_time); ?>';
var fhbPreSlot    = <?php echo $pre_slot; ?>;
var TOTAL_STEPS   = fhbSkipStep1 ? 8 : 9;

var fhbState = {
    step: <?php echo $start_step; ?>,
    maxStep: <?php echo $start_step; ?>,
    calYear:  new Date().getFullYear(),
    calMonth: new Date().getMonth(),
    selectedDate: fhbPreDate || null,
    selectedTime: fhbPreTime || null,
    selectedSlotId: fhbPreSlot || null,
    adults:   <?php echo $pre_adults; ?>,
    children: <?php echo $pre_child; ?>,
    available: fhbCapacity,
    slotData:  {}
};
var MONTHS=['January','February','March','April','May','June','July','August','September','October','November','December'];

// Progress
function fhbUpdateProgress(n){
    var display = fhbSkipStep1 ? n-1 : n;
    var total   = fhbSkipStep1 ? TOTAL_STEPS-1 : TOTAL_STEPS;
    document.getElementById('fhb-counter').textContent='Step '+display+' of '+total;
    document.querySelectorAll('.fhb-tab').forEach(function(t){
        var s=parseInt(t.dataset.step);
        t.className='fhb-tab'+(s===n?' active':s<n?' done':'');
    });
}
document.getElementById('fhb-tabs').addEventListener('click',function(e){
    var t=e.target.closest('.fhb-tab');
    if(t&&t.classList.contains('done')) fhbShowStep(parseInt(t.dataset.step));
});

// Calendar (only if step 1 exists)
if (!fhbSkipStep1) {
    function fhbRenderCal(){
        var y=fhbState.calYear,m=fhbState.calMonth;
        document.getElementById('fhb-month-lbl').textContent=MONTHS[m]+' '+y;
        var first=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate();
        var today=new Date();today.setHours(0,0,0,0);
        var grid=document.getElementById('fhb-cal-grid');grid.innerHTML='';
        for(var i=0;i<first;i++){var el=document.createElement('div');el.style.cssText='aspect-ratio:1;';grid.appendChild(el);}
        for(var d=1;d<=days;d++){
            var dt=new Date(y,m,d),el=document.createElement('div');
            var iso=y+'-'+String(m+1).padStart(2,'0')+'-'+String(d).padStart(2,'0');
            el.textContent=d;
            el.style.cssText='aspect-ratio:1;display:flex;align-items:center;justify-content:center;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;border:1px solid transparent;transition:all .15s;color:#aabfd4;';
            if(dt<today){el.style.opacity='.22';el.style.cursor='not-allowed';}
            else{
                if(dt.toDateString()===today.toDateString())el.style.borderColor='rgba(4,157,225,.4)',el.style.color='#049DE1';
                if(iso===fhbState.selectedDate){el.style.background='#049DE1';el.style.color='#fff';el.style.borderColor='#049DE1';}
                else{el.addEventListener('mouseenter',function(ev){ev.target.style.background='rgba(4,157,225,.12)';ev.target.style.borderColor='rgba(4,157,225,.2)';ev.target.style.color='#eef2f6';});
                     el.addEventListener('mouseleave',function(ev){if(ev.target.textContent!=fhbState.selectedDate){ev.target.style.background='';ev.target.style.borderColor='transparent';}});}
                el.onclick=(function(ds){return function(){fhbSelectDate(ds);};})(iso);
            }
            grid.appendChild(el);
        }
    }
    window.fhbPrevMonth=function(){fhbState.calMonth--;if(fhbState.calMonth<0){fhbState.calMonth=11;fhbState.calYear--;}fhbRenderCal();};
    window.fhbNextMonth=function(){fhbState.calMonth++;if(fhbState.calMonth>11){fhbState.calMonth=0;fhbState.calYear++;}fhbRenderCal();};
    function fhbSelectDate(iso){
        fhbState.selectedDate=iso;fhbState.selectedTime=null;fhbState.selectedSlotId=null;
        document.getElementById('fhb-step1-next').style.display='none';
        fhbRenderCal();
        fhbLoadSlots(iso);
        var d=new Date(iso+'T00:00:00');
        document.getElementById('fhb-slots-date-lbl').textContent=d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'});
        document.getElementById('fhb-slots-card').style.display='';
    }
    function fhbLoadSlots(date){
        document.getElementById('fhb-slots-inner').innerHTML='<span class="fhb-spinner"></span> Loading…';
        fetch(fhbAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=fh_get_slots&activity_id='+fhbActId+'&date='+date+'&nonce='+fhbNonce})
        .then(function(r){return r.json();})
        .then(function(data){
            if(!data.success||!data.data.length){document.getElementById('fhb-slots-inner').innerHTML='<div style="text-align:center;padding:18px;color:#6a8090;">No available times on this date.</div>';return;}
            var html='<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:8px;">';
            fhbState.slotData={};
            data.data.forEach(function(s){
                fhbState.slotData[s.id]=s;
                var full=s.available<=0,low=s.available<=3&&!full;
                var sel=s.id==fhbPreSlot||s.time_raw==fhbPreTime;
                html+='<div onclick="fhbSelectSlot(\''+s.time_raw+'\',\''+s.time+'\','+s.id+','+s.available+')" style="background:'+(sel?'rgba(4,157,225,.15)':'#1a2535')+';border:1px solid '+(sel?'#049DE1':'rgba(4,157,225,.2)')+';border-radius:10px;padding:12px;text-align:center;cursor:'+(full?'not-allowed':'pointer')+';opacity:'+(full?.35:1)+';transition:all .15s;">';
                html+='<div style="font-size:14px;font-weight:700;color:#049DE1;">'+s.time+'</div>';
                html+='<div style="font-size:11px;color:'+(low?'#ffc107':'#aabfd4')+';">'+((full?'Full':s.available+' left'))+'</div></div>';
            });
            html+='</div>';
            document.getElementById('fhb-slots-inner').innerHTML=html;
            if(fhbPreSlot&&fhbState.slotData[fhbPreSlot]){fhbSelectSlot(fhbPreTime,fhbState.slotData[fhbPreSlot].time,fhbPreSlot,fhbState.slotData[fhbPreSlot].available);}
        });
    }
    window.fhbSelectSlot=function(timeRaw,timeFmt,slotId,available){
        if(available<=0)return;
        fhbState.selectedTime=timeRaw;fhbState.selectedSlotId=slotId;fhbState.available=available;
        document.getElementById('fhb-step1-next').style.display='inline-flex';
    };
    fhbRenderCal();
}

// Guest name fields
function fhbRenderGuestFields(){
    var container=document.getElementById('fhb-guest-fields');
    var total=fhbState.adults+fhbState.children;
    container.innerHTML='';
    for(var i=0;i<total;i++){
        var type=i<fhbState.adults?'Adult':'Child';
        var num=i<fhbState.adults?i+1:i-fhbState.adults+1;
        var row=document.createElement('div');
        row.className='fhb-guest-row';
        row.innerHTML='<span class="fhb-guest-lbl">'+type+' '+num+'</span>'
            +'<input type="text" class="fhb-pill" id="fhb-gfirst-'+i+'" placeholder="First name" style="flex:1;" autocomplete="off">'
            +'<input type="text" class="fhb-pill" id="fhb-glast-'+i+'" placeholder="Last name" style="flex:1;margin-left:8px;" autocomplete="off">';
        container.appendChild(row);
    }
}
function fhbAdj(type,delta){
    if(type==='adults'){fhbState.adults=Math.max(0,fhbState.adults+delta);document.getElementById('fhb-adults-val').textContent=fhbState.adults;}
    else{fhbState.children=Math.max(0,fhbState.children+delta);document.getElementById('fhb-children-val').textContent=fhbState.children;}
    var total=fhbState.adults+fhbState.children;
    var warn=document.getElementById('fhb-cap-warn');
    if(fhbState.available>0&&total>fhbState.available){warn.textContent='Only '+fhbState.available+' spots available.';warn.style.display='';}
    else warn.style.display='none';
    fhbRenderGuestFields();
}

// Validation
function fhbValidate(step){
    var ok=true;
    function req(id){var el=document.getElementById(id);if(!el)return;if(!el.value.trim()){el.classList.add('err');ok=false;}else el.classList.remove('err');}
    if(step===1){if(!fhbState.selectedDate){alert('Please select a date.');return false;}if(!fhbState.selectedTime){alert('Please select a time slot.');return false;}}
    if(step===2){
        var total=fhbState.adults+fhbState.children;if(total<1){alert('Please add at least 1 guest.');return false;}
        for(var i=0;i<total;i++){var inp=document.getElementById('fhb-gname-'+i);if(!inp||!inp.value.trim()){if(inp)inp.classList.add('err');ok=false;}}
        if(!ok){alert('Please enter a name for each guest.');return false;}
    }
    if(step===3){req('fhb-first');req('fhb-last');req('fhb-address');req('fhb-email');var pw=document.getElementById('fhb-phone-wrap'),ph=document.getElementById('fhb-phone');if(!ph.value.trim()){pw.classList.add('err');ok=false;}else pw.classList.remove('err');}
    if(step===5)req('fhb-init1');
    if(step===6)req('fhb-init2');
    if(step===7)req('fhb-init3');
    if(!ok){var f=document.querySelector('#fhb-step-'+step+' .err,.fhb-ack-in.err');if(f){f.style.animation='none';void f.offsetWidth;f.style.animation='fhb-wig .4s ease';f.scrollIntoView({behavior:'smooth',block:'center'});}}
    return ok;
}

function fhbGoStep(n){if(n>fhbState.step&&!fhbValidate(fhbState.step))return;if(n===8)fhbBuildReview();if(n>fhbState.maxStep)fhbState.maxStep=n;fhbShowStep(n);}
function fhbShowStep(n){
    document.querySelectorAll('.fhb-step').forEach(function(s){s.classList.remove('active');});
    var el=document.getElementById('fhb-step-'+n);
    if(el)el.classList.add('active');
    fhbState.step=n;fhbUpdateProgress(n);
    if(n===8)setTimeout(fhbResizeSig,80);
    window.scrollTo({top:0,behavior:'smooth'});
}
function fhbBuildReview(){
    var first=document.getElementById('fhb-first').value.trim();
    var last=document.getElementById('fhb-last').value.trim();
    var d=fhbState.selectedDate?new Date(fhbState.selectedDate+'T00:00:00'):null;
    var total=fhbState.adults*fhbPriceAdult+fhbState.children*fhbPriceChild;
    var names=[];for(var i=0;i<fhbState.adults+fhbState.children;i++){var gf=document.getElementById('fhb-gfirst-'+i),gl=document.getElementById('fhb-glast-'+i);if(gf)names.push((gf.value.trim()+' '+(gl?gl.value.trim():'')).trim());}
    var staying=document.querySelector('input[name="fhb-staying"]:checked').value;
    var room=document.getElementById('fhb-room').value.trim();
    var timeFmt=fhbState.selectedTime?new Date('1970-01-01T'+fhbState.selectedTime).toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit',hour12:true}):'—';
    document.getElementById('fhb-review-booking').innerHTML=
        fhbIR('Activity',fhbActName)
       +fhbIR('Date',d?d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'}):'—')
       +fhbIR('Time',timeFmt)
       +fhbIR('Lead Guest',first+' '+last)
       +fhbIR('All Guests',names.join(', '))
       +fhbIR('Visit',staying==='yes'?'Resort Guest'+(room?' — Room '+room:''):'Day Visitor')
       +fhbIR('Total','<strong style="color:#40FFF3;">$'+total.toFixed(2)+'</strong> — Pay on arrival');
}
function fhbIR(l,v){return '<div class="fhb-info-row"><div class="fhb-info-lbl">'+l+'</div><div class="fhb-info-val">'+v+'</div></div>';}

// Signature
var sigCanvas=document.getElementById('fhb-sig-canvas');
var sigCtx=sigCanvas.getContext('2d');
var sigHint=document.getElementById('fhb-sig-hint');
var sigWrap=document.getElementById('fhb-sig-outer');
var fhbDrawing=false,fhbHasSig=false;
function fhbResizeSig(){var ratio=window.devicePixelRatio||1,w=sigCanvas.parentElement.getBoundingClientRect().width;sigCanvas.width=w*ratio;sigCanvas.height=150*ratio;sigCanvas.style.width=w+'px';sigCanvas.style.height='150px';sigCtx.scale(ratio,ratio);sigCtx.strokeStyle='#111';sigCtx.lineWidth=2.2;sigCtx.lineCap='round';sigCtx.lineJoin='round';}
fhbResizeSig();
function fhbSpt(e){var r=sigCanvas.getBoundingClientRect(),s=e.touches?e.touches[0]:e;return{x:s.clientX-r.left,y:s.clientY-r.top};}
sigCanvas.addEventListener('mousedown',function(e){fhbDrawing=true;sigCtx.beginPath();var p=fhbSpt(e);sigCtx.moveTo(p.x,p.y);});
sigCanvas.addEventListener('mousemove',function(e){if(!fhbDrawing)return;var p=fhbSpt(e);sigCtx.lineTo(p.x,p.y);sigCtx.stroke();fhbHasSig=true;sigHint.style.display='none';sigWrap.classList.remove('fhb-sig-err');});
sigCanvas.addEventListener('mouseup',function(){fhbDrawing=false;});
sigCanvas.addEventListener('mouseleave',function(){fhbDrawing=false;});
sigCanvas.addEventListener('touchstart',function(e){e.preventDefault();fhbDrawing=true;sigCtx.beginPath();var p=fhbSpt(e);sigCtx.moveTo(p.x,p.y);},{passive:false});
sigCanvas.addEventListener('touchmove',function(e){e.preventDefault();if(!fhbDrawing)return;var p=fhbSpt(e);sigCtx.lineTo(p.x,p.y);sigCtx.stroke();fhbHasSig=true;sigHint.style.display='none';sigWrap.classList.remove('fhb-sig-err');},{passive:false});
sigCanvas.addEventListener('touchend',function(){fhbDrawing=false;});
document.getElementById('fhb-sig-clr').addEventListener('click',function(){sigCtx.clearRect(0,0,sigCanvas.width,sigCanvas.height);fhbHasSig=false;sigHint.style.display='';sigWrap.classList.remove('fhb-sig-err');});

// Phone formatting
document.getElementById('fhb-country').addEventListener('change',function(){var o=this.options[this.selectedIndex];document.getElementById('fhb-cc-btn').textContent=(o.dataset.flag||'')+' '+this.value;});
document.getElementById('fhb-phone').addEventListener('input',function(e){var v=e.target.value.replace(/\D/g,'').substring(0,10),f='';if(v.length>6)f=v.substring(0,3)+'-'+v.substring(3,6)+'-'+v.substring(6);else if(v.length>3)f=v.substring(0,3)+'-'+v.substring(3);else f=v;e.target.value=f;});
document.querySelectorAll('input[name="fhb-staying"]').forEach(function(r){r.addEventListener('change',function(){document.getElementById('fhb-room-wrap').style.display=this.value==='yes'?'':'none';});});

// Submit
function fhbSubmit(){
    var empty=!fhbHasSig;
    if(empty){try{var d=sigCtx.getImageData(0,0,sigCanvas.width,sigCanvas.height).data;for(var i=0;i<d.length;i+=4){if(d[i+3]>10){empty=false;break;}}}catch(e){}}
    if(empty){sigWrap.classList.add('fhb-sig-err');sigWrap.scrollIntoView({behavior:'smooth',block:'center'});return;}
    var btn=document.getElementById('fhb-submit-btn');
    var errEl=document.getElementById('fhb-submit-err');
    errEl.style.display='none';btn.disabled=true;
    document.getElementById('fhb-submit-txt').innerHTML='<span class="fhb-spinner"></span> Saving…';
    var first=document.getElementById('fhb-first').value.trim();
    var last=document.getElementById('fhb-last').value.trim();
    var email=document.getElementById('fhb-email').value.trim();
    var phone=document.getElementById('fhb-country').value+' '+document.getElementById('fhb-phone').value.trim();
    var address=document.getElementById('fhb-address').value.trim();
    var notes=document.getElementById('fhb-notes').value.trim();
    var room=document.getElementById('fhb-room').value.trim();
    var init1=document.getElementById('fhb-init1').value.trim();
    var init2=document.getElementById('fhb-init2').value.trim();
    var init3=document.getElementById('fhb-init3').value.trim();
    var staying=document.querySelector('input[name="fhb-staying"]:checked').value;
    var total=fhbState.adults*fhbPriceAdult+fhbState.children*fhbPriceChild;
    var names=[];for(var i=0;i<fhbState.adults+fhbState.children;i++){var gf=document.getElementById('fhb-gfirst-'+i),gl=document.getElementById('fhb-glast-'+i);if(gf)names.push((gf.value.trim()+' '+(gl?gl.value.trim():'')).trim());}
    var sig=sigCanvas.toDataURL('image/png');
    var bookingBody='action=fh_save_booking&nonce='+fhbNonce
        +'&activity_id='+fhbActId+'&slot_id='+fhbState.selectedSlotId
        +'&booking_date='+encodeURIComponent(fhbState.selectedDate)
        +'&booking_time='+encodeURIComponent(fhbState.selectedTime)
        +'&guest_first_name='+encodeURIComponent(first)
        +'&guest_last_name='+encodeURIComponent(last)
        +'&guest_name='+encodeURIComponent(first+' '+last)
        +'&guest_email='+encodeURIComponent(email)
        +'&guest_phone='+encodeURIComponent(phone)
        +'&adults='+fhbState.adults+'&children='+fhbState.children
        +'&price_type=adult&total_price='+total.toFixed(2)
        +'&booking_source=online'
        +'&notes='+encodeURIComponent(names.join(', ')+(notes?' | '+notes:''))
        +'&send_email=1';
    var waiverBody='action=chena_submit_waiver&nonce='+encodeURIComponent(fhbWNonce)
        +'&guest_name='+encodeURIComponent(first+' '+last)
        +'&phone='+encodeURIComponent(phone)+'&address='+encodeURIComponent(address)
        +'&email='+encodeURIComponent(email)
        +'&visit_from='+encodeURIComponent(fhbState.selectedDate)
        +'&visit_to=&hotel_room='+encodeURIComponent(staying==='yes'?room:'')
        +'&initials='+encodeURIComponent(init1+' / '+init2+' / '+init3)
        +'&activities='+encodeURIComponent(fhbActName)
        +'&child_1=&child_2=&child_3=&child_4='
        +'&signature='+encodeURIComponent(sig)+'&waiver_version=v1.0';
    Promise.all([
        fetch(fhbAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:bookingBody}).then(function(r){return r.json();}),
        fetch(fhbAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:waiverBody}).then(function(r){return r.json();})
    ]).then(function(results){
        btn.disabled=false;
        document.getElementById('fhb-submit-txt').innerHTML='Confirm Booking <span class="fhb-arr"><svg viewBox="0 0 24 24"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg></span>';
        var br=results[0];
        if(br.success){
            document.getElementById('fhb-conf-code').textContent=br.data.code;
            document.getElementById('fhb-conf-email').textContent=email;
            document.getElementById('fhb-conf-total').textContent='$'+total.toFixed(2);
            var d=fhbState.selectedDate?new Date(fhbState.selectedDate+'T00:00:00'):null;
            var timeFmt=fhbState.selectedTime?new Date('1970-01-01T'+fhbState.selectedTime).toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit',hour12:true}):'—';
            document.getElementById('fhb-conf-details').innerHTML=
                fhbIR('Tour',fhbActName)+fhbIR('Date',d?d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'}):'—')
               +fhbIR('Time',timeFmt)+fhbIR('Guests',names.join(', '))
               +fhbIR('Total','$'+total.toFixed(2)+' — Pay on arrival')
               +fhbIR('Code','<strong style="color:#40FFF3;">'+br.data.code+'</strong>');
            fhbShowStep(9);
        } else {
            errEl.textContent=br.data||'Something went wrong. Please try again.';errEl.style.display='';
        }
    }).catch(function(){
        btn.disabled=false;document.getElementById('fhb-submit-txt').innerHTML='Confirm Booking';
        errEl.textContent='Network error. Please try again or see the front desk.';errEl.style.display='';
    });
}

// Load upsells + custom fields
function fhbLoadExtras() {
    if (!fhbActId) return;
    fetch(fhbAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=fh_get_booking_extras&activity_id='+fhbActId+'&nonce='+fhbNonce})
    .then(function(r){return r.json();})
    .then(function(data){
        if(!data.success)return;
        var upsells=data.data.upsells||[];
        var fields=data.data.fields||[];
        // Upsells
        if(upsells.length){
            var html='';
            upsells.forEach(function(u){
                html+='<div style="display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.05);">'
                    +'<div><div style="font-size:14px;font-weight:600;color:#eef2f6;">'+u.name+'</div>'
                    +'<div style="font-size:12px;color:#aabfd4;">$'+parseFloat(u.price).toFixed(2)+' '+((u.price_type==="per_person")?'per person':'flat')+'</div></div>'
                    +'<label style="display:flex;align-items:center;gap:8px;cursor:pointer;"><input type="checkbox" id="fhbu-'+u.id+'" data-price="'+u.price+'" data-type="'+u.price_type+'" onchange="fhbCalcTotal()" style="width:18px;height:18px;accent-color:#049DE1;"><span style="font-size:12px;color:#aabfd4;">Add</span></label>'
                    +'</div>';
            });
            document.getElementById('fhb-upsells-body').innerHTML=html;
            document.getElementById('fhb-upsells-card').style.display='';
        }
        // Custom fields
        if(fields.length){
            var html='';
            fields.forEach(function(f){
                html+='<div class="fhb-field" style="margin-bottom:14px;"><label style="font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#aabfd4;">'+f.field_label+(f.required?' *':'')+'</label>';
                if(f.field_type==='checkbox') html+='<input type="checkbox" id="fhbf-'+f.field_key+'" style="width:20px;height:20px;accent-color:#049DE1;margin-top:6px;">';
                else if(f.field_type==='number') html+='<input type="number" id="fhbf-'+f.field_key+'" class="fhb-pill" style="border-radius:8px;">';
                else html+='<input type="text" id="fhbf-'+f.field_key+'" class="fhb-pill" placeholder="'+f.field_label+'">';
                html+='</div>';
            });
            document.getElementById('fhb-fields-body').innerHTML=html;
            document.getElementById('fhb-fields-card').style.display='';
        }
        fhbUpsellDefs = upsells;
        fhbFieldDefs  = fields;
    });
}
var fhbUpsellDefs=[], fhbFieldDefs=[];

function fhbCalcTotal(){
    // Called from upsell checkboxes — no-op for now, upsells added at review
}

// Init
fhbRenderGuestFields();
if(fhbActId) fhbLoadExtras();
fhbUpdateProgress(fhbState.step);
// Show correct starting step
document.querySelectorAll('.fhb-step').forEach(function(s){s.classList.remove('active');});
var startEl=document.getElementById('fhb-step-'+fhbState.step);
if(startEl)startEl.classList.add('active');
// If pre-filled, load slots immediately
if(fhbSkipStep1&&fhbPreSlot){fhbState.selectedSlotId=fhbPreSlot;}
</script>
<?php
}

// ── WIDGET REPLACEMENT — inline calendar for tour pages ──────────
add_shortcode('fairerharbor_widget','fh_widget_shortcode');
function fh_widget_shortcode($atts) {
    $atts = shortcode_atts(['tour'=>''], $atts);
    ob_start();
    fh_render_tour_widget($atts['tour']);
    return ob_get_clean();
}

function fh_render_tour_widget($tour_slug = '') {
    if (!$tour_slug) {
        // Try to detect from current post
        $post_id = get_the_ID();
        if ($post_id) {
            $act_id = get_post_meta($post_id,'_fh_activity_id',true);
            if ($act_id) $tour_slug = get_post_field('post_name',$post_id);
        }
    }
    $data = $tour_slug ? fh_get_activity_by_slug($tour_slug) : null;
    $act  = $data['activity'] ?? null;
    $acf  = $data['acf'] ?? [];
    $nonce = wp_create_nonce('fh_nonce');
    $ajax  = admin_url('admin-ajax.php');
    $book_base = home_url('/book/?tour='.urlencode($tour_slug));
    ?>
<div id="fhw-wrap" style="font-family:'Inter',-apple-system,sans-serif;background:#0a0e14;border-radius:16px;overflow:hidden;border:1px solid rgba(14,165,233,.2);box-shadow:0 8px 40px rgba(0,0,0,.5);">
<style>
@keyframes fhw-in{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
@keyframes fhw-spin{to{transform:rotate(360deg)}}
@keyframes aurora-p{0%,100%{background-position:0% 50%}50%{background-position:100% 50%}}
.fhw-cal-day{aspect-ratio:1;display:flex;align-items:center;justify-content:center;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;border:1px solid transparent;transition:all .15s;color:#aabfd4;background:transparent;}
.fhw-cal-day:hover:not(.dis):not(.om){background:rgba(14,165,233,.12);border-color:rgba(14,165,233,.2);color:#fff;}
.fhw-cal-day.today{border-color:rgba(14,165,233,.4);color:#0ea5e9;}
.fhw-cal-day.sel{background:#0ea5e9;color:#fff;border-color:#0ea5e9;}
.fhw-cal-day.dis{opacity:.2;cursor:not-allowed;}
.fhw-cal-day.om{opacity:.15;cursor:default;}
.fhw-slot{background:#0f1419;border:1px solid rgba(14,165,233,.2);border-radius:8px;padding:10px;text-align:center;cursor:pointer;transition:all .15s;}
.fhw-slot:hover:not(.full){border-color:#0ea5e9;background:rgba(14,165,233,.08);}
.fhw-slot.sel{background:rgba(14,165,233,.15);border-color:#0ea5e9;}
.fhw-slot.full{opacity:.35;cursor:not-allowed;}
.fhw-slot-time{font-size:13px;font-weight:700;color:#0ea5e9;}
.fhw-slot-avail{font-size:10px;color:#6b7280;margin-top:2px;}
.fhw-slot-avail.low{color:#f59e0b;}
.fhw-step-btn{width:32px;height:32px;border-radius:7px;background:#0f1419;border:1px solid rgba(14,165,233,.2);color:#eef2f6;font-size:18px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s;}
.fhw-step-btn:hover{border-color:#0ea5e9;color:#0ea5e9;}
/* Crystal pill */
.fhw-cta{position:relative;display:flex;align-items:center;justify-content:center;width:100%;padding:15px;border-radius:100px;background:transparent;border:none;cursor:pointer;font-family:'Inter',sans-serif;transition:all .5s cubic-bezier(.25,.46,.45,.94);}
.fhw-cta:disabled{opacity:.4;cursor:not-allowed;pointer-events:none;}
.fhw-cta::before{content:'';position:absolute;inset:-1.5px;border-radius:100px;background:linear-gradient(135deg,#0ea5e9 0%,#22d3ee 25%,#0ea5e9 50%,#06b6d4 75%,#0ea5e9 100%);background-size:200% 200%;filter:blur(8px);opacity:.4;z-index:0;animation:aurora-p 5s ease-in-out infinite;}
.fhw-cta:disabled::before{opacity:0;}
.fhw-glass{position:absolute;inset:0;border-radius:100px;background:linear-gradient(135deg,rgba(4,21,42,.45),rgba(10,10,10,.38),rgba(4,30,59,.42));box-shadow:0 0 0 1px rgba(255,255,255,.4),0 6px 24px rgba(0,0,0,.3),inset 0 1.5px 0 rgba(255,255,255,.5);border:1.5px solid rgba(255,255,255,.3);backdrop-filter:blur(10px);z-index:1;transition:all .5s;}
.fhw-cta:not(:disabled):hover{transform:translateY(-2px);}
.fhw-cta:not(:disabled):hover .fhw-glass{box-shadow:0 0 2px 1px rgba(34,211,238,.5),0 0 18px rgba(34,211,238,.3),0 10px 40px rgba(14,165,233,.2),inset 0 2px 1px rgba(255,255,255,.55);border-color:rgba(34,211,238,.35);}
.fhw-cta-txt{position:relative;z-index:2;font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.16em;color:rgba(255,255,255,.95);display:flex;align-items:center;gap:8px;}
.fhw-spinner{display:inline-block;width:14px;height:14px;border:2px solid rgba(14,165,233,.2);border-top-color:#0ea5e9;border-radius:50%;animation:fhw-spin .7s linear infinite;}
</style>

<!-- Header -->
<div style="background:linear-gradient(135deg,rgba(14,165,233,.15),rgba(6,182,212,.1));padding:18px 22px;border-bottom:1px solid rgba(14,165,233,.2);">
  <div style="font-size:12px;font-weight:700;color:#0ea5e9;text-transform:uppercase;letter-spacing:.14em;margin-bottom:4px;">Book Your Adventure</div>
  <div style="font-size:18px;font-weight:800;color:#fff;">
    <?php echo $act ? esc_html($act->name) : 'Select a Tour'; ?>
  </div>
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;">
    <?php if (!empty($acf['price'])): ?><span style="background:rgba(14,165,233,.1);border:1px solid rgba(14,165,233,.2);color:#93c5fd;font-size:11px;font-weight:600;padding:3px 10px;border-radius:20px;">💰 <?php echo esc_html($acf['price']); ?></span><?php endif; ?>
    <?php if (!empty($acf['duration'])): ?><span style="background:rgba(14,165,233,.1);border:1px solid rgba(14,165,233,.2);color:#93c5fd;font-size:11px;font-weight:600;padding:3px 10px;border-radius:20px;">⏱ <?php echo esc_html($acf['duration']); ?></span><?php endif; ?>
    <?php if (!empty($acf['age'])): ?><span style="background:rgba(14,165,233,.1);border:1px solid rgba(14,165,233,.2);color:#93c5fd;font-size:11px;font-weight:600;padding:3px 10px;border-radius:20px;">👤 Ages <?php echo esc_html($acf['age']); ?></span><?php endif; ?>
  </div>
</div>

<!-- Live status -->
<div style="padding:8px 22px;background:rgba(0,0,0,.2);border-bottom:1px solid rgba(255,255,255,.05);display:flex;align-items:center;gap:6px;">
  <span style="width:8px;height:8px;background:#22c55e;border-radius:50%;animation:fhb-pulse 2s infinite;" id="fhw-status-dot"></span>
  <span style="font-size:11px;color:#22c55e;font-weight:600;">Live Availability</span>
</div>

<!-- Calendar -->
<div style="padding:20px 22px;border-bottom:1px solid rgba(255,255,255,.06);">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;">
    <button class="fhw-step-btn" onclick="fhwPrevMonth()">‹</button>
    <span style="font-size:14px;font-weight:700;color:#eef2f6;" id="fhw-month-lbl"></span>
    <button class="fhw-step-btn" onclick="fhwNextMonth()">›</button>
  </div>
  <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:3px;margin-bottom:6px;">
    <?php foreach(['Su','Mo','Tu','We','Th','Fr','Sa'] as $d): ?><div style="text-align:center;font-size:10px;font-weight:700;color:#4b5563;padding:3px 0;text-transform:uppercase;"><?php echo $d; ?></div><?php endforeach; ?>
  </div>
  <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:3px;" id="fhw-cal-grid"></div>
</div>

<!-- Time slots -->
<div id="fhw-slots-section" style="padding:16px 22px;border-bottom:1px solid rgba(255,255,255,.06);display:none;">
  <div style="font-size:10px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#0ea5e9;margin-bottom:10px;" id="fhw-slots-lbl">Available Times</div>
  <div id="fhw-slots-inner"></div>
</div>

<!-- Party size -->
<div style="padding:16px 22px;border-bottom:1px solid rgba(255,255,255,.06);">
  <div style="font-size:10px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#0ea5e9;margin-bottom:12px;">Party Size</div>
  <div style="display:flex;gap:20px;">
    <div>
      <div style="font-size:10px;color:#6b7280;text-transform:uppercase;letter-spacing:.08em;font-weight:600;margin-bottom:6px;">Adults</div>
      <div style="display:flex;align-items:center;gap:10px;">
        <button class="fhw-step-btn" onclick="fhwAdj('a',-1)">−</button>
        <span style="font-size:18px;font-weight:800;color:#eef2f6;min-width:24px;text-align:center;" id="fhw-adults">1</span>
        <button class="fhw-step-btn" onclick="fhwAdj('a',1)">+</button>
      </div>
    </div>
    <div>
      <div style="font-size:10px;color:#6b7280;text-transform:uppercase;letter-spacing:.08em;font-weight:600;margin-bottom:6px;">Children</div>
      <div style="display:flex;align-items:center;gap:10px;">
        <button class="fhw-step-btn" onclick="fhwAdj('c',-1)">−</button>
        <span style="font-size:18px;font-weight:800;color:#eef2f6;min-width:24px;text-align:center;" id="fhw-children">0</span>
        <button class="fhw-step-btn" onclick="fhwAdj('c',1)">+</button>
      </div>
    </div>
  </div>
</div>

<!-- Price summary -->
<div style="padding:14px 22px;border-bottom:1px solid rgba(255,255,255,.06);">
  <div style="display:flex;justify-content:space-between;align-items:center;">
    <span style="font-size:12px;color:#6b7280;">Estimated Total</span>
    <span style="font-size:24px;font-weight:800;color:#22d3ee;" id="fhw-total">$0.00</span>
  </div>
  <div id="fhw-avail-note" style="font-size:11px;color:#6b7280;margin-top:4px;"></div>
</div>

<!-- Book Now button -->
<div style="padding:16px 22px;">
  <button class="fhw-cta" id="fhw-book-btn" onclick="fhwBookNow()" disabled>
    <div class="fhw-glass"></div>
    <span class="fhw-cta-txt" id="fhw-btn-txt">Select a Date First</span>
  </button>
  <div style="text-align:center;font-size:11px;color:#4b5563;margin-top:10px;">No payment required now — pay on arrival</div>
</div>
</div>

<script>
var fhwActId    = <?php echo $act ? (int)$act->id : 0; ?>;
var fhwPA       = <?php echo $act ? (float)$act->price_adult : 0; ?>;
var fhwPC       = <?php echo $act ? (float)$act->price_child : 0; ?>;
var fhwCap      = <?php echo $act ? (int)$act->capacity : 20; ?>;
var fhwAjax     = '<?php echo esc_js($ajax); ?>';
var fhwNonce    = '<?php echo $nonce; ?>';
var fhwBookBase = '<?php echo esc_js($book_base); ?>';
var fhwState    = {cy:new Date().getFullYear(),cm:new Date().getMonth(),date:null,time:null,slotId:null,avail:0,adults:1,children:0,slotData:{}};
var FHWM=['January','February','March','April','May','June','July','August','September','October','November','December'];

function fhwRenderCal(){
    var y=fhwState.cy,m=fhwState.cm;
    document.getElementById('fhw-month-lbl').textContent=FHWM[m]+' '+y;
    var first=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate();
    var today=new Date();today.setHours(0,0,0,0);
    var grid=document.getElementById('fhw-cal-grid');grid.innerHTML='';
    for(var i=0;i<first;i++){var el=document.createElement('div');el.className='fhw-cal-day om';grid.appendChild(el);}
    for(var d=1;d<=days;d++){
        var dt=new Date(y,m,d),el=document.createElement('div');
        el.className='fhw-cal-day';el.textContent=d;
        var iso=y+'-'+String(m+1).padStart(2,'0')+'-'+String(d).padStart(2,'0');
        if(dt<today)el.classList.add('dis');
        else{
            if(dt.toDateString()===today.toDateString())el.classList.add('today');
            if(iso===fhwState.date)el.classList.add('sel');
            el.onclick=(function(ds){return function(){fhwSelDate(ds);};})(iso);
        }
        grid.appendChild(el);
    }
}
function fhwPrevMonth(){fhwState.cm--;if(fhwState.cm<0){fhwState.cm=11;fhwState.cy--;}fhwRenderCal();}
function fhwNextMonth(){fhwState.cm++;if(fhwState.cm>11){fhwState.cm=0;fhwState.cy++;}fhwRenderCal();}
function fhwSelDate(iso){
    fhwState.date=iso;fhwState.time=null;fhwState.slotId=null;
    fhwRenderCal();fhwLoadSlots(iso);
    var d=new Date(iso+'T00:00:00');
    document.getElementById('fhw-slots-lbl').textContent='Times for '+d.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'});
    document.getElementById('fhw-slots-section').style.display='';
    document.getElementById('fhw-slots-inner').innerHTML='<div style="text-align:center;padding:12px;color:#6b7280;font-size:12px;"><span class="fhw-spinner"></span> Loading…</div>';
    fhwUpdateBtn();fhwUpdateTotal();
}
function fhwLoadSlots(date){
    fetch(fhwAjax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:'action=fh_get_slots&activity_id='+fhwActId+'&date='+date+'&nonce='+fhwNonce})
    .then(function(r){return r.json();})
    .then(function(data){
        fhwState.slotData={};
        if(!data.success||!data.data.length){document.getElementById('fhw-slots-inner').innerHTML='<div style="text-align:center;padding:12px;color:#6b7280;font-size:12px;">No times available on this date.</div>';return;}
        var html='<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(100px,1fr));gap:6px;">';
        data.data.forEach(function(s){
            fhwState.slotData[s.id]=s;
            var full=s.available<=0,low=s.available<=3&&!full;
            var sel=s.id==fhwState.slotId;
            html+='<div class="fhw-slot'+(full?' full':'')+(sel?' sel':'')+'" onclick="fhwSelSlot(\''+s.time_raw+'\',\''+s.time+'\','+s.id+','+s.available+')">';
            html+='<div class="fhw-slot-time">'+s.time+'</div>';
            html+='<div class="fhw-slot-avail'+(low?' low':'')+'">'+((full?'Full':s.available+' left'))+'</div></div>';
        });
        html+='</div>';
        document.getElementById('fhw-slots-inner').innerHTML=html;
    });
}
function fhwSelSlot(timeRaw,timeFmt,slotId,available){
    if(available<=0)return;
    fhwState.time=timeRaw;fhwState.slotId=slotId;fhwState.avail=available;
    document.querySelectorAll('.fhw-slot').forEach(function(s){s.classList.remove('sel');});
    event.currentTarget.classList.add('sel');
    fhwUpdateBtn();fhwUpdateAvailNote();
}
function fhwAdj(type,delta){
    if(type==='a'){fhwState.adults=Math.max(0,fhwState.adults+delta);document.getElementById('fhw-adults').textContent=fhwState.adults;}
    else{fhwState.children=Math.max(0,fhwState.children+delta);document.getElementById('fhw-children').textContent=fhwState.children;}
    fhwUpdateTotal();fhwUpdateBtn();
}
function fhwUpdateTotal(){
    var t=(fhwState.adults*fhwPA)+(fhwState.children*fhwPC);
    document.getElementById('fhw-total').textContent='$'+t.toFixed(2);
}
function fhwUpdateAvailNote(){
    var note=document.getElementById('fhw-avail-note');
    if(fhwState.avail>0&&fhwState.avail<=5){note.style.color='#f59e0b';note.textContent='⚡ Only '+fhwState.avail+' spots remaining!';}
    else if(fhwState.avail>0){note.style.color='#22c55e';note.textContent=fhwState.avail+' spots available';}
    else note.textContent='';
}
function fhwUpdateBtn(){
    var btn=document.getElementById('fhw-book-btn');
    var txt=document.getElementById('fhw-btn-txt');
    if(!fhwState.date){btn.disabled=true;txt.textContent='Select a Date First';return;}
    if(!fhwState.slotId){btn.disabled=true;txt.textContent='Select a Time Slot';return;}
    var total=fhwState.adults+fhwState.children;
    if(total<1){btn.disabled=true;txt.textContent='Add at Least 1 Guest';return;}
    btn.disabled=false;
    txt.innerHTML='Book Now — $'+((fhwState.adults*fhwPA)+(fhwState.children*fhwPC)).toFixed(2)+' <span style="font-size:11px;opacity:.8;">↗</span>';
}
function fhwBookNow(){
    if(!fhwState.date||!fhwState.slotId)return;
    var url=fhwBookBase+'&date='+encodeURIComponent(fhwState.date)+'&time='+encodeURIComponent(fhwState.time)+'&slot='+fhwState.slotId+'&adults='+fhwState.adults+'&children='+fhwState.children;
    window.location.href=url;
}
// Init
fhwRenderCal();fhwUpdateTotal();fhwUpdateBtn();
</script>
<?php
}
